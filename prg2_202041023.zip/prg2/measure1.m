function err=measure1(data,lg,f,A)
  err = 0; 
  for n=1:size(data,1)
    d=data(n,lg.density); 
    o=data(n,lg.ratio)*d; 
    c=data(n,lg.cn); 
    err += (c-f(A,d,o))^2; 
  end
  err = sqrt(err/size(data,1)); 
end