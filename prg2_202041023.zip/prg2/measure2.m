function err=measure2(data,lg,f,A,alpha)
  err = 0; 
  for n=1:size(data,1)
    d=data(n,lg.density); 
    o=data(n,lg.ratio)*d; 
    c=data(n,lg.cn); 
    err += (c-f(A,d,o,alpha))^2; 
  end
  err = sqrt(err/size(data,1)); 
end