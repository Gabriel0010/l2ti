function v_exp2_2_mat(name)
%%checks data sets of the kind 2_2
         assert(length(name)>=4)
         assert(strcmp(name(end-3:end),'.mat'))
  rep=['../dataset/']; 
  T=load([rep,name]); 
         assert(isfield(T,'data'))
         assert(isfield(T,'lg'))
         assert(isfield(T.lg,'p_name_mat')); 
         assert(T.lg.ln==size(T.data,2))
  if size(T.data,1)>0
    i=ceil(rand(1)*size(T.data,1)); 
    n=T.data(i,T.lg.n); 
         assert(floor(n)==n)
    if size(T.data,1)>i 
         assert(T.data(i+1,T.lg.n)>T.data(i,T.lg.n));     
    end
         assert(n/T.lg.p_fe>=T.lg.p_TI(1)); 
         assert(n/T.lg.p_fe+1/T.lg.p_fe<=T.lg.p_TI(2)); 
  end
  %keyboard,
  disp(['v_exp2_2_mat ',name])
end