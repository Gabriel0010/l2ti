function [A1,A2]=solve1(data,lg,M); 
%%A1 is the OLS solution 
%%A2 is the non-negative OLS solution
  N=size(data,1); 
  D=data(:,lg.density); 
  O=D.*data(:,lg.ratio); 
         assert(all( O>=0)); 
  C=data(:,lg.cn); 
  X=[ones(N,1) D O D.^2 D.*O O.^2]; 
  v_X(X); 
  Y=C; 
  v_M(M); 
  A1=inv(X'*X)*(X'*Y);
  v_nnls1();
  epsi=1e-7; 
  B=lsqnonneg1(X*inv(M),Y);
  A2=inv(M)*B; 
end


function v_X(X)
  f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
  A=rand(1,6)'; 
  N=size(X,1); 
  ind=ceil(rand(1)*N); 
         assert(X(ind,:)*A,f(A,X(ind,2),X(ind,3)),1e-8)
end

function v_M(M)
  A=randn(6,1); 
  cond=@(a)(all(a(1:5)>=0))&(a(5)+2*a(6)>=0); 
         assert(all(M*A>=0) == cond(A)); 
end

function v_nnls1()
A = [0.0372    0.2869
     0.6861    0.7071
     0.6233    0.6245
     0.6344    0.6170];
y = [0.8587
     0.1781
     0.0747
     0.8405];
E=0.0000001;
  x = lsqnonneg1 (A, y); %  0 0.6929
         assert(all(x>=0)); 
         assert(all(abs(x-[0;0.692934397130293])<E*10)); 
  J=(A*x-y)'*(A*x-y);
  tic,
  for k=1:1  %1e8
    if toc>5*60 
      disp(['k=',num2str(k)]),
      tic,
    end
    x=rand(2,1).*10.^(randn(2,1)*7); 
    J1=(A*x-y)'*(A*x-y);
         assert(J1>=J-E); 
  end
end

function x=nnls1(A,Y,epsi)
% NON-NEGATIVE LEAST SQUARES
% Code written according to NNLS algorithmon Wikipedia
% https://en.wikipedia.org/wiki/Non-negative_least_squares#Algorithms

% Input matrix, vector and tolerance

  % Assigning m and n for A(mxn)
  m=size(A, 1);
  n=size(A, 2);

  % Set P = ∅
  P=[];

  % Set R = {1, ..., n}
  R=[];
  for i=1:n
    R=[R, i];
  end	

  % Set x to an all-zero vector of dimension n
  x=zeros(n, 1);

  % Set w = Aᵀ(Y − Ax)
  w=A'*(Y-A*x);
  
  % Main loop:
  while ~isempty(R) && max(w(R))>epsi
    % Let j in R be the index of max(w) in w
    [nr, j_]=max(w(R));
    j = R(j_); 
         assert(ismember(j,R)); 
         assert(w(j) >= max(w(R))); 
    % Add j to P
    P=[P, j];

    % Remove j from R
    R(find(R(:)==j))=[];
         assert(unique([P,R]) == 1:n); 
         assert(~ismember(j,R)); 
    % Let AP be A restricted to the variables included in P
    Ap=[];	
    for i=P
      Ap=[Ap, A(:, i)];
    end
         assert(size(Ap,2) == length(P)); 
         i1 = ceil(rand(1)*length(P)); 
         i2 = P(i1); 
         assert(all(Ap(:,i2) == A(:,i1))); 

    %Let s be vector of same length as x. Let sP denote the sub-vector with indexes from P, and let sR denote the sub-vector with indexes from R.

    % Set sP = ((AP)ᵀ AP)−1 (AP)ᵀY
    if(~isempty(Ap))
        sP=pinv(Ap'*Ap)*Ap'*Y;
      else
        sP=[];
    end

    % Set sR to zero
    sR=zeros(length(R), 1);

    % Setting up vector s
    s=zeros(size(A, 2), 1);
    count=1;
    for i=P
      s(i)=sP(count);
      count=count+1;
    end
    count=1;
    for i=R
      s(i)=sR(count);
      count=count+1;
    end

    % Inner loop
    while min(sP)<=0

      % Let alpha=-min(s(i)/(x(i)-s(i)) for i in P where s(i)<=0
      for z=1:length(P)
        idx=P(z);
        if(s(idx)<=0)
          alpha=x(idx)/(x(idx)-s(idx));
          break
        end
      end	
         assert(all(size(alpha))=[1 1]); 
         assert(~isnan(alpha)); 
      for i=P
        if(s(i)<=0)
          if(alpha>x(i)/(x(i)-s(i)))
            alpha=x(i)/(x(i)-s(i));
          end	
        end
      end
      alpha=-alpha;

      % Set x to x + alpha(s - x)	
      x=x+alpha*(s-x);

      % Move to R all indices j in P such that x(j) = 0
      for i=P
        if(x(i)==0)
          P(find(P(:)==i))=[];
          R=[R, i];
        end
      end

      % Updating Ap
      Ap=[];
      for i=P
        Ap=[Ap, A(:, i)];
      end

      % Set sP = ((AP)ᵀ AP)−1 (AP)ᵀY
      if(~isempty(Ap))
        sP=pinv(Ap'*Ap)*Ap'*Y;
      else
        sP=[];
      end

      % Set sR to zero
      sR=zeros(length(R), 1);

    end

    % Set x to s
    x=s;

    % Set w to Aᵀ(Y − Ax)
    w=A'*(Y-A*x);

  end
end