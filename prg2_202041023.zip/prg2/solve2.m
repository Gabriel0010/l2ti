function [A1,A2,A3,M]=solve2(data,lg); 
%%A1 is the OLS solution 
%%A2 is the non-negative OLS solution with M=Id
%%A3 is the non-negative OLS solution with M
  N=size(data,1); 
  D=data(:,lg.density); 
  O=D.*data(:,lg.ratio); 
         assert(all( O>=0)); 
  C=data(:,lg.cn); 
  X=[ones(N,1) D O D.^2 D.*O O.^2 D.^3 D.^2.*O D.*O.^2 O.^3]; 
  v_X(X); 
  Y=C; 
  M=c_M(); 
  v_M(M); 
  A1=inv(X'*X)*(X'*Y);
  v_nnls1();
  B=lsqnonneg1(X,Y);
  A2=B; 
  H=2*X'*X; q=-2*X'*Y; A=[]; b=[]; lb=[]; ub=[]; A_lb=zeros(size(M,1),1); A_in=M; A_ub=[]; 
  [A3, obj, info, lambda] = qp (A1, H, q, A, b, lb, ub, A_lb, A_in, A_ub);
end


function M=c_M(); 
  M=zeros(13,10); 
  M(1,1)=1; 
  M(2,2)=1; 
  M(3,3)=1; 
  M(4,4)=1;
  M(5,4:6)=[1 1 1]; 
  M(6,[5 7 9])=[2 3 1];   
  M(7,5)=1; 
  M(8,5:6)=[1 2]; 
  M(9,7)=1; 
  M(10,7:10)=[1 1 1 1];
  M(11,8)=1; 
  M(12,[8 9])=[1 1]; 
  M(13,[8 9 10])=[1 2 3]; 
end

function v_X(X)
  f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2+...
    a(7)*d.^3+a(8)*d.^2.*o+a(9)*d.*o.^2+a(10)*o.^3; 
  A=rand(1,10)'; 
  N=size(X,1); 
  ind=ceil(rand(1)*N); 
         assert(X(ind,:)*A,f(A,X(ind,2),X(ind,3)),1e-8)
end

function v_M(M)
  for k=1:1e3
    A=randn(10,1);
  cond1=@(a)all(a([1:5 7 8])>=0); 
  cond2=@(a)(a(5)+2*a(6)>=0)&(2*a(5)+3*a(7)+a(9)>=0)&...
    (a(7)+a(8)+a(9)+a(10)>=0)&...
    (a(8)+2*a(9)+3*a(10)>=0)&(a(8)+a(9)>=0)&(a(4)+a(5)+a(6)>=0); 
  cond=@(a)cond1(a)&cond2(a); 
         assert(all(M*A>=0) == cond(A)); 
  end
end

function v_nnls1()
A = [0.0372    0.2869
     0.6861    0.7071
     0.6233    0.6245
     0.6344    0.6170];
y = [0.8587
     0.1781
     0.0747
     0.8405];
E=0.0000001;
  x = lsqnonneg1 (A, y); %  0 0.6929
         assert(all(x>=0)); 
         assert(all(abs(x-[0;0.692934397130293])<E*10)); 
  J=(A*x-y)'*(A*x-y);
  tic,
  for k=1:1  %1e8
    if toc>5*60 
      disp(['k=',num2str(k)]),
      tic,
    end
    x=rand(2,1).*10.^(randn(2,1)*7); 
    J1=(A*x-y)'*(A*x-y);
         assert(J1>=J-E); 
  end
end
