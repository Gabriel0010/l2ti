function v_split_data3()
  lg=lg_c();
  lg.p_fe=1/ceil(rand(1)*150); 
  data=data_c_1(lg);
  [data2,lg2]=split_data3(data,lg,lg.p_fe,[],80); 
         assert(sum(data2(:,lg2.density)) == size(data,1)); 
         assert((data2(:,lg2.ratio) == 0)|(data2(:,lg2.density) == 0)); 
  [data2,lg2]=split_data3(data,lg,lg.p_fe,[],90); 
         assert(sum(data2(:,lg2.density)) == 0); 
  data(1,lg.limit) = 90;
  [data2,lg2]=split_data3(data,lg,lg.p_fe,[],80); 
         assert(sum(data2(:,lg2.density)) == size(data,1)-1); 
  data=data_c_1(lg);
  lg.p_fe = lg.p_fe*2;
  [data2,lg2]=split_data3(data,lg,lg.p_fe,[],80); 
         assert(sum(data2(:,lg2.density)) == size(data,1)); 
  data=data_c_1(lg);
  t1 = data2time(data(1,:),lg);   
  t3 = data2time(data(end,:),lg)+1e-8;   
  t2 = (t1+t3)/2; 
  [data2,lg2]=split_data3(data,lg,lg.p_fe,[t1,t2],80); 
         assert(all(lg2.p_TI == [t1,t2])); 
  [data3,lg3]=split_data3(data,lg,lg.p_fe,[t2,t3],80); 
         assert(all(lg3.p_TI == [t2,t3])); 
         assert(sum(data2(:,lg2.density))+sum(data3(:,lg3.density)) == size(data,1)); 
  data=data_c_1(lg);
  i=ceil(rand(1)*(size(data,1)-1)); 
  data(i,lg.speed)   = data(i,lg.limit)+8; 
  data(i+1,lg.speed) = data(i+1,lg.limit)+8; 
  [data2,lg2]=split_data3(data,lg,lg.p_fe,[],80); 
         r=data2(:,lg2.ratio); d=data2(:,lg2.density); 
         assert(sum(r(r>=0).*d(r>=0)) == 2)
  [data,lg]=data_c_2();      
  [data3,lg3]=split_data3(data,lg,1/5/60,[],[]);        
  t=8*3600+45*60; n=data3(1,lg3.n); 
         assert(t>=n/lg3.p_fe-1e-10); 
         assert(t<(n+1)/lg3.p_fe+1e-10); 
  [data,lg]=data_c_3();      
  [data4,lg4]=split_data3(data,lg,1/5/60,[],[]);        
  t=16*3600+12*60; n=data4(end,lg4.n); 
         assert(t>=(n-1)/lg4.p_fe-1e-10); 
         assert(t<n/lg4.p_fe+1e-10); 
  disp('v_split_data3')
end


function data=data_c_1(lg)
  dt_l=rand(1,30)/lg.p_fe; t_l=cumsum(dt_l)+rand(1)*10000; 
  data=zeros(length(t_l),lg.ln); 
  for k=1:length(t_l)
    [y, m, d, h, mi, s] = datevec(t_l(k)/24/3600); 
    data(k,lg.year)=y+2021; 
    data(k,lg.month)=m; 
    data(k,lg.day)=d; 
    data(k,lg.hour)=h; 
    data(k,lg.minute)=mi+s/60; 
  end
  data(:,lg.limit)=80; 
  data(:,lg.speed)=80*rand(length(t_l),1);
end

function [data,lg]=data_c_2()
  file_name='JDSR23.csv'; 
  rep=['../dataset/']; 
  [data,lg]=read_file1([rep,file_name],5);
end

function [data,lg]=data_c_3()
%2021-01-01T16:12;49.306873 1.1587267;64;80
  file_name='JDSR23.csv'; 
  rep=['../dataset/']; 
  [data,lg]=read_file1([rep,file_name],66);
end



function [data,lg]=data_c_3()
%2021-01-01T16:12;49.306873 1.1587267;64;80
  file_name='JDSR23.csv'; 
  rep=['../dataset/']; 
  [data,lg]=read_file1([rep,file_name],66);
end


function lg=lg_c()
  lg.year=1; 
  lg.month=2; 
  lg.day=3; 
  lg.hour=4; 
  lg.minute=5; 
  lg.position_x=6; 
  lg.position_y=7; 
  lg.speed=8; 
  lg.limit=9; 
  lg.ln=9; 
end