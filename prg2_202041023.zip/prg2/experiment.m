%%DONE 
%Time of end of data1 -> exp1, days_nb=167
%ratio as function of limit 
%  -> exp2, fig_exp2_2a.png, exp3, fig_exp2_2b.png
%  -> exp8, fig_exp2_8c.png, exp9, fig_exp2_9d.png
%ratio as function of days
%  -> exp4, fig_exp2_4a.png, exp5, fig_exp2_5b.png
%  -> exp10, fig_exp2_4a.png, exp11, fig_exp2_5b.png
%ratio and density as function of hours
%  -> exp14, exp15, exp16 fig_exp2_16cd.png, fig_exp2_16e.png
  

%%TODO
%average density for roads as a function of the speed limit
 

%%EXPERIMENT
% clear 
% number=1; 
% cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
% rep=['../dataset/']; 
% load([rep,'exp5b.mat'],'data','lg'); 
% t2=data2time(data(end,:),lg); 
% days_nb = t2/3600/24; 



%%EXPERIMENT
clear 
number=2; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
limit_l=[30 50 80 90 110 130]; 
ratio_mean_l=zeros(1,length(limit_l)); 
T=load([rep,'exp1.mat'],'data','lg'); 
fe=1/180; 
for k=1:length(limit_l)
  [data,lg]=split_data3(T.data,T.lg,fe,[],limit_l(k));
  ind = find(data(:,lg.density)>0);
  ratio_mean_l(k) = mean(data(ind,lg.ratio)); 
end
figure(1); bar(limit_l,ratio_mean_l); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_2a.png'],'png'); 


%%EXPERIMENT
clear 
number=3; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
limit_l=[30 50 80 90 110 130]; 
ratio_mean_l=zeros(1,length(limit_l)); 
T=load([rep,'exp5b.mat'],'data','lg'); 
fe=1/180; 
for k=1:length(limit_l)
  disp(['k=',num2str(k)])
  [data,lg]=split_data3(T.data,T.lg,fe,[],limit_l(k));
  ind = find(data(:,lg.density)>0);
  ratio_mean_l(k) = mean(data(ind,lg.ratio)); 
end
figure(1); bar(limit_l,ratio_mean_l); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
delete([rep,'fig_exp2_2b.png'])
saveas_(1,[rep,'fig_exp2_2b.png'],'png'); 



%%EXPERIMENT
clear 
number=4; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp1.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
day_l=0:(day_nb-1); 
ratio_mean_l=zeros(1,length(day_l)); 
fe=1/180; 
for k=1:length(day_l)
  tk_1=24*3600*day_l(k)+t1;
  tk_2=24*3600*day_l(k)+24*3600-1e-8+t1;
  disp(['k=',num2str(k)])
  [data,lg]=split_data3(T.data,T.lg,fe,[tk_1,tk_2],[]);
  ind = find(data(:,lg.density)>0);
  ratio_mean_l(k) = mean(data(ind,lg.ratio)); 
end
figure(1); plot(day_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_4a.png'],'png'); 




%%EXPERIMENT
clear 
number=5; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
disp(['day_nb=',num2str(day_nb)]),
day_l=0:(day_nb-1); 
ratio_mean_l=zeros(1,length(day_l)); 
fe=1/180; 
for k=1:length(day_l)
  tk_1=24*3600*day_l(k)+t1;
  tk_2=24*3600*day_l(k)+24*3600-1e-8+t1;
  disp(['k=',num2str(k)])
  [data,lg]=split_data3(T.data,T.lg,fe,[tk_1,tk_2],[]);
  ind = find(data(:,lg.density)>0);
  ratio_mean_l(k) = mean(data(ind,lg.ratio)); 
end
figure(1); plot(day_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_5b.png'],'png'); 



%%EXPERIMENT
clear 
number=6; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
hour_l=0:23; 
ratio_mean_l=zeros(1,length(hour_l)); 
T=load([rep,'exp1.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
day_l=0:(day_nb-1); 
fe=1/180; 
for k=1:length(hour_l)
  for l=1:length(day_l)
    tkl_1=24*3600*day_l(l)+3600*hour_l(k);
    tkl_2=24*3600*day_l(l)+3600*hour_l(k)+3600-1e-8; 
    disp(['k=',num2str(k),' l=',num2str(l)])
    [data,lg]=split_data3(T.data,T.lg,fe,[tkl_1,tkl_2],[]);   
    ind = find(data(:,lg.density)>0);
    if length(ind)>0
      ratio_mean_l(k) += mean(data(ind,lg.ratio)); 
    end
  end
end
ratio_mean_l=ratio_mean_l/length(day_l); 
figure(1); plot(hour_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_6a.png'],'png'); 




%%EXPERIMENT
clear 
number=7; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
hour_l=0:23; 
ratio_mean_l=zeros(1,length(hour_l)); 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
day_l=0:(day_nb-1); 
fe=1/180; 
for k=1:length(hour_l)
  for l=1:length(day_l)
    tkl_1=24*3600*day_l(l)+3600*hour_l(k);
    tkl_2=24*3600*day_l(l)+3600*hour_l(k)+3600-1e-8; 
    disp(['k=',num2str(k),' l=',num2str(l)])
    [data,lg]=split_data3(T.data,T.lg,fe,[tkl_1,tkl_2],[]);   
    ind = find(data(:,lg.density)>0);
    if length(ind)>0
      ratio_mean_l(k) += mean(data(ind,lg.ratio)); 
    end
  end
end
ratio_mean_l=ratio_mean_l/length(day_l); 
figure(1); plot(hour_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_7b.png'],'png'); 



%%EXPERIMENT
clear 
%instead of averaging ratios, it is d*r which is averaged. 
number=8; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
limit_l=[30 50 80 90 110 130]; 
ratio_mean_l=zeros(1,length(limit_l)); 
ratio_cum_l=zeros(1,length(limit_l)); 
density_cum_l=zeros(1,length(limit_l)); 
T=load([rep,'exp1.mat'],'data','lg'); 
fe=1/180; 
for k=1:length(limit_l)
  [data,lg]=split_data3(T.data,T.lg,fe,[],limit_l(k));
  [ratio_cum_l(k),density_cum_l(k)] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
end
ind = find(density_cum_l>0); 
ratio_mean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1); bar(limit_l,ratio_mean_l); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_8c.png'],'png'); 



%%EXPERIMENT
clear 
%instead of averaging ratios, it is d*r which is averaged. 
number=9; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
limit_l=[30 50 80 90 110 130]; 
ratio_mean_l=zeros(1,length(limit_l)); 
ratio_cum_l=zeros(1,length(limit_l)); 
density_cum_l=zeros(1,length(limit_l)); 
T=load([rep,'exp5b.mat'],'data','lg'); 
fe=1/180; 
for k=1:length(limit_l)
  [data,lg]=split_data3(T.data,T.lg,fe,[],limit_l(k));
  [ratio_cum_l(k),density_cum_l(k)] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
end
ind = find(density_cum_l>0); 
ratio_mean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1); bar(limit_l,ratio_mean_l); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_9d.png'],'png'); 




%%EXPERIMENT
clear 
number=10; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp1.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
day_l=0:(day_nb-1); 
ratio_mean_l=zeros(1,length(day_l)); 
ratio_cum_l=zeros(1,length(day_l)); 
density_cum_l=zeros(1,length(day_l)); 
fe=1/180; 
for k=1:length(day_l)
  tk_1=24*3600*day_l(k)+t1;
  tk_2=24*3600*day_l(k)+24*3600-1e-8+t1;
  disp(['k=',num2str(k)])
  [data,lg]=split_data3(T.data,T.lg,fe,[tk_1,tk_2],[]);
  [ratio_cum_l(k),density_cum_l(k)] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
end
ind = find(density_cum_l>0); 
ratio_mean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1); plot(day_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_10c.png'],'png'); 




%%EXPERIMENT
clear 
number=11; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
disp(['day_nb=',num2str(day_nb)]),
day_l=0:(day_nb-1); 
ratio_mean_l=zeros(1,length(day_l)); 
ratio_cum_l=zeros(1,length(day_l)); 
density_cum_l=zeros(1,length(day_l)); 
fe=1/180; 
for k=1:length(day_l)
  tk_1=24*3600*day_l(k)+t1;
  tk_2=24*3600*day_l(k)+24*3600-1e-8+t1;
  disp(['k=',num2str(k)])
  [data,lg]=split_data3(T.data,T.lg,fe,[tk_1,tk_2],[]);
  [ratio_cum_l(k),density_cum_l(k)] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
end
ind = find(density_cum_l>0); 
ratio_mean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1); plot(day_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_11d.png'],'png'); 



%%EXPERIMENT
clear 
number=12; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
hour_l=0:23; 
ratio_mean_l=zeros(1,length(hour_l)); 
T=load([rep,'exp1.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
day_l=0:(day_nb-1); 
ratio_mean_l=zeros(1,length(hour_l)); 
ratio_cum_l=zeros(1,length(hour_l)); 
density_cum_l=zeros(1,length(hour_l)); 
fe=1/180; 
for k=1:length(hour_l)
  for l=1:length(day_l)
    tkl_1=24*3600*day_l(l)+3600*hour_l(k);
    tkl_2=24*3600*day_l(l)+3600*hour_l(k)+3600-1e-8; 
    disp(['k=',num2str(k),' l=',num2str(l)])
    [data,lg]=split_data3(T.data,T.lg,fe,[tkl_1,tkl_2],[]);   
    ind = find(data(:,lg.density)>0);
    [dr,d] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
    ratio_cum_l(k) += dr; density_cum_l(k) += d; 
  end
end
ind = find(density_cum_l>0); 
ratio_mean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1); plot(hour_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_12c.png'],'png'); 




%%EXPERIMENT
clear 
number=13; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
hour_l=0:23; 
ratio_mean_l=zeros(1,length(hour_l)); 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor((t2-t1)/24/3600); 
day_l=0:(day_nb-1); 
ratio_mean_l=zeros(1,length(hour_l)); 
ratio_cum_l=zeros(1,length(hour_l)); 
density_cum_l=zeros(1,length(hour_l)); 
fe=1/180; 
for k=1:length(hour_l)
  for l=1:length(day_l)
    tkl_1=24*3600*day_l(l)+3600*hour_l(k);
    tkl_2=24*3600*day_l(l)+3600*hour_l(k)+3600-1e-8; 
    disp(['k=',num2str(k),' l=',num2str(l)])
    [data,lg]=split_data3(T.data,T.lg,fe,[tkl_1,tkl_2],[]);   
    ind = find(data(:,lg.density)>0);
    [dr,d] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
    ratio_cum_l(k) += dr; density_cum_l(k) += d; 
  end
end
ind = find(density_cum_l>0); 
ratio_mean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1); plot(hour_l,ratio_mean_l,'linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_13d.png'],'png'); 

%%EXPERIMENT
clear 
number=14; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp5b.mat'],'data','lg'); 
fe=1/180; 
[data,lg]=split_data3(T.data,T.lg,fe,[],[]);   
save([rep,'exp2_14.mat'],'data','lg'); 

%%EXPERIMENT
%ratio_rmean_l, ratio_dmean_l, density_mean_l,  
% are the average ratios without density-weighting, with density-weighting and the average density
%ratio_cum_l and density_cum_l are used to compute ratio_dmean_l, 
% the first is the cumulated number of offending cars
% the second is the cumulated number of cars
%num_rcum_l and num_dcum_l are used to account the number samples considered when averaging. 
clear 
number=15; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=1+floor(t2/24/3600); 
T=load([rep,'exp2_14.mat'],'data','lg'); 
hour_l=0:23; 
day_l=0:(day_nb-1); 
ratio_rmean_l  = zeros(1,length(hour_l)); 
ratio_dmean_l  = zeros(1,length(hour_l)); 
density_mean_l = zeros(1,length(hour_l)); 
ratio_cum_l    = zeros(1,length(hour_l)); 
density_cum_l  = zeros(1,length(hour_l)); 
num_rcum_l     = zeros(1,length(hour_l)); 
num_dcum_l     = zeros(1,length(hour_l)); 
for k=1:length(hour_l)
  for l=1:length(day_l)
    tkl_1=24*3600*day_l(l)+3600*hour_l(k);
    tkl_2=24*3600*day_l(l)+3600*hour_l(k)+3600-1e-8; 
    disp(['k=',num2str(k),' l=',num2str(l)])
    n1 = floor(tkl_1*T.lg.p_fe); 
    n2 = ceil(tkl_2*T.lg.p_fe);
         assert(n2>n1+1)
    for n=n1:n2
      if (n+1>0)&(n+1<=size(T.data,1))
         assert(T.data(n+1,T.lg.n) == n+1+653)
      end
      m = n-653;    
      if m <= 0 continue, end
      if m > size(T.data,1) continue, end
      if n == n1     portion = n1+1-tkl_1*T.lg.p_fe; 
      elseif n == n2 portion = tkl_2*T.lg.p_fe-(n2-1);
      else           portion = 1; 
      end
         assert(0 <= portion);       
         assert(portion <= 1);       
      if T.data(m,T.lg.density) > 0
        ratio_cum_l(k)   += T.data(m,T.lg.density)*T.data(m,T.lg.ratio)*portion; 
        ratio_rmean_l(k) += T.data(m,T.lg.ratio)*portion;
        num_rcum_l(k)    += portion;         
      end
      density_cum_l(k)   += T.data(m,T.lg.density)*portion;          
      num_dcum_l(k)      += portion;         
    end
  end
end
ind = find(density_cum_l>0); 
ratio_dmean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
ind = find(num_rcum_l > 0); 
ratio_rmean_l(ind) = ratio_rmean_l(ind)./num_rcum_l(ind); 
ind = find(num_rcum_l == 0); 
ratio_rmean_l(ind) = -1; 
density_mean_l = density_cum_l./num_dcum_l; 
save([rep,'exp2_15.mat'],'ratio_dmean_l','ratio_rmean_l','density_mean_l','ratio_cum_l','density_cum_l','num_rcum_l','num_dcum_l'); 



%%EXPERIMENT
%ratio_rmean_l, ratio_dmean_l, density_mean_l,  
% are the average ratios without density-weighting, with density-weighting and the average density
%ratio_cum_l and density_cum_l are used to compute ratio_dmean_l, 
% the first is the cumulated number of offending cars
% the second is the cumulated number of cars
%num_rcum_l and num_dcum_l are used to account the number samples considered when averaging. 
clear 
number=16; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
hour_l=0:23; 
T=load([rep,'exp2_15.mat']); 
extend_y = @(u)[u u(1)]; 
extend_x = @(u)[u 1+u(end)]; 
figure(1); plot(extend_x(hour_l),extend_y(T.ratio_rmean_l),'b-','linewidth',2,extend_x(hour_l),extend_y(T.ratio_dmean_l),'r-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_16bd.png'],'png'); 
figure(2); plot(extend_x(hour_l),extend_y(T.density_mean_l),'b-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(2,[rep,'fig_exp2_16e.png'],'png'); 




%%EXPERIMENT
clear 
number=17; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=data2time(T.data(end,:),T.lg); 
day_nb=floor(t2/24/3600); 
disp(['day_nb=',num2str(day_nb)]),
T=load([rep,'exp2_14.mat'],'data','lg'); 
day_l=0:(day_nb-1); 
ratio_rmean_l  = zeros(1,length(day_l)); 
ratio_dmean_l  = zeros(1,length(day_l)); 
density_mean_l = zeros(1,length(day_l)); 
ratio_cum_l    = zeros(1,length(day_l)); 
density_cum_l  = zeros(1,length(day_l)); 
num_rcum_l     = zeros(1,length(day_l)); 
num_dcum_l     = zeros(1,length(day_l)); 
fe=1/180; 
for k=1:length(day_l)
  tk_1=24*3600*day_l(k);
  tk_2=24*3600*day_l(k)+24*3600-1e-8;
  disp(['k=',num2str(k)])
  n1 = floor(tk_1*T.lg.p_fe); 
  n2 = ceil(tk_2*T.lg.p_fe);
         assert(n2>n1+1)
  for n=n1:n2
    if (n+1>0)&(n+1<=size(T.data,1))
      assert(T.data(n+1,T.lg.n) == n+1+653)
    end
    m = n-653;    
    if m <= 0 continue, end
    if m > size(T.data,1) continue, end
    if n == n1     portion = n1+1-tk_1*T.lg.p_fe; 
    elseif n == n2 portion = tk_2*T.lg.p_fe-(n2-1);
    else           portion = 1; 
    end
         assert(0 <= portion);       
         assert(portion <= 1);       
    if T.data(m,T.lg.density) > 0
      ratio_cum_l(k)   += T.data(m,T.lg.density)*T.data(m,T.lg.ratio)*portion; 
      ratio_rmean_l(k) += T.data(m,T.lg.ratio)*portion;
      num_rcum_l(k)    += portion;         
    end
    density_cum_l(k)   += T.data(m,T.lg.density)*portion;          
    num_dcum_l(k)      += portion;         
  end
end
ind = find(density_cum_l>0); 
ratio_dmean_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
ind = find(num_rcum_l > 0); 
ratio_rmean_l(ind) = ratio_rmean_l(ind)./num_rcum_l(ind); 
ind = find(num_rcum_l == 0); 
ratio_rmean_l(ind) = -1; 
density_mean_l = density_cum_l./num_dcum_l; 
save([rep,'exp2_17.mat'],'ratio_dmean_l','ratio_rmean_l','density_mean_l','ratio_cum_l','density_cum_l','num_rcum_l','num_dcum_l','day_l'); 



%%EXPERIMENT
%ratio_rmean_l, ratio_dmean_l, density_mean_l,  
% are the average ratios without density-weighting, with density-weighting and the average density
%ratio_cum_l and density_cum_l are used to compute ratio_dmean_l, 
% the first is the cumulated number of offending cars
% the second is the cumulated number of cars
%num_rcum_l and num_dcum_l are used to account the number samples considered when averaging. 
clear 
number=18; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp2_17.mat']); 
extend_y = @(u)[u u(1)]; 
extend_x = @(u)[u 1+u(end)]; 
figure(1); plot(extend_x(T.day_l),extend_y(T.ratio_rmean_l),'b-','linewidth',2,extend_x(T.day_l),extend_y(T.ratio_dmean_l),'r-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
axis([-Inf Inf -0.1 Inf])
saveas_(1,[rep,'fig_exp2_18bd.png'],'png'); 
figure(2); plot(extend_x(T.day_l),extend_y(T.density_mean_l),'b-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(2,[rep,'fig_exp2_18e.png'],'png'); 




%%EXPERIMENT
%ratio_rmean_l, ratio_dmean_l, density_mean_l,  
% are the average ratios without density-weighting, with density-weighting and the average density
%ratio_cum_l and density_cum_l are used to compute ratio_dmean_l, 
% the first is the cumulated number of offending cars
% the second is the cumulated number of cars
%num_rcum_l and num_dcum_l are used to account the number samples considered when averaging. 
clear 
number=18; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp2_17.mat']); 
extend_y = @(u)[u u(1)]; 
extend_x = @(u)[u 1+u(end)]; 
figure(1); plot(extend_x(T.day_l),extend_y(T.ratio_rmean_l),'b-','linewidth',2,extend_x(T.day_l),extend_y(T.ratio_dmean_l),'r-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
axis([-Inf Inf -0.1 Inf])
saveas_(1,[rep,'fig_exp2_18bd.png'],'png'); 
figure(2); plot(extend_x(T.day_l),extend_y(T.density_mean_l),'b-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(2,[rep,'fig_exp2_18e.png'],'png'); 



%%EXPERIMENT
%ratio_rmean_l, ratio_dmean_l, density_mean_l,  
% are the average ratios without density-weighting, with density-weighting and the average density
%ratio_cum_l and density_cum_l are used to compute ratio_dmean_l, 
% the first is the cumulated number of offending cars
% the second is the cumulated number of cars
%num_rcum_l and num_dcum_l are used to account the number samples considered when averaging. 
clear 
number=19; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp2_17.mat']); 
extend_y = @(u)[u u(1)]; 
extend_x = @(u)[u 1+u(end)]; 
figure(1); plot(T.day_l,T.ratio_rmean_l,'b-','linewidth',2,T.day_l,T.ratio_dmean_l,'r-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
axis([-Inf Inf 0.13 Inf])
saveas_(1,[rep,'fig_exp2_19bd.png'],'png'); 
figure(2); plot(T.day_l,T.density_mean_l,'b-','linewidth',2); 
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(2,[rep,'fig_exp2_19e.png'],'png'); 


%%EXPERIMENT
number=20; 
f=@(a,d,r)a(1)+a(2)*d+a(3)*r+a(4)*d.^2+a(5)*d.*r+a(6)*r.^2; 
cond=@(a)(all(a(1:5)>=0))&(a(3)+2*a(6)>=0); 
tic, N=1e5; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,6).*10.^(6*rand(1,6)); 
  if ~cond(a) continue, end
  D=abs(randn(1,N)).*10.^(6*rand(1,N));
  R=rand(1,N); 
  C=f(a,D,R); 
  dD=1e-5*ones(size(D)); 
  dR=1e-5*ones(size(R)); 
         assert(all(C>=0)); 
  ind=find(f(a,D,R)<1e8); 
         assert(all(f(a,D(ind)+dD(ind),R(ind))>=f(a,D(ind),R(ind)))); 
         assert(all(f(a,D(ind),R(ind)+dR(ind))>=f(a,D(ind),R(ind)))); 
end
ind=find(f(a,D,R+dR)<f(a,D,R));
length(ind); 
i=ind(1); 
d=D(i); r=R(i); 
dr=dR(i); 
f(a,d,r)


%%EXPERIMENT
number=21; 
%process data 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
t1+=30*25*3600; 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=data2time(T.data(1,:),T.lg); 
t2=t1+30*25*3600; 
fe=1/180; 
[data,lg]=split_data4(T.data,T.lg,fe,[t1,t2],[80]);   
save exp21.mat data lg;


%%EXPERIMENT
clear
number=22; 
%process data 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp21.mat','data','lg'); 
time_advance=5*60; duration=20*60; 
na=round(time_advance*T.lg.p_fe); 
nd=round(duration*T.lg.p_fe);
lg=T.lg; 
     assert(lg.n == 1); 
     assert(lg.density == 2); 
     assert(lg.ratio == 3); 
lg.cn = 4; 
lg.ln = 4;      
data=zeros(0,lg.ln); 
for n_=1:length(T.data); 
  n=T.data(n_,T.lg.n); 
     assert(n-n_ == 173); 
  if ~T.data(n_,T.lg.ok) continue, end
  ind_=n-173+(na:na+nd); 
  if max(ind_) > size(T.data,1) break; end
  if all(T.data(ind_,T.lg.ok))
    data=[data; T.data(n_,[T.lg.n T.lg.density T.lg.ratio]), ...
      sum(T.data(ind_,T.lg.density).*T.data(ind_,T.lg.ratio))]; 
  end
end
save exp22.mat data lg; 


%%EXPERIMENT
clear
number=22; 
%process data 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
N=size(T.data,1); 
figure(1); plot(1:N,T.data(:,T.lg.cn),'linewidth',2); 
set(gca,'FontSize',20); 
saveas(1,'exp2_22a.png'); 
figure(2); plot(T.data(:,T.lg.density),T.data(:,T.lg.cn),'.','linewidth',2); 
set(gca,'FontSize',20); 
saveas(2,'exp2_22b.png'); 
figure(3); plot(T.data(:,T.lg.ratio),T.data(:,T.lg.cn),'.','linewidth',2); 
set(gca,'FontSize',20); 
saveas(3,'exp2_22c.png'); 




%%EXPERIMENT
number=23; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
cond=@(a)(all(a(1:5)>=0))&(a(5)+2*a(6)>=0); 
tic, N=1e5; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,6).*10.^(6*rand(1,6)); 
  if ~cond(a) continue, end
  D=abs(randn(1,N)).*10.^(6*rand(1,N));
  O=D.*rand(1,N); 
  C=f(a,D,O); 
  dD=1e-5*ones(size(D)); 
  dO=1e-5*ones(size(O)); 
         assert(all(C>=0)); 
  ind=find((f(a,D,O)<1e8)&(O+dO<=D)); 
         assert(all(f(a,D(ind)+dD(ind),O(ind))>=f(a,D(ind),O(ind)))); 
         assert(all(f(a,D(ind),O(ind)+dO(ind))>=f(a,D(ind),O(ind)))); 
end
ind=find(f(a,D,R+dO)<f(a,D,O));
length(ind); 
i=ind(1); 
d=D(i); o=O(i); 
d_o=dO(i); 
f(a,do)




%%EXPERIMENT
clear
number=24; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
N=size(T.data,1); 
D=T.data(:,T.lg.density); 
O=D.*T.data(:,T.lg.ratio); 
         assert(all( O>=0)); 
C=D.*T.data(:,T.lg.cn); 
X=[ones(N,1) D O D.^2 D.*O O.^2]; 
         f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
         A=rand(1,6)'; 
         ind=ceil(rand(1)*N); 
         assert(X(ind,:)*A,f(A,X(ind,2),X(ind,3)),1e-8)
Y=C; 
M=eye(6); M(6,5)=1; M(6,6)=2; 
         A=randn(6,1); 
         cond=@(a)(all(a(1:5)>=0))&(a(5)+2*a(6)>=0); 
         assert(all(M*A>=0) == cond(A)); 
A=inv(X'*X)*(X'*Y);
all(M*A>=0),
M


%%EXPERIMENT
clear
number=25; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
M=eye(6); M(6,5)=1; M(6,6)=2; 
[A1,A2]=solve1(T.data,T.lg,M); 
all(M*A1>=0),
d=0:1e-2:6; 
o=0:1e-2:6; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
[D,O]=meshgrid(d,o); 
C=f(A1,D,O).*(O<=D);
figure(1); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(1,'fig_exp2_25a.png'); 




%%EXPERIMENT
number=26; 
%test dataset 1
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load([rep,'exp5b.mat'],'data','lg'); 
t1=30*25*3600+data2time(T.data(1,:),T.lg); 
t2=t1+30*25*3600; 
fe=1/180; 
[data,lg]=split_data4(T.data,T.lg,fe,[t1,t2],[80]);   
save exp26.mat data lg;


%EXPERIMENT
clear
number=27
%test dataset 2
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp26.mat','data','lg'); 
time_advance=5*60; duration=20*60; 
na=round(time_advance*T.lg.p_fe); 
nd=round(duration*T.lg.p_fe);
lg=T.lg; 
     assert(lg.n == 1); 
     assert(lg.density == 2); 
     assert(lg.ratio == 3); 
lg.cn = 4; 
lg.ln = 4;      
data=zeros(0,lg.ln); 
for n_=1:length(T.data); 
  n=T.data(n_,T.lg.n); 
     assert(n-n_ == 15173); 
  if ~T.data(n_,T.lg.ok) continue, end
  ind_=n-15173+(na:na+nd); 
  if max(ind_) > size(T.data,1) break; end
  if all(T.data(ind_,T.lg.ok))
    data=[data; T.data(n_,[T.lg.n T.lg.density T.lg.ratio]), ...
      sum(T.data(ind_,T.lg.density).*T.data(ind_,T.lg.ratio))]; 
  end
end
save exp27.mat data lg; 


%%EXPERIMENT
clear
number=28; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
M=eye(6); M(6,5)=1; M(6,6)=2; 
[A1,A2]=solve1(T.data,T.lg,M); 
all(M*A2>=0),
d=0:1e-2:6; 
o=0:1e-2:6; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
[D,O]=meshgrid(d,o); 
C=f(A2,D,O).*(O<=D);
figure(1); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(1,'fig_exp2_28b.png'); 

save exp2_28.mat A1 A2; 



%%EXPERIMENT
clear
number=29; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp27.mat','data','lg'); 
load exp2_28.mat A1 A2; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
err21=0; 
for n=1:size(T.data,1)
  d=T.data(n,T.lg.density); 
  o=T.data(n,T.lg.ratio)*d; 
  c=T.data(n,T.lg.cn); 
  err21 += (c-f(A1,d,o))^2; 
end
err21 = sqrt(err21/size(T.data,1)); 




%%EXPERIMENT
clear
number=30; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
load exp2_28.mat A1 A2; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
err11 = measure1(T.data,T.lg,f,A1), %2.0754
err12 = measure1(T.data,T.lg,f,A2), %2.17
T=load('exp27.mat','data','lg'); 
err21 = measure1(T.data,T.lg,f,A1), %1.2349
err22 = measure1(T.data,T.lg,f,A2), %1.2491




%%EXPERIMENT
clear
number=31; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
load exp2_28.mat A1 A2; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
err11 = measure1(T.data,T.lg,f,A1);
err12 = measure1(T.data,T.lg,f,A2);
D=T.data(:,T.lg.density); 
O=D.*T.data(:,T.lg.ratio); 
N=size(D,1); 
X=[ones(N,1) D O D.^2 D.*O O.^2]; 
C=T.data(:,T.lg.cn); 
sqrt((C-X*A1)'*(C-X*A1)/N)-err11,
sqrt((C-X*A2)'*(C-X*A2)/N)-err12,
T=load('exp27.mat','data','lg'); 
load exp2_28.mat A1 A2; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
err21 = measure1(T.data,T.lg,f,A1);
err22 = measure1(T.data,T.lg,f,A2);
D=T.data(:,T.lg.density); 
O=D.*T.data(:,T.lg.ratio); 
N=size(D,1); 
X=[ones(N,1) D O D.^2 D.*O O.^2]; 
C=T.data(:,T.lg.cn); 
sqrt((C-X*A1)'*(C-X*A1)/N)-err21,
sqrt((C-X*A2)'*(C-X*A2)/N)-err22,


%%EXPERIMENT
clear
number=32; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2+a(7)*d.^3+a(8)*d.^2.*o+a(9)*d.*o.^2+a(10)*o.^3; 
cond=@(a)(all(a(1:5)>=0))&(a(5)+2*a(6)>=0)&(a(7)>=0)&(a(8)>=0)&(3*a(7)+2*a(8)+a(9)>=0)&(a(8)+2*a(9)+3*a(10)>=0); 
tic, N=1e5; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,10).*10.^(6*rand(1,10)); 
  if ~cond(a) continue, end
  D=abs(randn(1,N)).*10.^(6*rand(1,N));
  O=D.*rand(1,N); 
  C=f(a,D,O); 
  dD=1e-5*ones(size(D)); 
  dO=1e-5*ones(size(O)); 
         assert(all(C>=0)); 
  ind=find((f(a,D,O)<1e8)&(O+dO<=D)); 
         assert(all(f(a,D(ind)+dD(ind),O(ind))>=f(a,D(ind),O(ind)))); 
         assert(all(f(a,D(ind),O(ind)+dO(ind))>=f(a,D(ind),O(ind)))); 
end
ind=find(f(a,D,R+dO)<f(a,D,O));
length(ind); 
i=ind(1); 
d=D(i); o=O(i); 
d_o=dO(i); 
f(a,do)



%%EXPERIMENT
clear
number=33; 
f=@(a,d)a(1)+a(2)*d+a(3)*d.^2; 
cond1=@(a)(a(1)>=0)&(a(3)>=0)&(a(2)>=-2*sqrt(a(1)*a(3))); 
delta=@(a)4*a(4)*a(6)-a(5)^2; 
o1=@(a)(-a(5)*a(3)+2*a(4)*a(2))/delta(a); 
d1=@(a)(-a(3)*a(5)+2*a(2)*a(6))/delta(a); 
cond2=@(a)(abs(delta(a))>1e-8)&(~((d1(a)>=o1(a))&(o1(a)>=0))|(a(1)+(a(2)*d1(a)+a(3)*o1(a))/2>=0)); 
cond=@(a)
tic, N=1e7; P=3; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,P).*10.^(6*rand(1,P)); 
  D=abs(randn(1,N)).*10.^(12*rand(1,N)-4);
  assert(cond(a) == all( f(a,D)>=0 )); 
end
ind=find(f(a,D)<0);
length(ind); 
i=ind(1); 
d=D(i); o=O(i); 
d_o=dO(i); 
f(a,do)



%%EXPERIMENT
clear
number=34; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2; 
cond=@(a)(a(1)>=0)&(a(4)>=0)&(a(2)>=-2*sqrt(a(1)*a(4)))&(a(4)+a(5)+a(6)>=0)&(a(2)+a(3)>=-2*sqrt(a(1)*(a(4)+a(5)+a(6)))); 
tic, N=1e7; P=6; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,P).*10.^(6*rand(1,P)); 
  D=abs(randn(1,N)).*10.^(12*rand(1,N)-4);
  O=D.*rand(1,N); 
  assert(cond(a) == all( f(a,D,O)>=0 )); 
end
ind=find(f(a,D)<0);
length(ind); 
i=ind(1); 
d=D(i); o=O(i); 
d_o=dO(i); 
f(a,do)

%%EXPERIMENT
clear
number=35; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2+a(7)*d.^3+a(8)*d.^2.*o+a(9)*d.*o.^2+a(10)*o.^3; 
P=10; 
tic, N=1e5; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,P).*10.^(6*rand(1,10)); 
  D=abs(randn(1,N)).*10.^(6*rand(1,N));
  O=D.*rand(1,N); 
  dD=1e-5*ones(size(D)); 
  dO=1e-5*ones(size(O)); 
  if ~all(f(a,D,D)>=0) 
    continue, 
  end
  if ~all(f(a,D,zeros(size(D)))>=0) 
    continue, 
  end
  ind=find((f(a,D,O)<1e8)); 
  if ~all(f(a,D(ind)+dD(ind),O(ind))>=f(a,D(ind),O(ind))) 
    continue, 
  end
  C=f(a,D,O); 
         assert(all(C>=0)); 
end


%%EXPERIMENT
clear
number=36; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2+a(7)*d.^3+a(8)*d.^2.*o+a(9)*d.*o.^2+a(10)*o.^3; 
cond1=@(a)all(a([1:5 7 8])>=0); 
cond2=@(a)(a(5)+2*a(6)>=0)&(2*a(5)+3*a(7)+a(9)>=0)&...
  (2*a(8)+a(9)>=0)&(a(7)+a(8)+a(9)+a(10)>=0)&...
  (a(8)+2*a(9)+3*a(10)>=0)&(a(8)+a(9)>=0); 
cond=@(a)cond1(a)&cond2(a); 
tic, N=1e5; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,10).*10.^(6*rand(1,10)); 
  if ~cond(a) continue, end
  D=abs(randn(1,N)).*10.^(6*rand(1,N));
  O=D.*rand(1,N); 
  C=f(a,D,O); 
  dD=1e-5*ones(size(D)); 
  dO=1e-5*ones(size(O)); 
         assert(all(C>=0)); 
  ind=find((f(a,D,O)<1e8)&(O+dO<=D)); 
         assert(all(f(a,D(ind)+dD(ind),O(ind))>=f(a,D(ind),O(ind)))); 
         assert(all(f(a,D(ind),O(ind)+dO(ind))>=f(a,D(ind),O(ind)))); 
end
ind=find(f(a,D,R+dO)<f(a,D,O));
length(ind); 
i=ind(1); 
d=D(i); o=O(i); 
d_o=dO(i); 
f(a,do)


%%EXPERIMENT
clear
number=37; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
[A1,A2,A3,M]=solve2(T.data,T.lg); 
%all(M*A3>=0),
%all(A3>=0),
d=0:1e-2:6; 
o=0:1e-2:6; 
f=@(a,d,o)a(1)+a(2)*d+a(3)*o+a(4)*d.^2+a(5)*d.*o+a(6)*o.^2+a(7)*d.^3+a(8)*d.^2.*o+a(9)*d.*o.^2+a(10)*o.^3; 
[D,O]=meshgrid(d,o); 
C=f(A1,D,O).*(O<=D);
figure(1); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(1,'fig_exp2_37a.png'); 
C=f(A2,D,O).*(O<=D);
figure(2); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(2,'fig_exp2_37b.png'); 
C=f(A3,D,O).*(O<=D);
figure(3); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(3,'fig_exp2_37c.png'); 
err37_11 = measure1(T.data,T.lg,f,A1), %2.0166
err37_12 = measure1(T.data,T.lg,f,A2), %2.1700
err37_13 = measure1(T.data,T.lg,f,A3), %2.1700

save exp2_37.mat A1 A2 A3 M err37_11 err37_12 err37_13; 
T=load('exp27.mat','data','lg'); 

err37_21 = measure1(T.data,T.lg,f,A1), %1.2314
err37_22 = measure1(T.data,T.lg,f,A2), %1.2491
err37_23 = measure1(T.data,T.lg,f,A3), %1.2491


%%EXPERIMENT
clear
number=38; 
alpha=0.5; 
f=@(a,d,o)a(1)+a(2)*d.^alpha+a(3)*o.^alpha+a(4)*d.^(2*alpha)+a(5)*d.^alpha.*o.^alpha+a(6)*o.^(2*alpha)+...
  a(7)*d.^(3*alpha)+a(8)*d.^(2*alpha).*o.^alpha+a(9)*d.^alpha.*o.^(2*alpha)+a(10)*o.^(3*alpha); 
cond1=@(a)all(a([1:5 7 8])>=0); 
cond2=@(a)(a(5)+2*a(6)>=0)&(2*a(5)+3*a(7)+a(9)>=0)&...
  (a(7)+a(8)+a(9)+a(10)>=0)&...
  (a(8)+2*a(9)+3*a(10)>=0)&(a(8)+a(9)>=0)&(a(4)+a(5)+a(6)>=0); 
cond=@(a)cond1(a)&cond2(a); 
tic, N=1e5; 
for k=1:1e8
  if toc>5*60 
    disp(['k=',num2str(k)]),
    tic,
  end
  a=randn(1,10).*10.^(6*rand(1,10)); 
  if ~cond(a) continue, end
  D=abs(randn(1,N)).*10.^(6*rand(1,N));
  O=D.*rand(1,N); 
  C=f(a,D,O); 
  dD=1e-5*ones(size(D)); 
  dO=1e-5*ones(size(O)); 
         assert(all(C>=0)); 
  ind=find((f(a,D,O)<1e8)&(O+dO<=D)); 
         assert(all(f(a,D(ind)+dD(ind),O(ind))>=f(a,D(ind),O(ind)))); 
         assert(all(f(a,D(ind),O(ind)+dO(ind))>=f(a,D(ind),O(ind)))); 
end
ind=find(f(a,D,R+dO)<f(a,D,O));
length(ind); 
i=ind(1); 
d=D(i); o=O(i); 
d_o=dO(i); 
f(a,do)


%%EXPERIMENT
clear
number=39; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
alpha=0.5; 
[A1,A2,A3,M]=solve3(T.data,T.lg,alpha); 
f=@(a,d,o)a(1)+a(2)*d.^alpha+a(3)*o.^alpha+a(4)*d.^(2*alpha)+a(5)*d.^alpha.*o.^alpha+a(6)*o.^(2*alpha)+...
  a(7)*d.^(3*alpha)+a(8)*d.^(2*alpha).*o.^alpha+a(9)*d.^alpha.*o.^(2*alpha)+a(10)*o.^(3*alpha); 
%all(M*A3>=0),
%all(A3>=0),
d=0:1e-2:6; 
o=0:1e-2:6; 
[D,O]=meshgrid(d,o); 
C=f(A1,D,O).*(O<=D);
figure(1); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(1,'fig_exp2_39a.png'); 
C=f(A2,D,O).*(O<=D);
figure(2); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(2,'fig_exp2_39b.png'); 
C=f(A3,D,O).*(O<=D);
figure(3); ch=contour(D,O,C,'linewidth',2); 
clabel(round(ch)); 
set(gca,'fontsize',20); 
saveas(3,'fig_exp2_39c.png'); 
err39_11 = measure1(T.data,T.lg,f,A1), %6.8014
err39_12 = measure1(T.data,T.lg,f,A2), %2.4339
err39_13 = measure1(T.data,T.lg,f,A3), %2.2273

T=load('exp27.mat','data','lg'); 

err39_21 = measure1(T.data,T.lg,f,A1), %1.72
err39_22 = measure1(T.data,T.lg,f,A2), %1.35
err39_23 = measure1(T.data,T.lg,f,A3), %1.32
save exp2_39.mat A1 A2 A3 M err39_11 err39_12 err39_13 err39_21 err39_22 err39_23; 


%%EXPERIMENT
clear
number=40; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
T2=load('exp27.mat','data','lg'); 
alpha_l=0.2:0.05:3;
lg.err_1=1; lg.err_2=2; lg.ln=2;  
err_l=zeros(length(alpha_l),lg.ln); 
f=@(a,d,o,alpha)a(1)+a(2)*d.^alpha+a(3)*o.^alpha+a(4)*d.^(2*alpha)+a(5)*d.^alpha.*o.^alpha+a(6)*o.^(2*alpha)+...
  a(7)*d.^(3*alpha)+a(8)*d.^(2*alpha).*o.^alpha+a(9)*d.^alpha.*o.^(2*alpha)+a(10)*o.^(3*alpha); 
for alpha_=1:length(alpha_l)
  alpha=alpha_l(alpha_); 
  disp(['alpha=',num2str(alpha)]),
  N=size(T.data,1); 
  D=T.data(:,T.lg.density).^alpha; 
  O=D.*T.data(:,T.lg.ratio); 
         assert(all( O>=0));
  O=O.^alpha;          
  C=T.data(:,T.lg.cn); 
  X=[ones(N,1) D O D.^2 D.*O O.^2 D.^3 D.^2.*O D.*O.^2 O.^3]; 
  Y=C; 
  A=inv(X'*X)*(X'*Y);
  err_l(alpha_,lg.err_2) = measure2(T2.data,T2.lg,f,A,alpha); 
  err_l(alpha_,lg.err_1) = measure2(T.data,T.lg,f,A,alpha); 
end
ind_alpha=find(alpha_l<1.7); 
figure(1); plot(alpha_l(ind_alpha),err_l(ind_alpha,lg.err_1),'b-','linewidth',2,...
  alpha_l(ind_alpha),err_l(ind_alpha,lg.err_2),'r-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(1,'fig_exp2_40.png'); 
save exp2_40.mat  




%%EXPERIMENT
clear 
%instead of averaging ratios, it is d*r which is averaged. 
number=41; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
limit_l=[30 50 80 90 110 130]; 
ratio_mean_l=zeros(1,length(limit_l)); 
ratio_mean2_l=zeros(1,length(limit_l)); 
ratio_cum_l=zeros(1,length(limit_l)); 
density_cum_l=zeros(1,length(limit_l)); 
T=load([rep,'exp5b.mat'],'data','lg'); 
fe=1/180; 
for k=1:length(limit_l)
  disp(['k=',num2str(k)])
  [data,lg]=split_data3(T.data,T.lg,fe,[],limit_l(k));
  ind = find(data(:,lg.density)>0);
  ratio_mean_l(k) = mean(data(ind,lg.ratio)); 
  [ratio_cum_l(k),density_cum_l(k)] = dr_mean(data(:,lg.density),data(:,lg.ratio)); 
end
ind = find(density_cum_l>0); 
ratio_mean2_l(ind) = ratio_cum_l(ind)./density_cum_l(ind); 
figure(1);
hold on; 
bar(limit_l,ratio_mean_l,0.3); 
bar(limit_l+3,ratio_mean2_l,0.3); 
hold off
set(gca, 'FontSize', 20, 'fontName','Times'); 
saveas_(1,[rep,'fig_exp2_41.png'],'png'); 


%%EXPERIMENT
clear
number=42; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg2
rep=['../dataset/']; 
T=load('exp22.mat','data','lg'); 
T2=load('exp27.mat','data','lg'); 
N=size(T.data,1); 
D=T.data(:,T.lg.density);
O=T.data(:,T.lg.ratio).*D+0.1*randn(N,1); 
D += 0.1*randn(N,1); 
figure(1); 
plot(D,O,'.',[0 max(D)],[0 0],'k-',[0 max(D)],[0 max(D)],'k-'); 
set(gca,'FontSize',20); 
axis([-0.5 Inf -0.5 Inf])
saveas(1,'fig_exp2_42.png'); 
figure(1); 
plot(D,O,'.',[0 max(D)],[0 0],'k-',[0 max(D)],[0 max(D)],'k-'); 
set(gca,'FontSize',20); 
axis([-0.5 6.5 -0.5 6.5])
saveas(1,'fig_exp2_42b.png'); 
