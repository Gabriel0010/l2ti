function v_data2time()
  lg.year=1; 
  lg.month=2; 
  lg.day=3; 
  lg.hour=4; 
  lg.minute=5; 
  lg.ln=5; 
  data=[2021,1,1,8,45]; 
  t=data2time(data,lg); 
       assert(abs(t-8*3600-45*60)<1e-10),
  data=[2021,1,1,20,30]; 
  t=data2time(data,lg);
       assert(abs(t-20*3600-30*60)<1e-10),
       
end