function [dr,d]=dr_mean(d_l,r_l)
  assert(all(size(d_l)==size(r_l))); 
  ind=find(d_l>0); 
  if isempty(ind) 
    dr=0; d=0; 
    return; 
  else 
    dr=sum(d_l(ind).*r_l(ind)); 
    d=sum(d_l(ind)); 
  end
end