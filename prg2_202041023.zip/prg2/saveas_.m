function saveas_(num,name,ext)
  delete(name); 
         assert(~isfile(name)); 
  saveas(num,name,ext); 
         assert(isfile(name)); 
  disp([name,' is saved ']),       
end