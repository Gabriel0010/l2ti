function v_read_file1()
  file_name='JDSR23.csv'; 
  rep=['../dataset/']; 
  [data,lg]=read_file1([rep,file_name],[1 2]);
  %2021-01-01T08:42;47.744946 -2.7685134;106;90
         assert(size(data,1) == 1); 
         assert(data(1,lg.year) == 2021); 
         assert(data(1,lg.month) == 1); 
         assert(data(1,lg.day) == 1); 
         assert(data(1,lg.hour) == 8); 
         assert(data(1,lg.minute) == 42); 
  [data,lg]=read_file1([rep,file_name],[65 66]);
  %2021-01-01T16:12;49.306873 1.1587267;64;80
         assert(size(data,1) == 1); 
         assert(data(1,lg.year) == 2021); 
         assert(data(1,lg.month) == 1); 
         assert(data(1,lg.day) == 1); 
         assert(data(1,lg.hour) == 16); 
         assert(data(1,lg.minute) == 12); 
  [data,lg]=read_file1([rep,file_name],[5095655 5095656]);
  %2021-11-13T18:41;50.54957 2.100355;73;80       
         assert(size(data,1)      == 1); 
         assert(data(1,lg.year)   == 2021); 
         assert(data(1,lg.month)  == 11); 
         assert(data(1,lg.day)    == 13); 
         assert(data(1,lg.hour)   == 18); 
         assert(data(1,lg.minute) == 41); 
  disp('v_read_file1'),
end