% NON-NEGATIVE LEAST SQUARES
% Code written according to NNLS algorithmon Wikipedia
% https://en.wikipedia.org/wiki/Non-negative_least_squares#Algorithms

% Input matrix, vector and tolerance
A = [0.0372    0.2869
     0.6861    0.7071
     0.6233    0.6245
     0.6344    0.6170];
y = [0.8587
     0.1781
     0.0747
     0.8405];
E=0.0000001;

% Assigning m and n for A(mxn)
m=size(A, 1);
n=size(A, 2);

% Set P = ∅
P=[];

% Set R = {1, ..., n}
R=[];
for i=1:n
	R=[R, i];
end	

% Set x to an all-zero vector of dimension n
x=zeros(n, 1);

% Set w = Aᵀ(y − Ax)
w=A'*(y-A*x);

% Main loop:
while ~isempty(R) && max(w)>E
	% Let j in R be the index of max(w) in w
	[nr, j]=max(w);

	% Add j to P
	P=[P, j];

	% Remove j from R
	R(find(R(:)==j))=[];

	% Let AP be A restricted to the variables included in P
	Ap=[];	
	for i=P
		Ap=[Ap, A(:, i)];
	end

	%Let s be vector of same length as x. Let sP denote the sub-vector with indexes from P, and let sR denote the sub-vector with indexes from R.

	% Set sP = ((AP)ᵀ AP)−1 (AP)ᵀy
	if(~isempty(Ap))
			sP=pinv(Ap'*Ap)*Ap'*y;
		else
			sP=[];
	end

	% Set sR to zero
	sR=zeros(length(R), 1);

	% Setting up vector s
	s=zeros(size(A, 2), 1);
	count=1;
	for i=P
		s(i)=sP(count);
		count=count+1;
	end
	count=1;
	for i=R
		s(i)=sR(count);
		count=count+1;
	end

	% Inner loop
	while min(sP)<=0

		% Let alpha=-min(s(i)/(x(i)-s(i)) for i in P where s(i)<=0
		for z=1:length(P)
			idx=P(z);
			if(s(idx)<=0)
				alpha=x(idx)/(x(idx)-s(idx));
				break
			end
		end	
		for i=P
			if(s(i)<=0)
				if(alpha>x(i)/(x(i)-s(i)))
					alpha=x(i)/(x(i)-s(i));
				end	
			end
		end
		alpha=-alpha

		% Set x to x + alpha(s - x)	
		x=x+alpha*(s-x);

		% Move to R all indices j in P such that x(j) = 0
		for i=P
			if(x(i)==0)
				P(find(P(:)==i))=[];
				R=[R, i];
			end
		end

		% Updating Ap
		Ap=[]
		for i=P
			Ap=[Ap, A(:, i)];
		end

		% Set sP = ((AP)ᵀ AP)−1 (AP)ᵀy
		if(~isempty(Ap))
			sP=pinv(Ap'*Ap)*Ap'*y;
		else
			sP=[];
		end

		% Set sR to zero
		sR=zeros(length(R), 1);

	end

	% Set x to s
	x=s;

	% Set w to Aᵀ(y − Ax)
	w=A'*(y-A*x);

end