function [A1,A2,A3,M]=solve3(data,lg,alpha); 
%%A1 is the OLS solution 
%%A2 is the non-negative OLS solution with M=Id
%%A3 is the non-negative OLS solution with M
         assert(ismember(alpha,[0.5 1])); 
  N=size(data,1); 
  D=data(:,lg.density).^alpha; 
  O=D.*data(:,lg.ratio); 
         assert(all( O>=0));
  O=O.^alpha;          
  C=data(:,lg.cn); 
  X=[ones(N,1) D O D.^2 D.*O O.^2 D.^3 D.^2.*O D.*O.^2 O.^3]; 
  v_X(X); 
  Y=C; 
  M=c_M(); 
  disp('ok'),
  v_M(M); 
  A1=inv(X'*X)*(X'*Y);
  v_nnls1();
  B=lsqnonneg1(X,Y);
  A2=B; 
  B=lsqnonneg1(X*pinv(M),Y);
  A3=pinv(M)*B; 
end


function M=c_M(); 
  M=zeros(13,10); 
  M(1,1)=1; 
  M(2,2)=1; 
  M(3,3)=1; 
  M(4,4)=1;
  M(5,4:6)=[1 1 1]; 
  M(6,[5 7 9])=[2 3 1];   
  M(7,5)=1; 
  M(8,5:6)=[1 2]; 
  M(9,7)=1; 
  M(10,7:10)=[1 1 1 1];
  M(11,8)=1; 
  M(12,[8 9])=[1 1]; 
  M(13,[8 9 10])=[1 2 3]; 
end


function v_M(M)
  tic,
  k=1; 
  while(1)
    if toc>30 
      disp(['k=',num2str(k)]),
      break; 
    end
    k += 1; 
    A=randn(10,1);
    cond1=@(a)all(a([1:5 7 8])>=0); 
    cond2=@(a)(a(5)+2*a(6)>=0)&(2*a(5)+3*a(7)+a(9)>=0)&...
      (a(7)+a(8)+a(9)+a(10)>=0)&...
      (a(8)+2*a(9)+3*a(10)>=0)&(a(8)+a(9)>=0)&(a(4)+a(5)+a(6)>=0); 
    cond=@(a)cond1(a)&cond2(a); 
         assert(all(M*A>=0) == cond(A)); 
  end
  disp('v_M'),
end


function v_X(X)
  alpha=0.5; 
  f=@(a,d,o)a(1)+a(2)*d.^alpha+a(3)*o.^alpha+a(4)*d.^(2*alpha)+a(5)*d.^alpha.*o.^alpha+a(6)*o.^(2*alpha)+...
  a(7)*d.^(3*alpha)+a(8)*d.^(2*alpha).*o.^alpha+a(9)*d.^alpha.*o.^(2*alpha)+a(10)*o.^(3*alpha); 
  A=rand(1,10)'; 
  N=size(X,1); 
  ind=ceil(rand(1)*N); 
         assert(X(ind,:)*A,f(A,X(ind,2),X(ind,3)),1e-8)
  disp('v_X'),        
end


function v_nnls1()
A = [0.0372    0.2869
     0.6861    0.7071
     0.6233    0.6245
     0.6344    0.6170];
y = [0.8587
     0.1781
     0.0747
     0.8405];
E=0.0000001;
  x = lsqnonneg1 (A, y); %  0 0.6929
         assert(all(x>=0)); 
         assert(all(abs(x-[0;0.692934397130293])<E*10)); 
  J=(A*x-y)'*(A*x-y);
  tic,
  for k=1:1  %1e8
    if toc>5*60 
      disp(['k=',num2str(k)]),
      tic,
    end
    x=rand(2,1).*10.^(randn(2,1)*7); 
    J1=(A*x-y)'*(A*x-y);
         assert(J1>=J-E); 
  end
end

