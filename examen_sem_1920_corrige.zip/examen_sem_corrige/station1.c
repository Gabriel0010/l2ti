//#include "../test_erreur.h"
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>


VOID  test_erreur(LPCTSTR msg_etape);

INT main(INT argc,char *argv[]) {
  if (2!=argc) {printf("erreur\n"); getchar(); return -1; }
  printf("station numero %d\n",atoi(argv[1]));
  getchar(); 
  return 0; 
}