

//#include "../test_erreur.h"
#include <string.h>
#include <stdio.h>
#include <Windows.h>
//#include <stdlib.h>

VOID  test_erreur(LPCTSTR msg_etape);




INT main(INT argc, CHAR * argv[]) {
  CHAR nom_exec[50],messEnv[50];
  int nbSta;
  SECURITY_ATTRIBUTES saPipe[3]; 
  STARTUPINFO startup[3];
  PROCESS_INFORMATION pi[3];
  HANDLE hP,hPipeDest[3],hPipeSrc[3];
  DWORD nbW;
  if (!DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),&hP,0,TRUE,DUPLICATE_SAME_ACCESS))
    test_erreur("centre:main:DuplicateHandle"); 
  for (nbSta=1;nbSta<4;nbSta++) {
    saPipe[nbSta-1].bInheritHandle=TRUE;
    saPipe[nbSta-1].lpSecurityDescriptor=NULL;
    saPipe[nbSta-1].nLength=sizeof(saPipe[nbSta-1]);
    if (!CreatePipe(&hPipeDest[nbSta-1],&hPipeSrc[nbSta-1],&saPipe[nbSta-1],0)) test_erreur("centre:main:CreatePipe"); 
    memset(&startup[nbSta-1],0,sizeof(startup[nbSta-1]));
    startup[nbSta-1].cb=sizeof(startup[nbSta-1]);
    sprintf_s(nom_exec,sizeof(nom_exec),"ex2 %d %d %d",nbSta,hP,hPipeDest[nbSta-1]);
    if (!CreateProcess(NULL,nom_exec,NULL,NULL,TRUE, CREATE_NEW_CONSOLE,NULL,NULL,&startup[nbSta-1],&pi[nbSta-1]))
      test_erreur("centre:main:CreateProcess"); 
    if (!CloseHandle(pi[nbSta-1].hProcess)) test_erreur("centre:main:CloseHandle 1"); 
    if (!CloseHandle(pi[nbSta-1].hThread)) test_erreur("centre:main:CloseHandle 1"); 
    if (!CloseHandle(hPipeDest[nbSta-1])) test_erreur("centre:main:CloseHandle 3"); 
  }
  if (!CloseHandle(hP)) test_erreur("centre:main:CloseHandle 2");
  for (nbSta=1;nbSta<4;nbSta++) {
    sprintf_s(messEnv,sizeof(messEnv),"bonjour station %d",1+nbSta);
    if (!WriteFile(hPipeSrc[nbSta-1],messEnv,1+strlen(messEnv),&nbW,NULL)) test_erreur("centre:main:WriteFile"); 
  }
  
  for (nbSta=1;nbSta<4;nbSta++) {
    if (!CloseHandle(hPipeSrc[nbSta-1])) test_erreur("centre:main:CloseHandle 4"); 
  }
  getchar(); 
  return 0; 
}
