//#include "../test_erreur.h"
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>

typedef enum {
  PRENDRE=0,
  RENDRE=1,
  FIN=3,
} ACTION;


VOID  test_erreur(LPCTSTR msg_etape);

INT main(INT argc,char *argv[]) {
  HANDLE hP,hPipeDest; 
  ACTION action; 
  DWORD nbR;
  if (4!=argc) {printf("erreur\n"); getchar(); return -1; }
  printf("station numero %d\n",atoi(argv[1]));
  hP=(HANDLE)atoi(argv[2]); 
  hPipeDest=(HANDLE)atoi(argv[3]); 
  while(TRUE) {
    if (!ReadFile(hPipeDest,&action,sizeof(action),&nbR,NULL)) test_erreur("centre:main:ReadFile"); 
    if (PRENDRE==action) printf("Un velib vient de quitter cette station\n"); 
    if (RENDRE==action) printf("Un velib vient de revenir a cette station\n"); 
    if (FIN==action) break; 
  }
  //printf("%s\n",messRecu);
  if (WAIT_OBJECT_0!=WaitForSingleObject(hP,INFINITE))
    test_erreur("station:main:WaitForSingleObject");
  if (!CloseHandle(hPipeDest))
    test_erreur("station:main:CloseHandle");
  if (!CloseHandle(hP))
    test_erreur("station:main:CloseHandle");
  return 0; 
}