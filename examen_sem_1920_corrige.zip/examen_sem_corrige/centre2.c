

//#include "../test_erreur.h"
#include <string.h>
#include <stdio.h>
#include <Windows.h>
//#include <stdlib.h>

VOID  test_erreur(LPCTSTR msg_etape);

INT main(INT argc, CHAR * argv[]) {
  CHAR nom_exec[50]; 
  int nbSta;
  STARTUPINFO startup[3];
  PROCESS_INFORMATION pi[3];
  HANDLE hP;
  if (!DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),&hP,0,TRUE,DUPLICATE_SAME_ACCESS))
    test_erreur("centre:main:DuplicateHandle"); 
  //printf("hP=%p\n",hP);
  for (nbSta=0;nbSta<3;nbSta++) {
    //printf("sizeof startup[nbSta]=%d\n",sizeof(startup[nbSta]));
    memset(&startup[nbSta],0,sizeof(startup[nbSta]));
    startup[nbSta].cb=sizeof(startup[nbSta]);
    sprintf_s(nom_exec,sizeof(nom_exec),"ex2 %d %d",1+nbSta,hP);
    if (!CreateProcess(NULL,nom_exec,NULL,NULL,TRUE, CREATE_NEW_CONSOLE,NULL,NULL,&startup[nbSta],&pi[nbSta]))
      test_erreur("centre:main:CreateProcess"); 
    if (!CloseHandle(pi[nbSta].hProcess)) test_erreur("centre:main:CloseHandle 1"); 
    if (!CloseHandle(pi[nbSta].hThread)) test_erreur("centre:main:CloseHandle 1"); 
  }
  if (!CloseHandle(hP)) test_erreur("centre:main:CloseHandle 2");
  getchar(); 
  return 0; 
}
