

//#include "../test_erreur.h"
#include <string.h>
#include <stdio.h>
#include <Windows.h>
//#include <stdlib.h>

typedef enum {
  PRENDRE=0,
  RENDRE=1,
  FIN=3,
} ACTION;



VOID  test_erreur(LPCTSTR msg_etape);

VOID prendre_velib(INT numSta,HANDLE hPipe[3]);
VOID rendre_velib(INT numSta,HANDLE hPipe[3]);
VOID terminer(HANDLE hPipe[3]);

INT main(INT argc, CHAR * argv[]) {
  CHAR nom_exec[50];
  int nbSta;
  SECURITY_ATTRIBUTES saPipe[3]; 
  STARTUPINFO startup[3];
  PROCESS_INFORMATION pi[3];
  HANDLE hP,hPipeDest[3],hPipeSrc[3];
  if (!DuplicateHandle(GetCurrentProcess(),GetCurrentProcess(),GetCurrentProcess(),&hP,0,TRUE,DUPLICATE_SAME_ACCESS))
    test_erreur("centre:main:DuplicateHandle"); 
  for (nbSta=1;nbSta<4;nbSta++) {
    saPipe[nbSta-1].bInheritHandle=TRUE;
    saPipe[nbSta-1].lpSecurityDescriptor=NULL;
    saPipe[nbSta-1].nLength=sizeof(saPipe[nbSta-1]);
    if (!CreatePipe(&hPipeDest[nbSta-1],&hPipeSrc[nbSta-1],&saPipe[nbSta-1],0)) test_erreur("centre:main:CreatePipe"); 
    memset(&startup[nbSta-1],0,sizeof(startup[nbSta-1]));
    startup[nbSta-1].cb=sizeof(startup[nbSta-1]);
    sprintf_s(nom_exec,sizeof(nom_exec),"ex2 %d %d %d",nbSta,hP,hPipeDest[nbSta-1]);
    if (!CreateProcess(NULL,nom_exec,NULL,NULL,TRUE, CREATE_NEW_CONSOLE,NULL,NULL,&startup[nbSta-1],&pi[nbSta-1]))
      test_erreur("centre:main:CreateProcess"); 
    if (!CloseHandle(pi[nbSta-1].hProcess)) test_erreur("centre:main:CloseHandle 1"); 
    if (!CloseHandle(pi[nbSta-1].hThread)) test_erreur("centre:main:CloseHandle 1"); 
    if (!CloseHandle(hPipeDest[nbSta-1])) test_erreur("centre:main:CloseHandle 3"); 
  }
  if (!CloseHandle(hP)) test_erreur("centre:main:CloseHandle 2");
  prendre_velib(1,hPipeSrc);
  rendre_velib(2,hPipeSrc);
  prendre_velib(2,hPipeSrc);
  terminer(hPipeSrc);
  getchar(); 
  return 0; 
}



VOID prendre_velib(INT numSta,HANDLE hPipe[3]) 
{
  DWORD nbW;
  ACTION action=PRENDRE; 
  if (!WriteFile(hPipe[numSta-1],&action,sizeof(action),&nbW,NULL)) test_erreur("centre:main:WriteFile"); 
}
VOID rendre_velib(INT numSta,HANDLE hPipe[3])
{
  DWORD nbW;
  ACTION action=RENDRE; 
  if (!WriteFile(hPipe[numSta-1],&action,sizeof(action),&nbW,NULL)) test_erreur("centre:main:WriteFile"); 
}
VOID terminer(HANDLE hPipe[3])
{
  DWORD nbW;
  ACTION action=FIN; 
  INT numSta;
  for(numSta=1;numSta<4;numSta++) {
    if (!WriteFile(hPipe[numSta-1],&action,sizeof(action),&nbW,NULL)) test_erreur("centre:main:WriteFile"); 
  }
  Sleep(50);
  for(numSta=1;numSta<4;numSta++) {
    if (!CloseHandle(hPipe[numSta-1])) test_erreur("centre:terminer:CloseHandle 1"); 
  }
}
