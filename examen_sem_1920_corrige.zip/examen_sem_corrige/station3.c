//#include "../test_erreur.h"
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>


VOID  test_erreur(LPCTSTR msg_etape);

INT main(INT argc,char *argv[]) {
  HANDLE hP,hPipeDest; 
  CHAR messRecu[50]; 
  DWORD nbR;
  //printf("argc=%d\n",argc);
  if (4!=argc) {printf("erreur\n"); getchar(); return -1; }
  printf("station numero %d\n",atoi(argv[1]));
  hP=(HANDLE)atoi(argv[2]); 
  hPipeDest=(HANDLE)atoi(argv[3]); 
  if (!ReadFile(hPipeDest,messRecu,sizeof(messRecu),&nbR,NULL)) test_erreur("centre:main:ReadFile"); 
  printf("%s\n",messRecu);

  //printf("HANDLE %p\n",hP);
  if (WAIT_OBJECT_0!=WaitForSingleObject(hP,INFINITE))
    test_erreur("station:main:WaitForSingleObject");
  if (!CloseHandle(hPipeDest))
    test_erreur("station:main:CloseHandle");
  if (!CloseHandle(hP))
    test_erreur("station:main:CloseHandle");
  return 0; 
}