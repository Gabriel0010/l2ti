//#include "../test_erreur.h"
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>


VOID  test_erreur(LPCTSTR msg_etape);

INT main(INT argc,char *argv[]) {
  HANDLE hP; 
  //printf("argc=%d\n",argc);
  if (3!=argc) {printf("erreur\n"); getchar(); return -1; }
  printf("station numero %d\n",atoi(argv[1]));
  hP=(HANDLE)atoi(argv[2]); 
  //printf("HANDLE %p\n",hP);
  if (WAIT_OBJECT_0!=WaitForSingleObject(hP,INFINITE))
    test_erreur("station:main:WaitForSingleObject");
  if (!CloseHandle(hP))
    test_erreur("station:main:CloseHandle");
  return 0; 
}