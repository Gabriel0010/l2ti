#include "objet.hpp"

class LienObjet
{
private: 
  Objet * pobjet; 
  LienObjet * pnext;
public:
  LienObjet(Objet * pobj):pobjet(pobj),pnext(NULL){}
  ~LienObjet() {}
	LienObjet * getNext() {return pnext;}
  void setNext(LienObjet * ptr){pnext=ptr;}
	Objet * getObjet() {return pobjet;}
};

class ListeObjet
{
private:
  LienObjet *pdeb;
  LienObjet *pfin;
public:
  ListeObjet():pdeb(NULL),pfin(NULL){}
  ~ListeObjet() {detruireListe();}
  void detruireListe();
  void insererDebutListe(Objet * pobj);
  void insererFinListe(Objet * pobj);
  void ecrireListe();

};