#include "vehicules.hpp"
#include <string.h>

void Vehicule::lire(istream & fluxIn)
{
  char typeVehicule[30];
  //cout << "puissance vitesse couleur " << endl;
  fluxIn >> puissance >> vitesse >> couleur >>typeVehicule;
  if (0==strcmp(typeVehicule,"voiture")) pvehicule=new Voiture;
  else if (0==strcmp(typeVehicule,"car")) pvehicule=new Car;
  else if (0==strcmp(typeVehicule,"camion")) pvehicule=new Camion;
  else pvehicule=NULL;
  if (NULL!=pvehicule) pvehicule->lire(fluxIn);
}

void Vehicule::lire(void)
{
  //cout << "puissance vitesse couleur " << endl;
  char typeVehicule[30];
  cin >> puissance >> vitesse >> couleur >> typeVehicule;
  if (0==strcmp(typeVehicule,"voiture")) pvehicule=new Voiture;
  else if (0==strcmp(typeVehicule,"car")) pvehicule=new Car;
  else if (0==strcmp(typeVehicule,"camion")) pvehicule=new Camion;
  else pvehicule=NULL;
  if (NULL!=pvehicule) pvehicule->lire();
}

void Vehicule::ecrire(ostream & fluxOut)
{
  fluxOut << "vehicule de puissance " << puissance << " de vitesse " <<  vitesse << " et de couleur " << couleur ;
  pvehicule->ecrire(fluxOut);  
  fluxOut  << endl;
}
void Vehicule::ecrire(void)
{
  cout << "vehicule de puissance " << puissance << " de vitesse " <<  vitesse << " et de couleur " << couleur ;
  pvehicule->ecrire();
  cout  << endl;
}

void Voiture::lire(istream & fluxIn)
{
//  cout << "Voiture dont le nombre de places est " ;
  fluxIn >> nb_places;
}
void Voiture::lire(void)
{
//  cout << "Voiture dont le nombre de places est " ;
  cin >> nb_places;
}
void Voiture::ecrire(ostream & fluxOut)
{
  fluxOut << "Voiture " ;
  fluxOut << nb_places;
}
void Voiture::ecrire(void)
{
  cout << "Voiture " ;
  cout << nb_places ;
}

void Car::lire(istream & fluxIn)
{
//  cout << "Car dont le nombre de passagers est " ;
  fluxIn >> nb_passagers;
}
void Car::lire(void)
{
//  cout << "Car dont le nombre de passagers est " ;
  cin >> nb_passagers;
}
void Car::ecrire(ostream & fluxOut)
{
  fluxOut << "Car " ;
  fluxOut << nb_passagers ;
}
void Car::ecrire(void)
{
  cout << "Car " ;
  cout << nb_passagers ;
}

void Camion::lire(istream & fluxIn)
{
  //cout << "Camion dont le poids maximum est " ;
  fluxIn >> poids;
}
void Camion::lire()
{
  //cout << "Camion dont le poids maximum est " ;
  cin >> poids;
}
void Camion::ecrire(ostream & fluxOut)
{
  fluxOut << "Camion " ;
  fluxOut << poids ;
}
void Camion::ecrire()
{
  cout << "Camion " ;
  cout << poids ;
}