using namespace std;

#include "listeobj.hpp"


class Lesvehicules
{
public:
  virtual void lire(istream & fluxIn)=0;
  virtual void lire(void)=0;
  virtual void ecrire(ostream & fluxOut)=0;
  virtual void ecrire(void)=0;
};

class Vehicule:public Objet
{
private:
  int puissance;
  int vitesse; 
  char couleur;
  Lesvehicules * pvehicule;
public:
  Vehicule(void):pvehicule(NULL){}
  ~Vehicule(void){delete pvehicule;}
  void lire(istream & fluxIn);
  void lire(void);
  void ecrire(ostream & fluxOut);
  void ecrire();
};


class Voiture:public Lesvehicules
{
private:
  int nb_places;
public:
  Voiture(void){}
  void lire(istream & fluxIn);
  void lire(void);
  void ecrire(ostream & fluxOut);
  void ecrire(void);
};

class Car:public Lesvehicules
{
private:
  int nb_passagers;
public:
  Car(){}
  void lire(istream & fluxIn);
  void lire(void);
  void ecrire(ostream & fluxOut);
  void ecrire(void);
};

class Camion:public Lesvehicules
{
private:
  int poids;
public:
  Camion(void){}
  void lire(istream & fluxIn);
  void lire(void);
  void ecrire(ostream & fluxOut);
  void ecrire(void);
};