#include <iostream>
#include "vehicules.hpp"
using namespace std;

int main(void)
{
  Vehicule v1,v2,v3;
  v1.lire();
  v2.lire();
  v3.lire();
  ListeObjet l;
  l.insererDebutListe(&v1);
  l.insererDebutListe(&v2);
  l.insererDebutListe(&v3);
  l.insererFinListe(&v1);
  l.insererFinListe(&v2);
  l.insererFinListe(&v3);

  l.ecrireListe();
  //v1.ecrire();

  //Vehicule vehicule1;
  //vehicule1.lire(cin);
  //vehicule1.lire();
  //vehicule1.ecrire(cout);
  //Voiture voiture1;
  //voiture1.lire(cin);
  ////voiture1.ecrire(cout);
  //Car car1;
  //car1.lire(cin);
  ////car1.ecrire(cout);
  //LienObjet l1((Objet*)&voiture1);
  //LienObjet l2((Objet*)&car1);
  //l1.setNext(&l2);
  //l1.getObjet()->ecrire();
  //l1.getNext()->getObjet()->ecrire();
  ////car1.ecrire();
  return 0;
}