#include "listeobj.hpp"


void ListeObjet::insererDebutListe(Objet * pobj)
{
  LienObjet * pLienObjet=new LienObjet(pobj);
  pLienObjet->setNext(pdeb);
  if (NULL==pdeb) pfin=pLienObjet; 
  pdeb=pLienObjet;
}

void ListeObjet::insererFinListe(Objet * pobj)
{
  LienObjet * pLienObjet=new LienObjet(pobj);
  pLienObjet->setNext(NULL);
  if (NULL==pdeb) pdeb=pLienObjet; else pfin->setNext(pLienObjet);
  pfin=pLienObjet;
  pfin->setNext(NULL);
}

void ListeObjet::ecrireListe()
{
  LienObjet * ptr=pdeb;
  while(ptr!=NULL)
  {
    ptr->getObjet()->ecrire();
    ptr=ptr->getNext();
  }
}

void ListeObjet::detruireListe()
{
  LienObjet *tmp,*ptr=pdeb;
  while(ptr!=NULL)
  {
    tmp=ptr->getNext();
    delete ptr;
    ptr=tmp;
  }
}