using namespace std;
#include <iostream>


class Objet
{
public:
  virtual void lire(istream & fluxIn)=0;
  virtual void lire(void)=0;
  virtual void ecrire(ostream & fluxOut)=0;
  virtual void ecrire(void)=0;
};

