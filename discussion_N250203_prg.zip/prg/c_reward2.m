function [val,ok]=c_reward2(Y,C,N,Nc,tau,b,p)
%computes the reward function for a given output Y
         assert(size(Y),[N,1]); 
         assert(Nc<N); 
         assert(p<tau*b); 
         assert(size(C),[N,1]); 
         assert(all(C>=0)); 
         assert(all((Y==1)|(Y==0))); 
  ind = find(Y); 
  if ~(all(diff(ind)>=Nc)) 
    ok = logical(0);    
    val = NaN; 
  else 
    ok = logical(1); 
    val=0; 
    for k=1:length(ind)
      val += tau*b*C(ind(k))-p; 
    end
  end
end