function [val,ok,Y_c]=c_reward3(Y,C,N,Nc,tau,b,p)
%it is different from c_reward1 and c_reward2
%because it changes the values of y_n when the UAV has 
%already been sent. 
%Hence ok is the same and if ok=1 then value is the same
%if ok=0, value is for the corrected Y
  D=zeros(N); 
  for k=1:(Nc-1)
    D += diag(ones(1,N-k),k); 
  end
  ok=(Y'*D*Y == 0); 
  if ~ok 
    Y_c = Y&(D*Y==0); 
  else 
    Y_c=Y; 
  end
  alpha=p/(tau*b); 
  val = tau*b*(C-alpha)'*Y_c;
end