function [val,ok]=c_reward1(Y,C,N,Nc,tau,b,p)
%computes the reward function for a given output Y
         assert(size(Y),[N,1]); 
         assert(Nc<N); 
         assert(p<tau*b); 
         assert(size(C),[N,1]); 
         assert(all(C>=0)); 
         assert(all((Y==1)|(Y==0))); 
  is_pb=0; val = 0; 
  for n=1:N
    if 0 == Y(n) 
      if is_pb >= Nc-1 
        is_pb = 0; 
        %val += tau*b*C(n);        
      elseif is_pb > 0
        is_pb += 1;
        %val += tau*b*C(n);        
      end
    elseif 0 == is_pb
      is_pb = 1; 
      val += tau*b*C(n) - p; 
    else 
      ok = logical(0); val = NaN; return; 
    end  
  end
  ok = logical(1);    
end