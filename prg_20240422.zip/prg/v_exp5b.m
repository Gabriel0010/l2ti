function v_Adatabase()
%checks the A-database 
  load([rep,'exp5b.mat'],'data','lg'); 
         assert(data(1,lg.limit),90); 
         assert(data(2,lg.limit),80); 
         assert(data(246,lg.limit),80); 
         assert(mod(data(:,lg.limit),10),zeros(size(data,1),1)); 
  load([rep,'exp1.mat'],'data','lg'); 
         assert(data(1,lg.limit),90); 
         assert(data(2,lg.limit),80); 
         assert(mod(data(:,lg.limit),10),zeros(size(data,1),1)); 
end