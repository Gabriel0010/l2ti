function data2=extract_data(data1,lg,time_interval)
%extracts samples whose time stamps are in time_interval
%using the divide by two algorithm
         assert(size(time_interval),[1 2]); 
         assert(time_interval(2)>time_interval(1));
         assert(size(data1,1)>1); 
  t1=data2time(data1(1,:),lg);
  t2=data2time(data1(end,:),lg);
         assert(t1<=time_interval(1)); 
         assert(time_interval(1)<t2); 
         assert(t1<time_interval(2)); 
  ok_a=0; ok_b=0; ind_a_l=init(data1); ind_b_l=init(data1); 
  while(1)
    if ~ok_a 
      [ok_a,ind_a_l]=algorithm_is_finished(ind_a_l,data1,lg,time_interval(1)); 
    end
    if ~ok_b
      [ok_b,ind_b_l]=algorithm_is_finished(ind_b_l,data1,lg,time_interval(2)); 
    end
    if ok_a&&ok_b break; end
    if ~ok_a
      ind_a_l=move(ind_a_l,data1,lg,time_interval(1));
    end
    if ~ok_b
      ind_b_l=move(ind_b_l,data1,lg,time_interval(2));
    end
  end
  data2=data1(ind_a_l(1):ind_b_l(1),:); 
end

function ind_l=init(data); 
  ind_l=[1 size(data,1)]; 
end


function [ok,ind_l]=algorithm_is_finished(ind_l,data,lg,t)
  if ind_l(2)-ind_l(1)==1
    ok=1; 
    if data2time(data(ind_l(2),:),lg)<=t
      ind_l=[ind_l(2) ind_l(2)]; 
    else 
      ind_l=[ind_l(1) ind_l(1)]; 
    end
  else 
    ok=0; 
  end
end


function ind2_l=move(ind1_l,data,lg,t1)
%ind1_l and ind2_l are pairs of indexes
%move modifies the pairs of indexes 
%in such a way that the left element remains below t1
         assert(data2time(data(ind1_l(1),:),lg)<=t1); 
  ind=ceil(mean(ind1_l)); 
  t2=data2time(data(ind,:),lg); 
  if t2<=t1 
    ind2_l=[ind ind1_l(2)]; 
  else 
    ind2_l=[ind1_l(1) ind]; 
  end
end