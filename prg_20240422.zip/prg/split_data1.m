function [data2,lg2]=split_data1(data1,lg1,fe,cond,time_advance,duration)
%data1 is a table
%lg1 is its legend
%fe is sampling frequency in second
%cond is an inline function testing if the speed is exceeded by more than 5%
%time_advance is the number of second for prediction
%duration is the time during which in the future the drone will be hovering
  for k=1:1e3 v_count(), end
  v_c_nb();
  lg2.density=1; 
  lg2.ratio=2; 
  lg2.y=3; 
  lg2.ln=3; 
  ind_c=data2ind(data1,lg1,fe); 
  cond_c=apply_cond(data1,lg1,cond); 
  [d_c,r_c]=count(ind_c,cond_c);
  [d_c,r_c,nb_c]=c_nb(d_c,r_c,round(time_advance*fe),round(duration*fe));
  [y_c,nb_threshold]=c_y(nb_c);
  lg2.nb_threshold=nb_threshold; 
  data2=[d_c,r_c,y_c]; 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% other functions


function [d3_c,r3_c,nb3_c]=c_nb(d_c,r_c,ind_advance,ind_duration)
%computes the number of offenders during a duration of ind_duration time slots 
%and at a later time of ind_advance time slots. 
  if ~(ind_advance+ind_duration<length(d_c)) d3_c=[]; r3_c=[]; nb3_c=[]; return; end
  nb_c=d_c.*r_c; nb_c(d_c==0)=0;
  nb1_c=nb_c((1+ind_advance):end);
  nb2_c=filter(ones(1,ind_duration),1,nb1_c);
  nb3_c=nb2_c(ind_duration:end); 
  d3_c=d_c(1:(end-ind_duration+1-ind_advance)); 
  r3_c=r_c(1:(end-ind_duration+1-ind_advance)); 
  ind=find(d3_c==0); r3_c(ind)=0; 
end

function [y_c,nb_threshold]=c_y(nb_c)
%nb_c is the number of offenders within a time window 
%defined with fe, time_advance and duration
%c_y computes a threshold and 
%for each time slots computes y
%which tells if there will be a higher number of offenders
  nb_threshold=quantile(nb_c,0.75); 
  y_c=(nb_c>nb_threshold); 
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Checking functions

function v_c_nb()
  for k=1:1e3
    [d_c,r_c,fe,time_advance,duration,N]=choose_data1();   
    [d3_c,r3_c,nb3_c]=c_nb(d_c,r_c,round(time_advance*fe),round(duration*fe));
    v_c_nb1(d3_c,r3_c,nb3_c,round(time_advance*fe),round(duration*fe),N);
  end
  [d_c,r_c,fe,time_advance,duration]=choose_data2();
  [d1_c,r1_c,nb1_c]=c_nb(d_c,r_c,round(time_advance*fe),round(duration*fe));
  v_c_nb1(d1_c,r1_c,nb1_c,round(time_advance*fe),round(duration*fe));       
  [d2_c,r2_c,nb2_c]=c_nb(d_c,r_c,round(time_advance*fe),1);
  v_c_nb1(d2_c,r2_c,nb2_c,round(time_advance*fe),1);       
  [d3_c,r3_c,nb3_c]=c_nb(d_c,r_c,0,round(duration*fe));
  v_c_nb1(d3_c,r3_c,nb3_c,0,round(duration*fe));       
end

function v_c_nb1(d_c,r_c,nb_c,ind_advance,ind_duration,N)
         assert(size(d_c),size(r_c)); 
         assert(size(nb_c),size(d_c)); 
         if (6==nargin)
           if ~isempty(d_c)
             assert(length(d_c),N-ind_advance+1-ind_duration); 
           else 
             assert(N<=ind_advance+ind_duration); 
           end           
         end
         if ~isempty(nb_c)
           if (1==ind_duration)&&(length(d_c)>ind_advance)
             ind=ceil((length(d_c)-ind_advance)*rand(1)); 
             assert(nb_c(ind),round(d_c(ind+ind_advance)*r_c(ind+ind_advance)),1e-4); 
           end
           assert(nb_c,round(nb_c),1e-4); 
           if (0==ind_advance)&&(length(d_c)>ind_duration)
             ind=ceil((length(d_c)-ind_duration)*rand(1)); 
             assert(nb_c(ind),round(sum(d_c(ind:ind+ind_duration-1).*r_c(ind:ind+ind_duration-1))),1e-4); 
           end
         end
end

function [d_c,r_c,fe,time_advance,duration,N]=choose_data1()
%for v_c_nb
  fe=1/60; 
  ind_advance=floor(rand(1)*5); 
  time_advance=ind_advance/fe; 
  ind_duration=ceil(rand(1)*5);
  duration=ind_duration/fe;   
  N=ceil(100*rand(1)); 
  d_c=ceil(6*rand(N,1)); 
  r_c=round(d_c.*(0.2+0.8*rand(N,1)))./d_c; 
  r_c(r_c==NaN)=0;
end  

function [d_c,r_c,fe,time_advance,duration,N]=choose_data3()
%for v_c_nb
  fe=1/60; 
  if rand(1)<0.5
    ind_advance=floor(rand(1)*5); 
    ind_duration=1; 
  else
    ind_duration=ceil(rand(1)*5);
    ind_advance=0; 
  end
  time_advance=ind_advance/fe; 
  duration=ind_duration/fe;   
  N=ceil(100*rand(1)); 
  d_c=ceil(6*rand(N,1)); 
  r_c=round(d_c.*(0.2+0.8*rand(N,1)))./d_c; 
  r_c(r_c==NaN)=0;
end  



function [d_c,r_c,fe,time_advance,duration]=choose_data2();
%for v_c_nb
  cd C:\A\SIMU\SIMU_X\traffic\prg
  rep=['../dataset/']; 
  load([rep,'exp1.mat'],'data','lg'); 
  fe=1/60; 
  cond=@(v,v_max)(v>(v_max*1.05)); 
  time_advance=5*60; duration=20*60; 
  ind_c=data2ind(data,lg,fe); 
  cond_c=apply_cond(data,lg,cond); 
  [d_c,r_c]=count(ind_c,cond_c);
end


function v_time2ind()
%verifies time2ind()
  t_c=cumsum(rand(100,1)); 
  fe=rand(1); 
  ind_c=time2ind(t_c,fe); 
         assert(size(ind_c,2),1); 
         assert(all(ind_c>=0)); 
         assert(all(diff(ind_c)>=0)); 
  ind_=ceil(rand(1)*length(ind_c)); 
         assert(t_c(ind_c(ind_))<=ind_/fe); 
         assert(t_c(ind_c(ind_))>(ind_-1)/fe); 
end


function v_count()
%verifies count()
  N=ceil(30*rand(1)); 
  cond_c=(rand(N,1)<0.5);
  ind_c=find(rand(N,1)<0.5); 
  [d_c,r_c]=count(ind_c,cond_c);
  assert(size(d_c,2)<=1); 
  if isempty(d_c) 
         assert(isempty(ind_c)); return; 
  end
  ind_n_nan=find(~isnan(r_c)); 
         assert(sum(d_c),ind_c(end)-1); 
         last=ind_c(end); 
         assert(sum(d_c(ind_n_nan).*r_c(ind_n_nan)),sum(cond_c(1:(last-1))));
         assert(all(r_c(ind_n_nan))>=0); 
         assert(isnan(r_c)<=(d_c==0)); 
         assert(isnan(r_c)+(0==r_c)>=(d_c==0)); 
         assert(all(r_c(ind_n_nan))<=1); 
         assert(r_c(ind_n_nan).*d_c(ind_n_nan),round(r_c(ind_n_nan).*d_c(ind_n_nan)), 1e-4); 
         
end

