function v_combine()
  data2=[]; lg2=[]; 
  K=ceil(rand(1)*10)*10; 
  for k=1:K
    [data1,lg1]=choose_data(); 
    [data2,lg2]=combine(data2,lg2,data1,lg1); 
  end
         assert(size(data2),[30 3*K]); 
         assert((sum(data2,1)/30)(lg2.mu_r),10*pi*ones(1,K),3);,
         assert((sum(data2,1)/30)(lg2.sigma_r),sqrt(2)*ones(1,K),1);,
  disp('v_combine'),
end

function [data1,lg1]=choose_data()
  lg1.t=1; 
  lg1.mu_r=2; 
  lg1.sigma_r=3; 
  lg1.ln=3; 
  data1=[sort(randn(30,1)) 10*pi+2*randn(30,1) sqrt(2)+randn(30,1)]; 
end