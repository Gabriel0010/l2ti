function v_extract_data()
  [data,lg,time_interval]=choose_data();
  data2=extract_data(data,lg,time_interval); 
  t1=data2time(data2(1,:),lg); 
  t2=data2time(data2(end,:),lg); 
         assert(t1<=time_interval(1)); 
         assert(t2<=time_interval(2)); 
  [ok,ind,ind2]=is_in(data,data2); 
  if 1==ok
    if ind2+1<=size(data2,1)
      assert(data2time(data2(ind2+1,:),lg)>=time_interval(1)); 
    end
    t=data2time(data2(ind2,:),lg); 
         assert(t<=time_interval(2));
  end
  [ok,ind2,ind]=is_in(data2,data); 
         assert(ok==1);
  disp('v_extract_data'), 
end

function [data,lg,time_interval]=choose_data()
%creates data to test the function
  cd C:\A\SIMU\SIMU_X\traffic\prg
  rep=['../dataset/']; 
  load([rep,'exp1.mat'],'data','lg'); 
  N=size(data,1); 
  n1=ceil(rand(1)*(N-200)); n2=n1+ceil(rand(1)*200); 
  data=data(n1:n2,:); 
  t1=data2time(data(1,:),lg); 
  t2=data2time(data(end,:),lg); 
         assert(t1<t2);
  ta=t1+rand(1)*(t2-t1); 
  tb=ta+rand(1)*(t2-ta); 
  time_interval=[ta tb];
         assert(t1<=time_interval(1)); 
         assert(time_interval(1)<t2); 
         assert(t1<time_interval(2));   
end

function [ok,ind1,ind2]=is_in(data1,data2)
  if 0==size(data1,1) 
    ok=1; ind1=NaN; ind2=NaN; 
  end
  ind1=ceil(rand(1)*size(data1,1)); 
  ok=0; ind2=NaN; 
  for ind2_=1:size(data2,1)
    if all(data1(ind1,:)==data2(ind2_,:)) 
      ok=1; ind2=ind2_; return; 
    end
  end
end