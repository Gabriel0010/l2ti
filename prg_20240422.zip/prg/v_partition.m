function v_partition()
  K=2+ceil(rand(1)*10); 
  time_interval=randn(1)+[0 5*rand(1)];
  [t_center_l,radius]=partition(time_interval,K);
         assert(size(t_center_l),[1 K]); 
         assert(size(radius),[1 1]); 
         assert(t_center_l(1),time_interval(1)+radius,1e-8); 
         assert(t_center_l(end),time_interval(2)-radius,1e-8); 
         ind=1+ceil(rand(1)*(K-2)); 
         assert(t_center_l(ind)-2*radius,t_center_l(ind-1),1e-8);
         assert(t_center_l(ind)+2*radius,t_center_l(ind+1),1e-8);
  disp('v_partition'), 
end