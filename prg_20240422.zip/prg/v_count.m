function v_count()
%verifies count()
  N=ceil(30*rand(1)); 
  cond_c=(rand(N,1)<0.5);
  ind_c=find(rand(N,1)<0.5); 
  [d_c,r_c]=count(ind_c,cond_c);
  assert(size(d_c,2)<=1); 
  if isempty(d_c) 
         assert(isempty(ind_c)); return; 
  end
  ind_n_nan=find(~isnan(r_c)); 
         assert(sum(d_c),ind_c(end)-1); 
         last=ind_c(end); 
         assert(sum(d_c(ind_n_nan).*r_c(ind_n_nan)),sum(cond_c(1:(last-1))));
         assert(all(r_c(ind_n_nan))>=0); 
         assert(isnan(r_c)<=(d_c==0)); 
         assert(isnan(r_c)+(0==r_c)>=(d_c==0)); 
         assert(all(r_c(ind_n_nan))<=1); 
         assert(r_c(ind_n_nan).*d_c(ind_n_nan),round(r_c(ind_n_nan).*d_c(ind_n_nan)), 1e-4); 
         
  disp('v_count');        
end
