function [data2,lg2]=combine2(data2,lg2,data1,lg1)
%cumulates the different data into one single adapting lg at each new data
         assert(isempty(data2),isempty(lg2)); 
         assert(lg1.ln,size(data1,2)); 
         assert(isfield(lg1,'t')); 
         assert(isfield(lg1,'r')); 
         assert(isfield(lg1,'d_fe'));         
  if isempty(data2)
    data2=data1; lg2=lg1; return; 
  end
  data2=[data2 data1]; 
  lg2.t=[lg2.t lg2.ln+lg1.t]; 
  lg2.r=[lg2.r lg2.ln+lg1.r]; 
  lg2.d_fe=[lg2.d_fe lg2.ln+lg1.d_fe]; 
  lg2.ln=lg2.ln+lg1.ln; 
         assert(lg2.ln,size(data2,2)); 
end