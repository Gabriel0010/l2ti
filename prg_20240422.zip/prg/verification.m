function verification()
  v_partition(); 
  v_count(); 
  v_time2ind(); 
  v_extract_data(); 
  v_combine(); 
end