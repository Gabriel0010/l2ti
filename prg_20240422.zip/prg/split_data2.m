function [data2,lg2]=split_data2(data1,lg1,fe,cond)
%data1 is a table
%lg1 is its legend
%fe is sampling frequency in second
%cond is an inline function testing if the speed is exceeded by more than 5%
  lg2.density=1; 
  lg2.ratio=2; 
  lg2.ln=2; 
  lg2.fe=fe; 
  ind_c=data2ind(data1,lg1,fe); 
  cond_c=apply_cond(data1,lg1,cond); 
  [d_c,r_c]=count(ind_c,cond_c);
  data2=[d_c,r_c]; 
end

