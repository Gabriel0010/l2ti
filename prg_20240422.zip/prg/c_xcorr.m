function [data2,lg2]=c_xcorr(data1,lg1)
%computes the unbiaised cross correlation
  MaxLag=100; 
         assert(size(data1,1)>MaxLag*2); 
         assert(0==any(any(isnan(data1))));
  lg2.t=1; 
  lg2.ln=lg1.ln+1; 
  lg2.mu_r=lg1.mu_r+1; 
  lg2.sigma_r=lg1.sigma_r+1; 
  lg2.MaxLag=MaxLag; 
  data2=zeros(2*MaxLag+1,lg2.ln); 
  data2(:,lg2.t)=(-MaxLag:MaxLag)/lg1.fe; 
  data2(:,lg2.mu_r)=xcorr_un(data1(:,lg1.mu_r),MaxLag); 
  data2(:,lg2.sigma_r)=xcorr_un(data1(:,lg1.sigma_r),MaxLag); 
end

function R=xcorr_un(x,MaxLag)
%unbiaised implementation of xcorr
  R=xcorr(x,MaxLag)./xcorr(ones(size(x)),MaxLag); 
end