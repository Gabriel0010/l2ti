function [data,lg]=read_file1(file,nb)
%reads a csv file 
%extracts a table data
%lg indicates the signification of each column
%nb is either the maximum number of lines read
%or an interval with the minimum and the maximum number
  [n1,n2]=read_nb(nb); 
  fid=fopen(file); 
  data=[]; 
  cpt=0; 
  while (! feof (fid) )
    line=fgetl(fid); 
    if cpt>=n1
      data_l=read_line(line);
      if ~isempty(data_l) 
        data=[data; data_l]; 
      end    
    end
    %vect=str2num(d{:}),
    %vect,
    if 0==mod(cpt,5e4) disp(line), end
    cpt++; 
    if n2==cpt break; end
  end
  fclose(fid); 
  lg.year=1; 
  lg.month=2; 
  lg.day=3; 
  lg.hour=4; 
  lg.minute=5; 
  lg.position_x=6; 
  lg.position_y=7; 
  lg.speed=8; 
  lg.limit=9; 
  lg.ln=9; 
end

function [n1,n2]=read_nb(nb)
  if 1==length(nb) n1=1; n2=nb; 
  else n1=nb(1); n2=nb(2); 
  end
end

function data_l=read_line(line)
%parse a line into 9 values. 
  [~,~,~,d1]=regexp(line,'[^ ;T:]*');
  data_l=[];
  if (length(d1)<7)  return; end
  [~,~,~,d2]=regexp(d1{1},'[^-]*');
  data_l=zeros(1,9); 
  for i=1:9
    if i<=3 
      
      [val,state]=str2num(d2{i}); 
      if ~state data_l=[]; return; end
      data_l(i)=val; 
    else
      [val,state]=str2num(d1{i-2});
      if ~state data_l=[]; return; end
      data_l(i)=val; 
    end      
  end  
         assert(mod(data_l(9),10),zeros(size(data_l,1),1)); 
end