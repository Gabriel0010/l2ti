function cond_c=apply_cond(data1,lg1,cond)
%applies the inline function cond to dataset data1,lg1
  v=data1(:,lg1.speed); 
  v_max=data1(:,lg1.limit); 
  cond_c=cond(v,v_max);
end
