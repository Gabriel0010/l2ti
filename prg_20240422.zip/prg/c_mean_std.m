function [data2,lg2]=c_mean_std(data1,lg1,window_ln)
%computes the mean and std of data
%one sample evry window_ln samples
         assert(window_ln>0); 
         assert(size(window_ln),[1 1]); 
         assert(floor(window_ln),window_ln); 
  lg2.mu_r=1; 
  lg2.sigma_r=2; 
  lg2.ln=2; 
  lg2.fe=lg1.fe/window_ln; 
  data2=zeros(floor(size(data1,1)/window_ln),lg2.ln); 
  for data1_=window_ln:window_ln:size(data1,1)
    ind_l=data1_-window_ln+1:data1_;
    inda=find(data1(ind_l,lg1.density)~=0); 
    ind_l=ind_l(inda); 
    if isempty(ind_l)
      data2(data1_/window_ln,lg2.mu_r)=0; 
      data2(data1_/window_ln,lg2.sigma_r)=0; 
    else
      data2(data1_/window_ln,lg2.mu_r)=mean(data1(ind_l,lg1.ratio)); 
      data2(data1_/window_ln,lg2.sigma_r)=std(data1(ind_l,lg1.ratio)); 
    end
  end
  lg2.window_ln=window_ln; 
end