function v_time2ind()
%verifies time2ind()
  t_c=cumsum(rand(100,1)); 
  fe=rand(1); 
  ind_c=time2ind(t_c,fe); 
         assert(size(ind_c,2),1); 
         assert(all(ind_c>=0)); 
         assert(all(diff(ind_c)>=0)); 
  ind_=ceil(rand(1)*length(ind_c)); 
         assert(t_c(ind_c(ind_))<=ind_/fe); 
         assert(t_c(ind_c(ind_))>(ind_-1)/fe); 
  disp('v_time2ind'),
end
