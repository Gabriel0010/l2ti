function [d_c,r_c]=count(ind_c,cond_c)
%ind_c is the list of indexes addressing the beginning of each time slot
%cond_c is the addressed table and contains 1 if the condition is met and 0 otherwise
%d_c is the number of lines in the addressed table
%r_c is the ratio of success within this table.
  if isempty(ind_c) d_c=[]; r_c=[]; return; end
  for ind_=1:length(ind_c)
    if 1==ind_
      previous=1; 
    else 
      previous=ind_c(ind_-1); 
    end
    upto=ind_c(ind_)-1; 
    cond_cum=sum(cond_c(previous:upto)); 
    d_c(ind_)=upto-previous+1; 
    if 0==d_c(ind_)
      r_c(ind_)=NaN; 
    else
      r_c(ind_)=cond_cum/d_c(ind_); 
    end
  end
  d_c=d_c(:); r_c=r_c(:); 
end

