function [t_center_l,radius]=partition(time_interval,K)
%this function cuts time_interval in K equal intervals of time_interval
%t_center_l is the list of centers 
%radius is the common half length of each interval. 
%computations are done assuming time are real numbers
         assert(time_interval(2)>time_interval(1)); 
         assert(floor(K),K); 
         assert(size(time_interval),[1 2]); 
  T=time_interval(2)-time_interval(1); 
  t_center_l=time_interval(1)+T/K*(0.5+(0:(K-1))); 
  radius=t_center_l(1)-time_interval(1); 
end