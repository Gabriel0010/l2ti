function ind_c=data2ind(data,lg,fe)
%computes the time slot of each sample.
%There can be several samples in the same time slots
  t_c=data2time(data,lg); 
  ind_c=time2ind(t_c,fe);
end



function ind_c=time2ind(t_c,fe)
%fe is the sampling frequency, that is the inverse of the duration of each time slots
%t_c is a column vector containing the time in seconds of each sample. 
%ind_c is the time stamp of each sample. 
  if isempty(t_c) ind_c=[]; return; end
  t=0; 
  ind_c=[]; ind_=1; 
  while(t<t_c(end))
    if t>t_c(ind_)
      ind_++; 
    else
      ind_c=[ind_c; ind_]; 
      t+=1/fe;
    end
  end
end