function [data2,lg2]=c_xcorr2(data1,lg1)
%computes the unbiaised cross correlation
  MaxLag=100; 
         assert(size(data1,1)>MaxLag*2); 
         assert(mean(data1(:,lg1.density)>0)>0.5); 
  lg2.t=1; 
  lg2.ln=lg1.ln+1; 
  lg2.r=lg1.ratio+1; 
  lg2.d_fe=lg1.density+1; 
  lg2.MaxLag=MaxLag; 
  data2=zeros(2*MaxLag+1,lg2.ln); 
  data2(:,lg2.t)=(-MaxLag:MaxLag)/lg1.fe; 
  ind_l=find(data1(:,lg1.density)~=0);
  data2(:,lg2.r)=xcorr_un(data1(ind_l,lg1.ratio),MaxLag); 
  data2(:,lg2.d_fe)=xcorr_un(data1(:,lg1.density)*lg1.fe,MaxLag); 
         assert(0==any(any(isnan(data2))));
end

function R=xcorr_un(x,MaxLag)
%unbiaised implementation of xcorr
  R=xcorr(x,MaxLag)./xcorr(ones(size(x)),MaxLag); 
end