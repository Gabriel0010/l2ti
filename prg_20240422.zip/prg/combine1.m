function [data2,lg2]=combine1(data2,lg2,data1,lg1)
%cumulates the different data into one single adapting lg at each new data
         assert(isempty(data2),isempty(lg2)); 
         assert(lg1.ln,size(data1,2)); 
         assert(isfield(lg1,'t')); 
         assert(isfield(lg1,'mu_r')); 
         assert(isfield(lg1,'sigma_r'));
         assert(isfield(lg1,'mu_d_fe'));         
         assert(isfield(lg1,'sigma_d_fe'));         
  if isempty(data2)
    data2=data1; lg2=lg1; return; 
  end
  data2=[data2 data1]; 
  lg2.t=[lg2.t lg2.ln+lg1.t]; 
  lg2.mu_r=[lg2.mu_r lg2.ln+lg1.mu_r]; 
  lg2.mu_d_fe=[lg2.mu_d_fe lg2.ln+lg1.mu_d_fe]; 
  lg2.sigma_r=[lg2.sigma_r lg2.ln+lg1.sigma_r]; 
  lg2.sigma_d_fe=[lg2.sigma_d_fe lg2.ln+lg1.sigma_d_fe]; 
  lg2.ln=lg2.ln+lg1.ln; 
         assert(lg2.ln,size(data2,2)); 
end