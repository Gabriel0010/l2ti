#include <windows.h>
#include "..\test_erreur.h"
#include <string.h>
#include <stdio.h>
#include <conio.h>
#define NB_PROC 10
#define LG_CMD 100
INT main(VOID)
{
  STARTUPINFO st_in[NB_PROC];
  PROCESS_INFORMATION pi[NB_PROC];
  SECURITY_ATTRIBUTES se_at;
  INT i; 
  CHAR cmd[LG_CMD];
  HANDLE hMut,hEvAr,hProc[NB_PROC];
  se_at.bInheritHandle=TRUE; se_at.lpSecurityDescriptor=NULL; se_at.nLength=sizeof se_at; 
  if (NULL==(hMut=CreateMutex(&se_at,FALSE,NULL))) test_erreur("CreateMutex"); 
  if (NULL==(hEvAr=CreateEvent(NULL,TRUE,FALSE,"arret"))) test_erreur("ex2:CreateEvent arret"); 
  //printf("ex2:hMut=%d\n",hMut);
  for(i=0;i<NB_PROC;i++) {
    st_in[i].cb=sizeof st_in[i]; ZeroMemory(&st_in[i],st_in[i].cb);
    sprintf_s(cmd,sizeof(cmd),"ex1 %d %d",i,hMut);
    //printf("%s\n",cmd);
    if (!CreateProcess(NULL,cmd,NULL,NULL,TRUE,0,NULL,NULL,&st_in[i],&pi[i]))
      test_erreur("ex2: CreateProcess"); 
    if (!CloseHandle(pi[i].hThread)) test_erreur("ex2:main:CloseHandle hThread");
    hProc[i]=pi[i].hProcess;
  }
  while(!_kbhit()) Sleep(200); 
  _getch();
  if (!SetEvent(hEvAr)) test_erreur("ex2:main:SetEvent arret"); 
  if (WAIT_FAILED==WaitForMultipleObjects(NB_PROC,hProc,TRUE,INFINITE)) 
    test_erreur("ex2:main:WaitForMultipleObjects");
  if (!CloseHandle(hEvAr)) test_erreur("ex2:main:CloseHandle hEvAr");
  if (!CloseHandle(hMut)) test_erreur("main:CloseHandle Mutex"); 
  for(i=0;i<NB_PROC;i++) {
    if (!CloseHandle(hProc[i])) test_erreur("ex2:main:CloseHandle hProcess");
  }
  return 0; 
}