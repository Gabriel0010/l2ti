#include <Windows.h>
#include <stdio.h>
#include <conio.h>
#include "..\test_erreur.h"
#include <string.h>

#define NB_THREAD 10

DWORD WINAPI joueur(LPVOID param);

typedef struct _DONNEE {
  INT numPr;
  INT numTh;
  HANDLE hMut;
} DONNEE;

INT main(INT argc,CHAR * argv[])
{
  INT i,Pr; 
  DONNEE tab[NB_THREAD];
  HANDLE hTab[NB_THREAD];
  HANDLE hMut;
  if (3!=argc) {
    printf("nombre arguments errones\n"); return -1;
  }
  Pr=atoi(argv[1]);
  hMut=(HANDLE)atoi(argv[2]);
  //printf("ex1:hMut=%d\n",hMut);
  for(i=0;i<NB_THREAD;i++){
    tab[i].numTh=i; tab[i].hMut=hMut; tab[i].numPr=Pr;
    if (NULL==(hTab[i]=CreateThread(NULL,0,joueur,&tab[i],0,NULL))) 
      test_erreur("main:CreateThread");
  }
  for(i=0;i<NB_THREAD;i++){
    if (!CloseHandle(hTab[i])) test_erreur("main:CloseHandle");
  }
  while(1);
  if (!CloseHandle(hMut)) test_erreur("main:CloseHandle Mutex"); 
  return 0;
}


DWORD WINAPI joueur(LPVOID param)
{
  DONNEE donnee=*(DONNEE *)param; 
  while(1) {
    //printf("ex1:joueur %d hMut=%d\n",donnee.numTh,donnee.hMut);
    if (WAIT_OBJECT_0!=WaitForSingleObject(donnee.hMut,INFINITE)) 
      test_erreur("joueur:WaitForSingleObject");
    printf("joueur  %d%d recoit ballon\n",donnee.numPr,donnee.numTh); 
    Sleep(100); 
    if (!ReleaseMutex(donnee.hMut)) test_erreur("joueur:ReleaseMutex");
    Sleep(100);
  }
  return 0;
}