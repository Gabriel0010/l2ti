#include <Windows.h>
#include <stdio.h>
#include <conio.h>
#include "..\test_erreur.h"

#define NB_THREAD 5

DWORD WINAPI joueur(LPVOID param);

typedef struct _DONNEE {
  INT num;
  HANDLE hEv;
} DONNEE;

INT main(VOID)
{
  INT i; 
  DONNEE tab[NB_THREAD];
  HANDLE hTab[NB_THREAD];
  HANDLE hEv;
  if (NULL==(hEv=CreateEvent(NULL,FALSE,FALSE,NULL))) test_erreur("CreateEvent");
  if (!SetEvent(hEv)) test_erreur("main:SetEvent");
  for(i=0;i<NB_THREAD;i++){
    tab[i].num=i+1;
    tab[i].hEv=hEv;
    if (NULL==(hTab[i]=CreateThread(NULL,0,joueur,&tab[i],0,NULL))) 
      test_erreur("main:CreateThread");
  }
  while(!_kbhit()) {
    Sleep(200); 
  }
  _getch();
  for(i=0;i<NB_THREAD;i++){
    if (!TerminateThread(hTab[i],i)) test_erreur("main:TerminateThread");
    if (!CloseHandle(hTab[i])) test_erreur("main:CloseHandle");
  }
  if (!CloseHandle(hEv)) test_erreur("main:CloseHandle Event"); 
  return 0;
}


DWORD WINAPI joueur(LPVOID param)
{
  DONNEE donnee=*(DONNEE *)param; 
  while(1) {
    if (WAIT_OBJECT_0!=WaitForSingleObject(donnee.hEv,INFINITE)) 
      test_erreur("joueur:WaitForSingleObject");
    printf("joueur num %d recoit ballon\n",donnee.num); 
    Sleep(100); 
    if (!SetEvent(donnee.hEv)) test_erreur("joueur:SetEvent");
    Sleep(100);
  }
  return 0;
}