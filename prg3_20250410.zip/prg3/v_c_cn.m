function v_c_cn()
  T=load('exp3_1.mat'); 
  [data2,lg2]=c_cn(T.data_tr,T.lg_tr);
         assert(size(data2,1)<=size(T.data_tr,1)); 
  is_in(data2,lg2,T.data_tr,T.lg_tr);        
  is_cn_possible(data2,lg2,T.data_tr,T.lg_tr);        
end

function is_in(data2,lg2,data1,lg1)
  n2=ceil(rand(1)*size(data2,1)); 
  for n1=1:size(data1,1)
    if data1(n1,lg1.n) == data2(n2,lg2.n)
         assert(data1(n1,lg1.density) == data2(n2,lg2.density)); 
         assert(data1(n1,lg1.ratio) == data2(n2,lg2.ratio)); 
      return; 
    end
  end
  error('is_in'); 
end


function is_cn_possible(data2,lg2,data1,lg1)
  time_advance=5*60; duration=20*60; 
  na=round(time_advance*lg1.p_fe); 
  nd=round(duration*lg1.p_fe);         
  n2=ceil(rand(1)*size(data2,1)); 
  ok=0; 
  for n1=1:size(data1,1)
    ind=n1+(na:(na+nd))-1;     
    if ~(min(ind) >= 1) continue, end
    if ~(max(ind) <= size(data1,1)) continue, end
    if ~(all(data1(ind,lg1.ok))) continue, end
    if data2(n2,lg2.cn) == sum(data1(ind,lg1.density).*data1(ind,lg1.ratio))
      return; 
    end
  end
  error('is_cn_possible'); 
end