function [data2,lg2]=c_cn(data1,lg1,time_advance,duration)
%computes and removes lines (i.e. samples) for which cn cannot be computed
  if 2==nargin time_advance=5*60; duration=20*60; end
  na=round(time_advance*lg1.p_fe); 
  nd=round(duration*lg1.p_fe);
     assert(lg1.n == 1); 
     assert(lg1.density == 2); 
     assert(lg1.ratio == 3); 
  lg2.n=lg1.n; 
  lg2.density=lg1.density; 
  lg2.ratio=lg1.ratio; 
  lg2.cn = 4; 
  lg2.ln = 4;      
  data2=zeros(0,lg1.ln); 
  delta_n = data1(1,lg1.n)-1; 
  for n_=1:length(data1); 
    n=data1(n_,lg1.n); 
      assert(n-n_ == delta_n); 
    if ~data1(n_,lg1.ok) continue, end
    ind_ = n-delta_n+(na:na+nd); 
    if max(ind_) > size(data1,1) break; end
    if all(data1(ind_,lg1.ok))
      data2=[data2; data1(n_,[lg1.n lg1.density lg1.ratio]), ...
        sum(data1(ind_,lg1.density).*data1(ind_,lg1.ratio))]; 
    end
  end
end