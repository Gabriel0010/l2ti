function model = solve4(X_tr,Y_tr,X_va,Y_va,method)
         assert(ismember(method,[1 2 4 5 6 7])); 
  if 1 == method
    lambda = 1e-3;
    model.A = OLS(X_tr,Y_tr,lambda); 
  elseif 2 == method
    fun1 = @(lambda)OLS(X_tr,Y_tr,exp(-lambda));
    if size(X_va,2)>size(X_tr,2)
      fun2 = @(lambda)[fun1(lambda)(1:end-1); zeros(size(X_va,2)-length(fun1(lambda)),1); fun1(lambda)(end)];
    else fun2 = @(lambda)fun1(lambda); 
    end
    fun3 = @(lambda)X_va*fun2(lambda); 
    fun4 = @(lambda)sum(abs(Y_va-fun3(lambda))); 
    lambda=exp(-fminbnd(fun4,-log(1e3),-log(1e-3)));     
         assert(lambda >= 1e-3); 
         assert(lambda <= 1e3); 
    model.lambda=lambda; 
    model.A = OLS(X_tr,Y_tr,lambda);          
  elseif 4 == method
    lambda = 1e-3;
    K_tr = size(X_tr,2)-1; 
    M4 = c_M4(K_tr);
    model.A = OLS_con(X_tr,Y_tr,lambda,M4); 
    model.M4 = M4; 
  elseif 5 == method
    lambda = 1e-3;
    A = LAD(X_tr,Y_tr,lambda); 
    model.A = A;
  elseif 6 == method
    fun1 = @(lambda)LAD(X_tr,Y_tr,exp(-lambda));
    if size(X_va,2)>size(X_tr,2)
      fun2 = @(lambda)[fun1(lambda)(1:end-1); zeros(size(X_va,2)-length(fun1(lambda)),1); fun1(lambda)(end)];
    else fun2 = @(lambda)fun1(lambda); 
    end
    fun3 = @(lambda)X_va*fun2(lambda); 
    fun4 = @(lambda)sum(abs(Y_va-fun3(lambda))); 
    lambda=exp(-fminbnd(fun4,-log(1e3),-log(1e-3)));     
         assert(lambda >= 1e-3); 
         assert(lambda <= 1e3); 
    model.lambda=lambda; 
    model.A = LAD(X_tr,Y_tr,lambda);   
  elseif 7 == method
    lambda = 1e-3;
    K_tr = size(X_tr,2)-1; 
    M4 = c_M4(K_tr);
    model.A = LAD_con(X_tr,Y_tr,lambda,M4); 
    model.M4 = M4;     
  end
end

function A = OLS(X,Y,lambda)
  K = size(X,2)-1; 
  Sigma = diag([ones(1,K) 0]); 
  A = inv(X'*X+2*lambda*Sigma)*(X'*Y); 
end


function A = LAD(X,Y,lambda)
  K = size(X,2)-1; 
  fun_obj=@(A)sum(abs(X*A-Y))+lambda*sum(abs(A));
  [A, fval, info, output, grad, hess] = fminunc (fun_obj,OLS(X,Y,lambda));   
end


function M4 = c_M4(K)
  M4=[diag([ones(1,K) 0]); zeros(1,K+1)]+[[zeros(1,K) 1]; diag([-ones(1,K) 1]) ]; 
end

function A=OLS_con(X,Y,lambda,M); 
  fun_obj=@(A)(X*A-Y)'*(X*A-Y)+lambda*A'*A; 
  A0 = OLS(X,Y,lambda);
  K=length(A0)-1; 
  for k=1:K
    A0(k) = min(A0(k:K)); 
  end
  A0(1:K) = A0(1:K) - min(A0(K),0); 
  A0(K+1) = max(A0(K+1),-A0(1));   
         assert(all(M*A0>=0));   
  A=A0;   
  lambda=1e-3; 
  fun=@(A)(Y-X*A)'*(Y-X*A)+lambda*A'*A; 
  [A, fval, cvg, outp]= fmincon (fun, A0, -M, zeros(K+2,1)); 
         assert(all(M*A>=-1e-10));   
end 

function A=LAD_con(X,Y,lambda,M); 
  A0 = OLS(X,Y,lambda);
  K=length(A0)-1; 
  for k=1:K
    A0(k) = min(A0(k:K)); 
  end
  A0(1:K) = A0(1:K) - min(A0(K),0); 
  A0(K+1) = max(A0(K+1),-A0(1));   
         assert(all(M*A0>=0));   
  A=A0;   
  lambda=1e-3; 
  fun_obj=@(A)sum(abs(X*A-Y))+lambda*sum(abs(A));
  [A, fval, cvg, outp]= fmincon (fun_obj, A0, -M, zeros(K+2,1)); 
         assert(all(M*A>=-1e-10));   
end 


