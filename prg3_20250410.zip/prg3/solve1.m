function model = solve1(X_tr,Y_tr,X_va,Y_va,method)
         assert(ismember(method,[1 2])); 
  if 1 == method
    lambda = 1e-3;
    model.A = OLS(X_tr,Y_tr,lambda); 
  elseif 2 == method
    fun1 = @(lambda)OLS(X_tr,Y_tr,exp(-lambda));
    if size(X_va,2)>size(X_tr,2)
      fun2 = @(lambda)[fun1(lambda)(1:end-1); zeros(size(X_va,2)-length(fun1(lambda)),1); fun1(lambda)(end)];
    else fun2 = @(lambda)fun1(lambda); 
    end
    fun3 = @(lambda)X_va*fun2(lambda); 
    fun4 = @(lambda)sum(abs(Y_va-fun3(lambda))); 
    lambda=exp(-fminbnd(fun4,-log(1e3),-log(1e-3)));     
         assert(lambda >= 1e-3); 
         assert(lambda <= 1e3); 
    model.lambda=lambda; 
    model.A = OLS(X_tr,Y_tr,lambda);          
  end
end

function A = OLS(X_tr,Y_tr,lambda)
  K_tr = size(X_tr,2)-1; 
  Sigma = diag([ones(1,K_tr) 0]); 
  A = inv(X_tr'*X_tr+2*lambda*Sigma)*(X_tr'*Y_tr); 
end