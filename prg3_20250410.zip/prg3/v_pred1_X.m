function v_pred1_X(X)
%% checks X with respect to pred1
         assert(all(all(ismember(X,[0 1])))); 
  ind=ceil(rand(1)*size(X,1));        
         assert(length(find(X(ind,:)~=0)) ==2); 
         assert(X(ind,end) == 1); 
end