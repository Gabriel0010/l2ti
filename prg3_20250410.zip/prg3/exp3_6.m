%%EXPERIMENT
clear
number=6; 
%cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=1; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
K_tr=size(X_tr,2)-1; 
M_tr=[diag([ones(1,K_tr) 0]); zeros(1,K_tr+1)]+[[zeros(1,K_tr) 1]; diag([-ones(1,K_tr) 1]) ]; 
reci = 0; 
for k=1:1e4
  A=randn(K_tr+1,1); 
  model_rnd.A=A; 
  Y_tr_pr = pred1(X_tr,model_rnd,method);
  test1 = all(M_tr*A >= 0); 
  test2a = all(Y_tr_pr >= 0); 
  X_p_tr=X_tr+ones(size(X_tr)); 
  Y_p_tr_pr = pred1(X_p_tr,model_rnd,method);
  test2b = all(Y_p_tr_pr >= Y_tr_pr); 
  test2 = test2a && test2b; 
  test3a = (-A(end) <= A(1)); 
  test3b = all( A(1:end-2) <= A(2:end-1) ); 
  test3c = (A(end-1) <= 0); 
  test3d = (0 <= A(end)); 
  test3 = (test3a && test3b && test3c && test3d); 
  assert(test1 == test3);
  assert( test2||~test1 ); 
  if ~test2&&test1 disp('False reciprocal'), reci -= 1; end
end


