function [X,Y]=read_data1(data,lg,method,dataset)
  if 3 == nargin dataset = 1; end
  assert(ismember(method,[1 2 3 4 5 6 7])); 
  assert(ismember(dataset,[1 2])); 
  if 1 == dataset 
    x_val = data(:,lg.density);
  elseif 2 == dataset 
    x_val = round(data(:,lg.density).*data(:,lg.ratio)); 
  end
  if ismember(method,[1 2 3 4 5 6 7])
    K=max(data(:,lg.density)); 
    N=size(data,1); 
    X=[zeros(N,K) ones(N,1)];
    for k=0:(K-1)
      X(:,k+1) = (x_val == k); 
    end
    Y=data(:,lg.cn); 
  else error('read_data1'), 
  end
end
