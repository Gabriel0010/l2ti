function v_pred1()
  K=ceil(rand(1)*10)+1; 
  A=randn(K+1,1); 
  model.A=A; 
  X_ex1=[1 1]; 
  v_pred1_X(X_ex1); 
         assert(pred1(X_ex1,model,1),A(1)+A(end),1e-12); 
  K2=ceil(rand(1)*10)+1; 
  X_ex2=[zeros(1,K2) 1 1]; 
  v_pred1_X(X_ex2); 
  if ~(abs(pred1(X_ex2,model,1)-A(end))<1e-12)
         assert(pred1(X_ex2,model,1),A(K2+1)+A(end),1e-12); 
  end
end