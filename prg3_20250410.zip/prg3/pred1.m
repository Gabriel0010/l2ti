function Y = pred1(X,model,method)
         assert(ismember(method,[1 2 4 5 6 7])); 
         v_pred1_X(X); 
  if ismember(method,[1 2 4 5 6 7])
    A = model.A; 
    if size(X,2) > length(A)
      A = [A(1:end-1); zeros(size(X,2)-length(A),1); A(end)]; 
    elseif size(X,2) < length(A)
      K = size(X,2)-1; 
      A = [A(1:K); A(end)]; 
    end
    Y = X*A;
  end
end
