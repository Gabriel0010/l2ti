function v_read_data1()
  T=load('exp3_12.mat'); 
  method1 = ceil(rand(1)*7); 
  [X1,Y1]=read_data1(T.data_tr,T.lg_tr,method1);
  method2 = ceil(rand(1)*7); 
  [X2,Y2]=read_data1(T.data_tr,T.lg_tr,method2);
         assert(size(X1) == size(X2)); 
         assert(all(X1 == X2)); 
         assert(size(Y1) == size(Y2)); 
         assert(all(Y1 == Y2)); 
         assert(all(ceil(Y1) == Y1)); 
  v_pred1_X(X1); 
  ind = ceil(rand(1)*size(T.data_tr,1)); 
         assert(X1(ind,1+round(T.data_tr(ind,T.lg_tr.density))) == 1);
  [X3,Y3]=read_data1(T.data_tr,T.lg_tr,method1,2);         
  v_pred1_X(X3); 
  x_val = T.data_tr(ind,T.lg_tr.density).*T.data_tr(ind,T.lg_tr.ratio); 
         assert(round(x_val),x_val,1e-12); 
         assert(X3(ind,1+round(x_val)) == 1); 
end