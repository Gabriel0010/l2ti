function t=data2time(data,lg)
%computes for each sample
%the time since the beginning of the year 2021
%in seconds
  days=datenum(data(:,lg.year)-2021,data(:,lg.month),data(:,lg.day),...
    data(:,lg.hour),data(:,lg.minute)); 
  t=(days-1)*24*3600; 
end
