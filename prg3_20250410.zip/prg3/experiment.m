%%EXPERIMENT
clear 
number=1; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
rep=['../dataset/']; 
%T=load([rep,'exp1.mat'],'data','lg'); %->1-8days
T=load([rep,'exp5b.mat'],'data','lg'); %->Jan-June
t1=data2time(T.data(1,:),T.lg); 
t2=t1+15*24*60*60; 
t3=t2+15*24*60*60; 
t4=t3+15*24*60*60; 
fe=1/60/5; 
limit=[]; 
[data_tr,lg_tr]=split_data4(T.data,T.lg,fe,[t1 t2],limit); 
[data_va,lg_va]=split_data4(T.data,T.lg,fe,[t2 t3],limit); 
[data_te,lg_te]=split_data4(T.data,T.lg,fe,[t3 t4],limit); 
save exp3_1.mat data_tr lg_tr data_va lg_va data_te lg_te; 

%%EXPERIMENT
clear
number=2; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_1.mat'); 
[data_tr,lg_tr]=c_cn(T.data_tr,T.lg_tr);
[data_va,lg_va]=c_cn(T.data_va,T.lg_va);
[data_te,lg_te]=c_cn(T.data_te,T.lg_te);
save exp3_2.mat data_tr lg_tr data_va lg_va data_te lg_te; 


%%EXPERIMENT
clear
number=3; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
for k=1:100
  v_c_cn(); 
end

%%EXPERIMENT
clear
number=4; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=1; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(1); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(1,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_4_fig1.png'); 
Y_pr = pred1(X_te,model_tr,method); %min(Y_pr) 0.726
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %8.20
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %8.15
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %10.47
method=2; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); %lambda = 0.0022762
Y_pr = pred1(X_te,model_tr,method); %min(Y_pr) 0.726
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %8.20
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %8.14
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %10.54
figure(2); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(2,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_4_fig2.png'); 

%%EXPERIMENT
clear
number=5; 
%cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=1; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
K_tr=size(X_tr,2)-1; 
M_tr=[diag(ones(1,K_tr)) ones(K_tr,1)]; 
reci = 0; 
for k=1:1e4
  A=randn(K_tr+1,1); 
  model_rnd.A=A; 
  Y_tr_pr = pred1(X_tr,model_rnd,method);
  test1 = all(M_tr*A >= 0); 
  test2 = all(Y_tr_pr >= 0); 
  assert( test2||~test1 ); 
  if ~test2&&test1 disp('False reciprocal'), reci -= 1; end
end



%%EXPERIMENT
clear
number=6; 
%cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=1; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
K_tr=size(X_tr,2)-1; 
M_tr=[diag([ones(1,K_tr) 0]); zeros(1,K_tr+1)]+[[zeros(1,K_tr) 1]; diag([-ones(1,K_tr) 1]) ]; 
reci = 0; 
for k=1:1e4
  A=randn(K_tr+1,1); 
  model_rnd.A=A; 
  Y_tr_pr = pred1(X_tr,model_rnd,method);
  test1 = all(M_tr*A >= 0); 
  test2a = all(Y_tr_pr >= 0); 
  X_p_tr=X_tr+ones(size(X_tr)); 
  Y_p_tr_pr = pred1(X_p_tr,model_rnd,method);
  test2b = all(Y_p_tr_pr >= Y_tr_pr); 
  test2 = test2a && test2b; 
  test3a = (-A(end) <= A(1)); 
  test3b = all( A(1:end-2) <= A(2:end-1) ); 
  test3c = (A(end-1) <= 0); 
  test3d = (0 <= A(end)); 
  test3 = (test3a && test3b && test3c && test3d); 
  assert(test1 == test3);
  assert( test2||~test1 ); 
  if ~test2&&test1 disp('False reciprocal'), reci -= 1; end
end


%%EXPERIMENT
clear
number=7; 
pkg load optim
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=4; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
Y_pr = pred1(X_te,model_tr,method); %min(Y_pr) 0.2
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %10.67
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %9.65
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %12.70
figure(4); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
axis([0 Inf 0 140])
set(gca,'fontsize',20); 
saveas(4,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_7_fig4.png'); 



%%EXPERIMENT
clear
number=8; 
pkg load optim
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=5; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %5e-07
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %8.03
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %7.90
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %10.27
figure(5); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
axis([0 Inf 0 140])
set(gca,'fontsize',20); 
saveas(5,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_8_fig5.png'); 



%%EXPERIMENT
clear
number=9; 
pkg load optim
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=6; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); model_tr.lambda, %2.1713e-03
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %3e-7
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %8.00
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %7.82
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %10.38
figure(6); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
axis([0 Inf 0 140])
set(gca,'fontsize',20); 
saveas(6,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_9_fig6.png'); 




%%EXPERIMENT
clear
number=10; 
pkg load optim
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_2.mat'); 
method=7; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), % 0.72
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %10.48
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %8.61
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %13.81
figure(7); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
axis([0 Inf 0 140])
set(gca,'fontsize',20); 
saveas(7,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_10_fig7.png'); 




%%EXPERIMENT
clear 
number=11; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
rep=['../dataset/']; 
%T=load([rep,'exp1.mat'],'data','lg'); %->1-8days
T=load([rep,'exp5b.mat'],'data','lg'); %->Jan-June
t1=data2time(T.data(1,:),T.lg); 
t2=t1+15*24*60*60; 
t3=t2+15*24*60*60; 
t4=t3+15*24*60*60; 
fe=1/60/5; 
limit=[80]; 
[data_tr,lg_tr]=split_data4(T.data,T.lg,fe,[t1 t2],limit); 
[data_va,lg_va]=split_data4(T.data,T.lg,fe,[t2 t3],limit); 
[data_te,lg_te]=split_data4(T.data,T.lg,fe,[t3 t4],limit); 
save exp3_11.mat data_tr lg_tr data_va lg_va data_te lg_te; 


%%EXPERIMENT
clear
number=12; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_11.mat'); 
[data_tr,lg_tr]=c_cn(T.data_tr,T.lg_tr);
[data_va,lg_va]=c_cn(T.data_va,T.lg_va);
[data_te,lg_te]=c_cn(T.data_te,T.lg_te);
save exp3_12.mat data_tr lg_tr data_va lg_va data_te lg_te; 




%%EXPERIMENT
clear
number=13; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=1; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(1); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(1,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_13_fig1.png'); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %0.277
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %0.732
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %0.637
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %0.539


%%EXPERIMENT
clear
number=14; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=4; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(4); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(4,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_14_fig4.png'); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %8e-4
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %3.365
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %2.059
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %1.25



%%EXPERIMENT
clear
number=15; 
pkg load optim
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=5; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %8e-06
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %0.572
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %0.422
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %0.304
figure(5); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
axis([0 Inf 0 60])
set(gca,'fontsize',20); 
saveas(5,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_15_fig5.png'); 

%%EXPERIMENT
clear
number=16; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
v_read_data1();
for k=1:1e3
  v_pred1(); 
end



%%EXPERIMENT
clear
number=17; 
pkg load optim
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=7; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %0
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %3.450
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %2.109
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %1.28
figure(7); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
axis([0 Inf 0 60])
set(gca,'fontsize',20); 
saveas(7,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_17_fig7.png'); 



%%EXPERIMENT
clear
number=18; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=1; dataset=2; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method,dataset); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method,dataset); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method,dataset); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(1); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(1,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_18_fig1.png'); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %0.397
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %0.935
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %0.642
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %0.576




%%EXPERIMENT
clear
number=19; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=4; dataset=2; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method,dataset); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method,dataset); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method,dataset); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(4); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(4,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_19_fig4.png'); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %0.494
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %1.021
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %0.717
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %0.657



%%EXPERIMENT
clear
number=20; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=5; dataset=2; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method,dataset); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method,dataset); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method,dataset); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(5); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(5,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_20_fig5.png'); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %2e-6
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %0.708
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %0.339
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %0.242



%%EXPERIMENT
clear
number=21; 
disp(['number=',num2str(number)]),
cd C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3
%cd ~/A/SIMU_Y/MANSOUR/traffic/prg3
T=load('exp3_12.mat'); 
method=7; dataset=2; 
[X_tr,Y_tr]=read_data1(T.data_tr,T.lg_tr,method,dataset); 
[X_va,Y_va]=read_data1(T.data_va,T.lg_va,method,dataset); 
[X_te,Y_te]=read_data1(T.data_te,T.lg_te,method,dataset); 
model_tr = solve4(X_tr,Y_tr,X_va,Y_va,method); 
figure(7); 
K=length(model_tr.A)-1; 
plot(1:K,model_tr.A(1:end-1)+model_tr.A(end),'b-','linewidth',2); 
set(gca,'fontsize',20); 
saveas(7,'C:\A\SIMU\SIMU_Y\MANSOUR\traffic\prg3\exp3_21_fig7.png'); 
Y_pr = pred1(X_te,model_tr,method); min(Y_pr), %0
Y_tr_pr = pred1(X_tr,model_tr,method); sum(abs(Y_tr_pr-Y_tr))/length(Y_tr), %0.738
Y_va_pr = pred1(X_va,model_tr,method); sum(abs(Y_va_pr-Y_va))/length(Y_va), %0.338
dev(method) = sum(abs(Y_pr-Y_te))/length(Y_te), %0.241
