function [data,lg]=split_data4(data1,lg1,fe,time_interval,limit)
%data1 is a table
%lg1 is its legend
%fe is sampling frequency in second
%limit is the speed limit considered
%time_interval start and end of experiment
%cond is replaced by a function testing if the speed is exceeded by more than 5%
%ok means maximum speed is as expected.
  if ~isempty(limit)
    assert(ismember(limit,[30,50,80,90,110,130])); 
  end
  lg.density=2; 
  lg.ratio=3; 
  lg.n=1; 
  lg.ok=4; 
  lg.ln=4; 
  lg.p_fe=fe; 
  lg.p_time_interval=time_interval; 
  lg.p_limit=limit; 
  if isempty(time_interval)
    t1=data2time(data1(1,:),lg1); 
    t2=data2time(data1(end,:),lg1)+1e-8; 
    lg.p_TI=[t1,t2]; 
  else 
    lg.p_TI=time_interval; 
  end
  lg.p_limit=limit; 
  i=1; 
  n1 = floor(lg.p_TI(1)*lg.p_fe); n2 = ceil(lg.p_TI(2)*lg.p_fe); 
         assert(n1/lg.p_fe>=lg.p_TI(1)-1/lg.p_fe); 
         assert(n2/lg.p_fe<=lg.p_TI(2)+1/lg.p_fe); 
  data=zeros(n2-n1+1,lg.ln);
  tic,  
  for n = n1:n2
    d=0; r=0; 
    [i,d,r,ok] = update2(i,d,r,n,data1,lg1,lg); 
    [d,r] =  post_process(d,r); 
    data(n-n1+1,:) = [n d r ok]; 
    if toc - tic >1*60
      disp(num2str([toc,(n-n1)/(n2-n1+1)])),
      tic,
    end
  end
end

function [i,d,r,ok] = update_(i,d,r,n,data1,lg1,lg)
  while (1)
    if i > size(data1,1) return; end
    t = data2time(data1(i,:),lg1); 
    t1 = max(n/lg.p_fe,lg.p_TI(1)); 
    t2 = min((n+1)/lg.p_fe,lg.p_TI(2)); 
    if     t < t1 i += 1;
    elseif t < t2 
      if isempty(lg.p_limit)||(data1(i,lg1.limit) == lg.p_limit)
        d += 1;
        if cond_(data1(i,lg1.speed),data1(i,lg1.limit))
          r += 1; 
        end
      end
      i += 1; 
    else 
      return; 
    end
  end
end

function [i,d,r,ok] = update2(i,d,r,n,data1,lg1,lg)
  ok=1; 
  while (1)
    if i > size(data1,1) return; end
    t = data2time(data1(i,:),lg1); 
    t1 = max(n/lg.p_fe,lg.p_TI(1)); 
    t2 = min((n+1)/lg.p_fe,lg.p_TI(2)); 
    if     t < t1 i += 1;
    elseif t < t2 
      if isempty(lg.p_limit)||(data1(i,lg1.limit) == lg.p_limit)
        d += 1;
        if cond_(data1(i,lg1.speed),data1(i,lg1.limit))
          r += 1; 
        end
      else 
        ok=0; 
      end
      i += 1; 
    else 
      return; 
    end
  end
end



function test = cond_(v,v_max)
%%returns true if driver is too fast
  if v_max < 100
    test = ~(v < v_max+5); 
  else 
    test = ~(v < v_max*1.05); 
  end
end


function [d,r] =  post_process(d,r)
  assert(r <= d); 
  assert(r >= 0); 
  if 0 == d 
    r = -1; 
  else 
    r = r / d; 
  end
end

