function graph2(d)
  figure(1); 
  delete(1); 
  figure(1); 
  set(gca,'fontsize',20); 
  hold on; 
  if d.P_nb>=2
    for k=0:d.P_nb-2
      plot_seg(d.P(k+1,:),d.P(k+2,:)); 
      plot_pt(d.P(k+1,:),['P_',num2str(k)]); 
    end
  end
  plot_pt(d.P(d.P_nb,:),['P_',num2str(d.P_nb-1)]); 
  plot_pt(d.M,'M'); 
  axis('equal'); 
  hold off; 
end



