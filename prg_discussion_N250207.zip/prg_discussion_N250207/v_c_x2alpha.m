function v_c_x2alpha()
  rho=10^(2*rand(1))*rand(1); 
  c=10^(2*rand(1))*rand(1); 
  gamma=rand(1)*pi; 
  x=10^(2*rand(1))*rand(1); 
  [alpha,ok]=c_x2alpha(x,c,gamma,rho); 
  if ok 
    assert(c*sin(alpha+gamma),rho+x*sin(alpha),1e-12); 
  else
    assert(~((x>=0)&&(rho<c*sin(gamma)))); 
    % alpha_opt=pi/2; val_opt=Inf; 
    % K=1e3; 
    % for k=1:K
      % epsi=10^(-5*rand(1)); 
      % alpha=max(0,min(pi,alpha_opt+epsi)); 
      % val=(c*sin(alpha+gamma)-(rho+x*sin(alpha)))^2; 
      % if val<val_opt val_opt=val; alpha_opt=alpha; end
      % if val_opt<10 K=1e4; end
      % if val_opt<1  K=1e5; end
      % if toc>30 
        % disp(['v_c_s2alpha',' k=',num2str(k),' k_max=',num2str(K),' val_opt=',num2str(val_opt)])
        % tic,
      % end
    % end
    % assert(val_opt>1e-8); 
  end
end