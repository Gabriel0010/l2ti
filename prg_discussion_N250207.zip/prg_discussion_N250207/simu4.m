function [d,ok]=simu4()
%%cette fonction choisit aléatoire un certain nombre de points
%%les données sont sauvegardées dans une structure notee d. 
  d.P_nb=1+ceil(rand(1)*4); 
  d.P=randn(d.P_nb,2); 
  S=zeros(d.P_nb-1,1); 
  s=0; 
  S(1) = s; 
  for k_=0:d.P_nb-2
    s += norm(d.P(k_+2,:)-d.P(k_+1,:)); 
    S(k_+2) = s; 
  end
  d.S=S; 
  ok=true; 
  
end