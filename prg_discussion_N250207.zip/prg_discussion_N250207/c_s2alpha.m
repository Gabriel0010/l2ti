function [alpha,ok]=c_s2alpha(s,c,gamma,rho)
%solves the equation 
%csin(alpha+gamma)=rho+s sin(alpha)
%ok=0 => no solution
  alpha=NaN; ok=0; 
  fun=@(x)c*sin(x+gamma)-rho-s*sin(x); 
  if c*sin(gamma)>= rho ok=1; x0=[0 pi]; 
  end
  if c*cos(gamma)-s>=0
    x_max=atan((c*cos(gamma)-s)/sin(gamma)); 
  else
    x_max=pi+atan((c*cos(gamma)-s)/sin(gamma)); 
  end
         assert(x_max>=0); 
         assert(x_max<=pi); 
  if fun(x_max)>=0
    ok=1; 
    x0=[x_max pi]; 
  end
         assert(fun(pi)<=0); 
  if ok 
     [alpha, fval, info, output] = fzero (fun,x0); 
  end
end