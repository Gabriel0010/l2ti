function graph1(d)
  figure(1); 
  delete(1); 
  figure(1); 
  set(gca,'fontsize',20); 
  hold on; 
  plot_seg(d.P,d.M); plot_seg(d.P,d.Mp); plot_seg(d.P,d.O); 
  plot_pt(d.P,'P'); plot_pt(d.M,'M'); plot_pt(d.Mp,'M'''); plot_pt(d.O,'O'); 
  plot_pt(d.Op,'O'''); plot_seg(d.O,d.Op); plot_seg(d.M,d.Mp); 
  axis('equal'); 
  hold off; 
end

function plot_seg(A,B)
  plot([A(1) B(1)],[A(2),B(2)],'b-','linewidth',2); 
end

function plot_pt(A,str)
  text(A(1),A(2),str,'fontsize',20);
end

