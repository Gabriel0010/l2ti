function ok=est_aligne(A,B,C)
% fonction vérifie sur A,B,C sont alignés
  val1=det([B-A,C-A])/norm(B-A)/norm(C-A); 
  ok = (abs(val1)<1e-7); 
end
