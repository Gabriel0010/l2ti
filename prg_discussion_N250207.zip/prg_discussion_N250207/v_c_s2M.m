function v_c_s2M()
  [data,ok]=simu5();
         assert(ok,true); 
  s1=rand(1)*data.S(end); 
  s2=rand(1)*data.S(end); 
  M1=c_s2M(s1,data); 
  M2=c_s2M(s2,data); 
         assert(norm(M1-M2)<=abs(s1-s2)+1e-10); 
  epsi=1e-3; 
  if s1+epsi<data.S(end)-1e-9
    M3=c_s2M(s1+epsi,data); 
         assert(norm(M1-M3)<=epsi*(1+1e-8)); 
  end
  s4=rand(1)*data.S(1); 
  M4=c_s2M(s4,data); 
         assert(norm(M4-data.P(1,:)),s4,1e-10); 
         assert(norm(M4-data.P(2,:)),data.S(2)-s4,1e-10); 
  [k4,ok]=c_kappa(s4,data); 
         assert(k4,0,1e-10); 
  s5=data.S(2)+rand(1)*(data.S(3)-data.S(2)); 
  M5=c_s2M(s5,data); 
         assert(c_s2M(data.S(2),data),data.P(2,:),1e-10); 
         assert(norm(M5-data.P(2,:)),s5-data.S(2),1e-10); 
  [k5,ok]=c_kappa(s5,data); 
         assert(k5,1,1e-10); 
end