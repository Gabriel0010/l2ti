function [alpha,ok]=c_x2alpha(x,c,gamma,rho)
%solves the equation 
%csin(alpha+gamma)=rho+x* sin(alpha)
%ok=0 => no solution
  ok= (rho<c*sin(gamma))&&(x>=0); 
  if ~ok alpha=NaN; return; end
  fun=@(alpha)(c*sin(alpha+gamma)-rho)/sin(alpha)-x; 
  x0=[0 pi-gamma];
  [alpha, fval, info, output] = fzero (fun,x0);
end