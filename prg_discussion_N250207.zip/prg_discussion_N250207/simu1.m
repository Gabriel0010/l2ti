function [d,ok]=simu1()
%simule des points géométriques
%ok=1 si O est dans le secteur MPM'
  d.P=randn(2,1); 
  d.M=randn(2,1); 
  d.Mp=randn(2,1); 
  d.alpha=c_angle(d.Mp,d.M,d.P); 
         assert(d.alpha>=0); 
         assert(d.alpha<=pi); 
  d.s=norm(d.P-d.M); 
  d.sp=norm(d.Mp-d.P); 
  d.beta=pi-c_angle(d.M,d.P,d.Mp); 
  d.O=randn(2,1); 
  conda = (det([d.O-d.P d.M-d.P])*det([d.Mp-d.P d.M-d.P])>0);   
  condb = (det([d.O-d.P d.Mp-d.P])*det([d.M-d.P d.Mp-d.P])>0);   
  condc = (d.O-d.M)'*(d.Mp-d.M)>0;
  condd = (d.O-d.Mp)'*(d.M-d.Mp)>0;
  conde = (det([d.Mp-d.M d.O-d.M])*det([d.Mp-d.M d.P-d.M])<0); 
  ok = conda && condb && condc && condd && conde; 
  cond3 = abs(c_angle(d.M,d.P,d.O)+c_angle(d.O,d.P,d.Mp)-c_angle(d.M,d.P,d.Mp)) < 1e-10; 
  implies=@(t1,t2)t2||(!t1); 
         assert(implies(ok,cond3)); 
  if ok 
    d.gamma = c_angle(d.M,d.P,d.O); 
    d.Op=proj(d.O,d.M,(d.Mp-d.M)/norm(d.Mp-d.M)); 
         assert(est_aligne(d.M,d.Mp,d.Op));
    %d.M+(d.Mp-d.M)'*(d.O-d.M)*(d.Mp-d.M)/norm(d.Mp-d.M)^2/norm(d.O-d.M); 
         assert(norm(d.Op-d.M)^2+norm(d.Op-d.O)^2,norm(d.O-d.M)^2,1e-10); 
         assert(norm(d.Op-d.M)+norm(d.Mp-d.Op),norm(d.Mp-d.M),1e-10); 
    d.rho=norm(d.Op-d.O); 
    d.c=norm(d.O-d.P); 
    d.Opp=intersection(d.M,(d.Mp-d.M)/norm(d.Mp-d.M),d.P,(d.O-d.P)/norm(d.O-d.P)); 
         assert(est_aligne(d.M,d.Opp,d.Mp)); 
         assert(est_aligne(d.P,d.Opp,d.O)); 
    d.c1=norm(d.P-d.Opp); 
    d.c2=norm(d.O-d.Opp);     
  end  
  %d.gamma=
  %ok=1; 
end


