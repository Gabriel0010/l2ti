function v_est_dans_cone()
  A=10^(2*rand(1))*randn(2,1); 
  u=randn(2,1); u=u/norm(u); 
  v=randn(2,1); v=v/norm(v); 
  lambda=10^(2*rand(1))*rand(1); 
  mu=10^(2*rand(1))*rand(1); 
         assert(est_dans_cone(A+lambda*u+mu*v,A,u,v),true); 
         assert(est_dans_cone(A-lambda*u+mu*v,A,u,v),false); 
         assert(est_dans_cone(A-lambda*u-mu*v,A,u,v),false); 
         assert(est_dans_cone(A+lambda*u-mu*v,A,u,v),false); 
end