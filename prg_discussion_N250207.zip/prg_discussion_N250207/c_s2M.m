function [M,ok]=c_s2M(s,data)
         assert(size(s),[1 1]); 
  [k,ok]=c_kappa(s,data); 
  if ~ok M=NaN; return; end
         assert(k<=data.P_nb-2); 
  u=data.P(k+2,:)-data.P(k+1,:); u /= norm(u); 
  M=data.P(k+1,:)+(s-data.S(k+1))*u; 
end