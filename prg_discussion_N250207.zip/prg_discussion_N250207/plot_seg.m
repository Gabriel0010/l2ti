function plot_seg(A,B)
  plot([A(1) B(1)],[A(2),B(2)],'b-','linewidth',2); 
end
