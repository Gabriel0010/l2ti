function [d,ok]=simu3()
%simule des points géométriques
%ne spécifie pas la valeur de x
%les points sont des fonctions de x
%ok=1 si O est dans le secteur MPM'
  CONTINUE = true; 
  while(CONTINUE)
    CONTINUE = false; 
    d.P=randn(2,1); 
    d.O=randn(2,1); 
    d.rho=rand(1); 
    u=randn(2,1); u=u/norm(u); d.u=u; %MP 
    v=randn(2,1); v=v/norm(v); d.v=v; %PM'
    d.beta=c_angle(d.P+v,d.P,d.P+u); 
    d.gamma=c_angle(d.O,d.P,d.P-u); 
    d.c=norm(d.O-d.P);   
    if ~(d.c>d.rho) CONTINUE = true; end
    if ~est_dans_cone(d.O,d.P,-u,v) CONTINUE = true; end
    if ~(d.rho<d.c*sin(d.gamma)) CONTINUE = true; end
  end
  ok=(d.c*sin(d.beta+d.gamma)>=d.rho); 
  if ok
    %d.x=(d.c*sin(d.beta+d.gamma)-d.rho)/sin(d.beta)+epsi*d.c; 
    fun=@(alpha)(d.c*sin(alpha+d.gamma)-d.rho)/sin(alpha); 
    d.ok=@(x)(fun(d.beta)<=x); 
    d.alpha=@(x)c_x2alpha(x,d.c,d.gamma,d.rho); 
    d.M=@(x)d.P-x*u; 
    d.y=@(x)x*sin(d.alpha(x))/sin(d.beta-d.alpha(x)); 
    d.Mp=@(x)d.P+d.y(x)*v; 
    d.Op=@(x)proj(d.O,d.M(x),(d.Mp(x)-d.M(x))/norm(d.Mp(x)-d.M(x))); 
    d.Opp=@(x)intersection(d.M(x),(d.Mp(x)-d.M(x))/norm(d.Mp(x)-d.M(x)),d.P,(d.O-d.P)/norm(d.O-d.P)); 
    d.c1=@(x)norm(d.P-d.Opp(x)); 
    d.c2=@(x)norm(d.O-d.Opp(x));
    
  end
end



