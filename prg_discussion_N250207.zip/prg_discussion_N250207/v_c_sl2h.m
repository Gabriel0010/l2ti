function v_c_sl2h()
  [data,ok]=simu5();
         assert(ok,true); 
  s=data.S(end)*rand(1); 
  [hm,hp]=c_sl2h(s,0,data); 
         assert(hm>=0); 
         assert(hp>=0); 
  [M,ok]=c_s2M(s,data); 
         assert(ok,true);    
  if s-hm>0
    [Mp,ok]=c_s2M(s-hm,data); 
         assert(c_kappa(s-hm,data)+1,c_kappa(s,data))
    u=Mp-M; u /= norm(u); 
    O=data.O(1,:); 
    Op = proj(O',Mp',u'); 
         assert(est_aligne(M',Mp',Op)); 
    P=data.P(c_kappa(s,data)+1,:); 
         assert(est_dans_cone2(Op,P',Mp',M')); 
    verif1(s,0,data,P',M',Mp',O',data.rho,hm);          
         assert(est_dans_seg(Op,M',Mp'));
         assert(norm(data.O(1,:)'-Op),data.rho,1e-10); 
         disp('test ok'),
  end
  if s+hp<data.S(end)
    [Mp,ok]=c_s2M(s+hp,data); 
         assert(c_kappa(s+hp,data)-1,c_kappa(s,data))
    u=Mp-M; u /= norm(u); 
    O=data.O(1,:); 
    Op = proj(O',M',u'); 
         assert(est_aligne(M',Mp',Op)); 
    P=data.P(c_kappa(s,data)+2,:); 
    verif2(s,0,data,P',M',Mp',O',data.rho,hp);          
         assert(est_dans_cone2(Op,P',M',Mp')); 
         assert(est_dans_seg(Op,M',Mp'));
         assert(norm(data.O(1,:)'-Op),data.rho,1e-10);   
         disp('test ok'),
  end       
end

function verif1(s,l,data,P,M,Mp,O,rho,hm)
  k=c_kappa(s,data); 
  c=norm(data.P(k+1,:)-data.O(l+1,:));   
  gamma=c_angle(data.O(l+1,:)',data.P(k+1,:)',data.P(k+2,:)'); 
      assert(data.rho < c*sin(gamma)); 
  beta=pi-c_angle(data.P(k,:)',data.P(k+1,:)',data.P(k+2,:)'); 
  x=s-data.S(k+1); 
  alpha= c_x2alpha(x,c,gamma,data.rho); 
      assert(rho,data.rho); 
      assert(P,data.P(k+1,:)'); 
      assert(O,data.O(l+1,:)'); 
      assert(c_s2M(s-hm,data)',Mp,1e-10); 
      assert(x,norm(M-P),1e-10); 
  verif3(P,M,Mp,O,data.rho,alpha,beta,gamma,c);        
    
end


function verif2(s,l,data,P,M,Mp,O,rho,hp)
  k=c_kappa(s,data); 
  c=norm(data.P(k+2,:)-data.O(l+1,:));   
  gamma=c_angle(data.P(k+1,:)',data.P(k+2,:)',data.O(l+1,:)'); 
      assert(data.rho < c*sin(gamma)); 
  beta=pi-c_angle(data.P(k+1,:)',data.P(k+2,:)',data.P(k+3,:)'); 
  x=data.S(k+2)-s; 
  alpha=c_x2alpha(x,c,gamma,data.rho); 
  f=x*sin(alpha)/sin(beta-alpha); 
  u=Mp-M; u /= norm(u); 
      assert(O,data.O(1,:)',1e-10); 
  Op = proj(O,M,u); 
  Op1 = proj(O,M,(Mp-M)/norm(Mp-M)); 
      assert(norm(data.O(1,:)'-Op),data.rho,1e-6); 
      assert(norm(O-Op1),rho,1e-10); 
      assert(O,data.O(l+1,:)',1e-10); 
      assert(hp,x+f,1e-12); 
      assert(M,c_s2M(s,data)',1e-10); 
      assert(P,c_s2M(data.S(k+2),data)',1e-10); 
      assert(P,c_s2M(s+x,data)',1e-10); 
      assert(Mp,c_s2M(s+hp,data)',1e-10); 
      assert(rho,data.rho); 
      assert(c_kappa(s,data)+1,c_kappa(s+hp,data),1e-12); 
      assert(norm(Mp-P),s+hp-s-x,1e-10); 
      assert(P,data.P(k+2,:)'); 
      assert(O,data.O(l+1,:)'); 
      assert(x,norm(P-M),1e-10); 
      assert(alpha<=beta); 
  beta_ctr=c_angle(P+P-M,P,Mp); 
      assert(beta,beta_ctr,1e-10); 
      assert(gamma,c_angle(M,P,O),1e-10); 
      assert(c,norm(P-O),1e-10); 
      assert(c*sin(alpha+gamma),rho+x*sin(alpha),1e-12); 
      assert(x>=(c*sin(beta+gamma)-rho)/sin(beta)); 
      assert(alpha,c_angle(P,M,Mp),1e-10); 
      assert(norm(P-Mp),f,1e-10); 
      assert(est_dans_seg(M,P,data.P(k+1,:)')); 
      assert(est_dans_seg(Mp,P,data.P(k+3,:)')); 
    u=data.P(k+1,:)-P'; u /= norm(u);    
    v=data.P(k+3,:)-P'; v /= norm(v);
      assert(est_dans_cone(O,P,u',v'));
    verif3(P,M,Mp,O,data.rho,alpha,beta,gamma,c);        
      
end


function verif3(P,M,Mp,O,rho,alpha,beta,gamma,c)
         assert(est_dans_cone2(O,P,M,Mp)); 
  Op = proj(O,M,(Mp-M)/norm(Mp-M)); 
         assert(c,norm(P-O),1e-10); 
         assert(alpha,c_angle(P,M,Mp),1e-10); 
         assert(gamma,c_angle(M,P,O),1e-10); 
         Opp=intersection(M,(Mp-M)/norm(Mp-M),P,(O-P)/norm(O-P)); 
         assert(est_dans_seg(Opp,M,Mp)); 
         assert(est_aligne(Opp,M,Mp)); 
         assert(est_dans_seg(Opp,P,O)); 
         c1=norm(Opp-P); 
         x=norm(P-M); 
         y=norm(P-Mp); 
         assert(alpha+gamma<=pi); 
         assert(c_angle(Mp,M,P),c_angle(Opp,M,P),1e-10); 
         assert(alpha,c_angle(Opp,M,P),1e-10); 
         assert(sin(pi-alpha-gamma)/x,sin(alpha)/c1,1e-10); 
         assert(sin(gamma)/norm(Opp-M),sin(alpha)/c1,1e-10); 
         assert(sin(alpha)/y,sin(beta-alpha)/x,1e-10); 
         assert(abs(pi/2-alpha-gamma),abs(c_angle(Op,O,Opp)),1e-10); 
         assert(c1<=c); 
         assert(rho,(c-c1)*cos(pi/2-alpha-gamma),1e-10); 
         assert(rho,(c-c1)*sin(alpha+gamma),1e-10); 
         assert(c-c1,norm(O-Opp),1e-10); 
         assert(rho,norm(O-Op),1e-10); 
end