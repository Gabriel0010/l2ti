function ok=est_dans_cone2(M,A,B,C)
%vérifie que ce point est dans ce cône AB,AC
  u=(B-A)/norm(B-A); 
  v=(C-A)/norm(C-A); 
  ok = est_dans_cone(M,A,u,v); 
end