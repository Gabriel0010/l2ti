function [k,ok]=c_kappa(s,data)
%cette fonction identifie la branche du chemin où l'on se trouve. 
%ok=0 signifie que s<0 ou que s>S
  if (s<0)||(s>data.S(end)) 
    ok=false; k=NaN; return; 
  end
  dist=0; ok=true; 
  for k=0:(data.P_nb-1)
    if data.S(k+2) >= s return; end
  end
end