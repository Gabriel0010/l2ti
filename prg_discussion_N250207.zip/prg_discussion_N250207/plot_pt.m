function plot_pt(A,str)
  text(A(1),A(2),str,'fontsize',20);
end
