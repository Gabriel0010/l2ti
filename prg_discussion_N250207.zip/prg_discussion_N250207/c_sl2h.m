function [hm,hp,ok]=c_sl2h(s,l,data)
         assert(l>=0); 
         assert(l<=data.O_nb-1); 
  k=c_kappa(s,data);
  if k < data.P_nb-1
         assert(s<=data.S(k+2)); 
  end
         assert(s>=data.S(k+1)); 
  if k >= data.P_nb-2
    hp = +Inf; 
  else 
    u=data.P(k+1,:)-data.P(k+2,:); u /= norm(u);    
    v=data.P(k+3,:)-data.P(k+2,:); v /= norm(v);
    if est_dans_cone(data.O(l+1,:)',data.P(k+2,:)',u',v')  
         assert(est_dans_cone2(data.O(l+1,:)',data.P(k+2,:)',data.P(k+1,:)',data.P(k+3,:)')); 
      c=norm(data.P(k+2,:)-data.O(l+1,:));   
      gamma=c_angle(data.P(k+1,:)',data.P(k+2,:)',data.O(l+1,:)'); 
      if ~(data.rho < c*sin(gamma)) ok = false; hp = NaN; hm = NaN; return; end
      beta=pi-c_angle(data.P(k+1,:)',data.P(k+2,:)',data.P(k+3,:)'); 
      x=data.S(k+2)-s; 
      alpha=c_x2alpha(x,c,gamma,data.rho); 
      if ~(alpha<beta) 
        hp=Inf; 
      else
        f=x*sin(alpha)/sin(beta-alpha);  
        hp=x+f;
         assert(f>=0);
      end
    else 
      hp = +Inf; 
    end
  end
  if k <= 0
    hm = +Inf; 
  else
    u=data.P(k,:)-data.P(k+1,:); u /= norm(u);    
    v=data.P(k+2,:)-data.P(k+1,:); v /= norm(v);
    if est_dans_cone(data.O(l+1,:)',data.P(k+1,:)',u',v')      
      c=norm(data.P(k+1,:)-data.O(l+1,:));   
      gamma=c_angle(data.O(l+1,:)',data.P(k+1,:)',data.P(k+2,:)'); 
      if ~(data.rho < c*sin(gamma)) ok = false; hp = NaN; hm = NaN; return; end
      beta=pi-c_angle(data.P(k,:)',data.P(k+1,:)',data.P(k+2,:)'); 
      x=s-data.S(k+1); 
      alpha= c_x2alpha(x,c,gamma,data.rho); 
      if ~(alpha<beta)
        hm=Inf; 
      else
        f=x*sin(alpha)/sin(beta-alpha); 
        hm=x+f;
         assert(f>=0);
      end
    else 
      hm = +Inf; 
  end
end