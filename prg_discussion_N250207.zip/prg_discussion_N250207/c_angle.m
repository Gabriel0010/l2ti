function DCE=c_angle(D,C,E)
  assert(size(D),[2,1]); 
  assert(size(C),[2,1]); 
  assert(size(E),[2,1]); 
%calcule l'angle DCE
  d=det([D-C E-C])/norm(D-C)/norm(E-C);
  p=(D-C)'*(E-C);
  if p>0 DCE=asin(abs(d)); elseif p<0 DCE=pi-asin(abs(d)); else DCE=pi/2; end
  assert(DCE>=-1e-10);
  assert(DCE<=pi+1e-10);
  DCE=max(0,DCE); 
  DCE=min(pi,DCE); 
end