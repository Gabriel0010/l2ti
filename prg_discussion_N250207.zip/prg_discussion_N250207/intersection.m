function M=intersection(A,u,B,v)
% fonction calcule l'intersection de la droite passant par A et de vecteur unitaire u
% et la droite passant par B et de vecteur unitaire v
  assert(u'*v<1)
  assert(norm(u),1,1e-10); 
  assert(norm(v),1,1e-10); 
  M=A+((B-A)'*u-((B-A)'*v)*(u'*v))/(1-(u'*v)^2)*u; 
end