function [d,ok]=simu2()
%simule des points géométriques
%traite le cas du point M le plus proche de P
%ok=1 si O est dans le secteur MPM'
  CONTINUE = true; 
  while(CONTINUE)
    CONTINUE = false; 
    d.P=randn(2,1); 
    d.O=randn(2,1); 
    d.rho=rand(1); 
    u=randn(2,1); u=u/norm(u); %MP
    v=randn(2,1); v=v/norm(v); %PM'
    d.beta=c_angle(d.P+v,d.P,d.P+u); 
    d.gamma=c_angle(d.O,d.P,d.P-u); 
    d.c=norm(d.O-d.P);   
    if ~(d.c>d.rho) CONTINUE = true; end
    
    %conda = (det([d.O-d.P -u])*det([ v -u])>0);   
    %condb = (det([d.O-d.P  v])*det([-u v])>0);   
    %if ~(conda&&condb) CONTINUE=true; end
    if ~est_dans_cone(d.O,d.P,-u,v) CONTINUE = true; end
    if ~(d.rho<d.c*sin(d.gamma)) CONTINUE = true; end
  end
  ok=(d.c*sin(d.beta+d.gamma)>=d.rho); 
  if ok
    epsi=10^(-(1+7*rand(1))); 
    d.s=(d.c*sin(d.beta+d.gamma)-d.rho)/sin(d.beta)+epsi*d.c; 
    [d.alpha,ok2]=c_s2alpha(d.s,d.c,d.gamma,d.rho);
         assert(ok2==1); 
    d.M=d.P-d.s*u; 
         assert(d.P-d.M,u*norm(d.P-d.M),1e-10); 
    d.sp=d.s*sin(d.alpha)/sin(d.beta-d.alpha); 
    d.Mp=d.P+d.sp*v; 
         assert(d.Mp-d.P,v*norm(d.Mp-d.P),1e-10*norm(d.Mp-d.P)); 
    d.Op=proj(d.O,d.M,(d.Mp-d.M)/norm(d.Mp-d.M)); 
         assert(est_aligne(d.M,d.Mp,d.Op));
         assert(d.rho,norm(d.Op-d.O),1e-10); 
         assert(norm(d.Op-d.M)^2+norm(d.Op-d.O)^2,norm(d.O-d.M)^2,1e-10*norm(d.O-d.M)^2); 
         assert(norm(d.Op-d.M)+norm(d.Mp-d.Op),norm(d.Mp-d.M),1e-8*norm(d.Mp-d.M)); 
         assert(d.c,norm(d.O-d.P),1e-10); 
         assert(norm(d.M-d.Op)+norm(d.Op-d.Mp),norm(d.M-d.Mp),1e-8*norm(d.Mp-d.M)); 
         assert(c_angle(d.M,d.P,d.O)+c_angle(d.O,d.P,d.Mp),c_angle(d.M,d.P,d.Mp),1e-10); 
    d.Opp=intersection(d.M,(d.Mp-d.M)/norm(d.Mp-d.M),d.P,(d.O-d.P)/norm(d.O-d.P)); 
         assert(est_aligne(d.M,d.Opp,d.Mp)); 
         assert(est_aligne(d.P,d.Opp,d.O)); 
    d.c1=norm(d.P-d.Opp); 
    d.c2=norm(d.O-d.Opp);
    assert(d.beta>=d.alpha); 
    assert(d.c1+d.c2,d.c,1e-10); 
    
  end
end



