function v_c_kappa()
  [data,ok]=simu4(); 
         assert(ok,true); 
  s=randn(1)*50; 
  [k,ok]=c_kappa(s,data); 
  if s<0 
         assert(ok,false); 
    return; 
  end
  if s>data.S(end) 
         assert(ok,false);
    return; 
  end
         assert(ok,true); 
         assert(k<=data.P_nb-2);
  if s<=data.S(2)
         assert(k,0); 
  elseif s<=data.S(3)
         assert(k,1);
  elseif s<=data.S(4)
         assert(k,2);   
  end
  s2=rand(1); 
  [k2,ok2]=c_kappa(s,data);     
  if ok2
         assert(k2>=k); 
  end
end