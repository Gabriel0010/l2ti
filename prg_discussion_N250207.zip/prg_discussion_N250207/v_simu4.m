function v_simu4()
  [data,ok]=simu4(); 
         assert(length(data.S) == data.P_nb); 
end