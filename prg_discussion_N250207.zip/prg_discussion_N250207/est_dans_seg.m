function ok=est_dans_seg(M,A,B)
  if abs(norm(M-A)+norm(M-B)-norm(B-A))<1e-6
    ok = true; 
  else 
    ok = false; 
  end
end