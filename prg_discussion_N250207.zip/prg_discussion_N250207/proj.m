function Mp=proj(M,A,u)
%projection de M sur la droite passant par A et de vecteur unitaire u
         assert(norm(u),1,1e-10); 
  Mp=A+(u'*(M-A))*u;
         assert(est_aligne(A,A+u,Mp)); 
end
