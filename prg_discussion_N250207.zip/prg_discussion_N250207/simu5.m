function [d,ok]=simu5()
%cette fonction choisit aléatoire un certain nombre de points P
%et aussi des obstacles. 
%les données sont sauvegardées dans une structure notee d. 
  CONTINUE = true; 
  while(CONTINUE)
    CONTINUE = false; 
    d.P_nb=5; 
    d.P=randn(d.P_nb,2); 
    S=zeros(d.P_nb-1,1); 
    s=0; 
    S(1) = s; 
    for k_=0:d.P_nb-2
      s += norm(d.P(k_+2,:)-d.P(k_+1,:)); 
      S(k_+2) = s; 
    end
    d.S=S; 
    ok=true; 
    d.O_nb=1; %ceil(rand(1)*2); 
    d.O=randn(d.O_nb,2); 
    d.rho=rand(1)*0.5; 
    d.eta=2; 
    if ~ok_obstacles(d) CONTINUE = true; end
  end
end

function ok = ok_obstacles(data)
  ok = true; 
  for k_=1:data.P_nb
    for l_=1:data.O_nb
      if k_<=data.P_nb-1
        c=norm(data.P(k_+1,:)-data.O(l_,:));   
        gamma=c_angle(data.P(k_,:)',data.P(k_+1,:)',data.O(l_,:)'); 
        if ~(data.rho < c*sin(gamma))
          ok = false; 
          return; 
        end
      end
      if k_>=2
        c=norm(data.P(k_,:)-data.O(l_,:));   
        gamma=c_angle(data.P(k_-1,:)',data.P(k_,:)',data.O(l_,:)'); 
        if ~(data.rho < c*sin(gamma))
          ok = false; 
          return; 
        end
      end
    end
  end
end