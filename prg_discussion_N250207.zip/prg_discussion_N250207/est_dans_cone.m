function ok=est_dans_cone(M,A,u,v)
%vérifie que ce point est dans ce cône 
         assert(size(M),[2 1]); 
         assert(size(A),[2 1]); 
         assert(size(u),[2 1]); 
         assert(size(v),[2 1]); 
  conda = (det([M-A u])*det([v u])>=0);   
  condb = (det([M-A v])*det([u v])>=0);   
  ok=conda && condb; 
end