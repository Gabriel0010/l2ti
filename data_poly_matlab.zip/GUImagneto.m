

function varargout = GUImagneto(varargin)
% GUIexemple M-file for GUIexemple.fig
%      GUIexemple, by itself, creates a new GUIexemple or raises the existing
%      singleton*.
%
%      H = GUIexemple returns the handle to a new GUIexemple or the handle to
%      the existing singleton*.
%
%      GUIexemple('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIexemple.M with the given input arguments.
%
%      GUIexemple('Property','Value',...) creates a new GUIexemple or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUIexemple_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUIexemple_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUIexemple

% Last Modified by GUIDE v2.5 31-Aug-2007 00:57:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUIexemple_OpeningFcn, ...
                   'gui_OutputFcn',  @GUIexemple_OutputFcn, ...
                   'gui_LayoutFcn',  @GUImagneto_LayoutFcn, ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT






% --- Executes just before GUIexemple is made visible.
function GUIexemple_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUIexemple (see VARARGIN)

Fs=8000;
handles.Fs=Fs;   % met la valeur Fs dans la structure globale handles
set(handles.text_erreur,'String','attention, enregistrement non sauvegard�');
set(handles.text_erreur,'ForegroundColor',[1 0 0]);
% Choose default command line output for GUIexemple
handles.output = hObject;

% met les attributs de l'objet courant dans la structure g�n�rale
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUIexemple wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUIexemple_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_ecouter.
function pushbutton_ecouter_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_ecouter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Fs=handles.Fs;
son=chirp(0:1/Fs:0.5,200,0.5,500);
volume=0.5;
% si le champ 'volume' a d�j� �t� cr�� c'est qu'on a d�j� chang� le niveau
% sonore avec le slider
if isfield(handles,'volume')
    volume=handles.volume;
end

% si le champ 'enreg' a d�j� �t� cr�� c'est qu'on a d�j� enregistr� un son
if isfield(handles,'enreg')
    son=handles.son;
end
handles.son=son;
sound(volume*son,Fs)

% affiche une courbe dans la fen�tre axes_signal pr�vue, champ qui fait
% partie de la structure g�n�rale handles
axes(handles.axes_signal)
N=length(son);
c=[0 0 1];
plot([0:1/Fs:(N-1)/Fs],son,'Color',c)

% Choose default command line output
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);




% --- Executes on button press in pushbutton_ecouter.
function pushbutton_effacer_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_ecouter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
son=0;
handles.son=0;
Fs=handles.Fs;
% affiche une courbe dans la fen�tre axes_signal pr�vue, champ qui fait
% partie de la structure g�n�rale handles
axes(handles.axes_signal)
N=length(son);
c=[0 0 1];
plot([0:1/Fs:(N-1)/Fs],0)

% Choose default command line output
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function listbox_couleur_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox_couleur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in listbox_couleur.
function listbox_frequence_Callback(hObject, eventdata, handles)
% hObject    handle to listbox_couleur (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox_couleur contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox_couleur
Fs=8000;
% val repr�sente le num�ro de ligne dans la liste
val = get(hObject,'Value');
% tab est un tableau contenant toute les valeurs de la liste. Les
% indices seront donn�s par val
tab=[0 8000 9000 10000 11000 12000 13000 14000 15000];
handles.Fs=Fs;
Fs=tab(val);
handles.Fs=Fs;
% teste s'il y a bien un champ son dans la structure g�n�rale handles
if isfield(handles,'son')
    son=handles.son;
    axes(handles.axes_signal)
    Fs=handles.Fs;
    N=length(son);
    plot([0:1/Fs:(N-1)/Fs],son,'Color',[0 0 1])
end

% Choose default command line output 
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider_volume_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_volume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
    
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on slider movement.
function slider_volume_Callback(hObject, eventdata, handles)
% hObject    handle to slider_volume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% r�cup�re la valeur du volume
volume = get(hObject,'Value');
handles.volume = volume;
% mini = get(hObject, 'Min');
% maxi = get(hObject, 'Max');

% Choose default command line output 
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_duree_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_duree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit_fichier_Callback(hObject, eventdata, handles)
% hObject    handle to edit_duree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_duree as text
%        str2double(get(hObject,'String')) returns contents of edit_duree as a double

% get(hObject,'String') est une cha�ne de caract�res contenant la dur�e et
% qu'il faut convertir en double (r�el)
fichier = get(hObject,'String')% on r�cup�re le nom du fichier 

% si le champ 'enreg' a d�j� �t� cr�� c'est qu'on a d�j� enregistr� un son
if isfield(handles,'enreg')
    son=handles.son;
else 
    handles.son=0;
end

% diff�rents tests pour v�rifier si l'on a bien rentr� un nom de fichier
flag=0;
if (fichier ~= ' ')
    wavwrite(handles.son,fichier);%permet d'enregistrer l'enregistrement 
    flag=1;%indique que l'enregistrement est fait
end
% set permet d'affecter une valeur selon les tests
% pr�c�dents
set(hObject,'String',fichier);
if flag>0
    
    set(handles.text_erreur,'String',fichier);
    set(handles.text_erreur,'ForegroundColor',[0  0.7  0.1]);
else 
    set(handles.text_erreur,'String','attention, enregistrement non sauvegard�');
    set(handles.text_erreur,'ForegroundColor',[1 0 0]);
end
handles.duree = 5;

% Choose default command line output 
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pushbutton_enregistrer.
function pushbutton_enregistrer_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_enregistrer (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Fs=handles.Fs;
duree=3;
if isfield(handles,'duree')
    duree=handles.duree;
end
handles.enreg=1;

% enregistre � partir du p�riph�rique micro par d�faut et convertit en
% double entre 0 et 1 (le format de sortie de wavrecord est uint8=entier 8 bits non sign�,
% donc de 0 � 255)
son=double(wavrecord(duree*Fs, Fs,1,'uint8'))/255;
% �met un bip
beep

handles.son=son;

% Choose default command line output 
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pushbutton_DSP
function pushbutton_DSP_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_ecouter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Fs=handles.Fs;

% affiche une courbe dans la fen�tre axes_signal pr�vue, champ qui fait
% partie de la structure g�n�rale handles
% affiche une courbe dans la fen�tre axes_signal pr�vue, champ qui fait
% partie de la structure g�n�rale handles
%axes(handles.axes_signal)
%plot([0:1/Fs:(N-1)/Fs],son,'Color',c)


%axes(handles.axes_signal)
c=[1 1 1];
%psd_son=
psd(spectrum.welch,handles.son,'Fs',Fs);
%N=length(psd_son);
%plot([0:1/Fs:(N-1)/Fs],psd_son,'Color',c)

% Choose default command line output
handles.output = hObject;
% Update handles structure
guidata(hObject, handles);


% toute la suite permet de cr�er la fen�tre principale GUI_exemple 
% avec les propri�t�s de tous les objets pr�sents dans la fen�tre

% --- Creates and returns a handle to the GUI figure. 
function h1 = GUImagneto_LayoutFcn(policy)
% policy - create a new figure or use a singleton. 'new' or 'reuse'.

persistent hsingleton;
if strcmpi(policy, 'reuse') & ishandle(hsingleton)
    h1 = hsingleton;
    return;
end

h1 = figure(...
'Units','characters',...
'PaperUnits',get(0,'defaultfigurePaperUnits'),...
'Color',[0.835294117647059 0.8 0.733333333333333],...
'Colormap',[0 0 0.5625;0 0 0.625;0 0 0.6875;0 0 0.75;0 0 0.8125;0 0 0.875;0 0 0.9375;0 0 1;0 0.0625 1;0 0.125 1;0 0.1875 1;0 0.25 1;0 0.3125 1;0 0.375 1;0 0.4375 1;0 0.5 1;0 0.5625 1;0 0.625 1;0 0.6875 1;0 0.75 1;0 0.8125 1;0 0.875 1;0 0.9375 1;0 1 1;0.0625 1 1;0.125 1 0.9375;0.1875 1 0.875;0.25 1 0.8125;0.3125 1 0.75;0.375 1 0.6875;0.4375 1 0.625;0.5 1 0.5625;0.5625 1 0.5;0.625 1 0.4375;0.6875 1 0.375;0.75 1 0.3125;0.8125 1 0.25;0.875 1 0.1875;0.9375 1 0.125;1 1 0.0625;1 1 0;1 0.9375 0;1 0.875 0;1 0.8125 0;1 0.75 0;1 0.6875 0;1 0.625 0;1 0.5625 0;1 0.5 0;1 0.4375 0;1 0.375 0;1 0.3125 0;1 0.25 0;1 0.1875 0;1 0.125 0;1 0.0625 0;1 0 0;0.9375 0 0;0.875 0 0;0.8125 0 0;0.75 0 0;0.6875 0 0;0.625 0 0;0.5625 0 0],...
'IntegerHandle','off',...
'InvertHardcopy',get(0,'defaultfigureInvertHardcopy'),...
'MenuBar','none',...
'Name','GUImagneto',...
'NumberTitle','off',...
'PaperPosition',get(0,'defaultfigurePaperPosition'),...
'PaperSize',[20.98404194812 29.67743169791],...
'PaperType',get(0,'defaultfigurePaperType'),...
'Position',[103.8 15.5384615384615 157 45.9230769230769],...
'Renderer',get(0,'defaultfigureRenderer'),...
'RendererMode','manual',...
'HandleVisibility','callback',...
'Tag','figure1',...
'UserData',[]);

setappdata(h1, 'GUIDEOptions',struct(...
'active_h', [], ...
'taginfo', struct(...
'figure', 2, ...
'axes', 2, ...
'pushbutton', 3, ...
'togglebutton', 2, ...
'listbox', 2, ...
'popupmenu', 2, ...
'radiobutton', 2, ...
'slider', 2, ...
'text', 6, ...
'edit', 2), ...
'override', 0, ...
'release', 13, ...
'resize', 'none', ...
'accessibility', 'callback', ...
'mfile', 1, ...
'callbacks', 1, ...
'singleton', 1, ...
'syscolorfig', 1, ...
'blocking', 0, ...
'lastSavedFile', 'E:\caro\Enseignement\Initiation Matlab\GUIexemple.m'));


h2 = axes(...
'Parent',h1,...
'CameraPosition',[0.5 0.5 9.16025403784439],...
'CameraPositionMode',get(0,'defaultaxesCameraPositionMode'),...
'Color',get(0,'defaultaxesColor'),...
'ColorOrder',get(0,'defaultaxesColorOrder'),...
'Position',[0.0624203821656051 0.281407035175879 0.612738853503185 0.618090452261307],...
'XColor',get(0,'defaultaxesXColor'),...
'YColor',get(0,'defaultaxesYColor'),...
'ZColor',get(0,'defaultaxesZColor'),...
'Tag','axes_signal');


h3 = get(h2,'title');

set(h3,...
'Parent',h2,...
'Color',[0 0 0],...
'HorizontalAlignment','center',...
'Position',[0.9 1.01761517615176 1.00005459937205],...
'VerticalAlignment','bottom',...
'HandleVisibility','off');

h4 = get(h2,'xlabel');

set(h4,...
'Parent',h2,...
'Color',[0 0 0],...
'HorizontalAlignment','center',...
'Position',[0.497920997920998 -0.0636856368563685 1.00005459937205],...
'VerticalAlignment','cap',...
'HandleVisibility','off');

h5 = get(h2,'ylabel');

set(h5,...
'Parent',h2,...
'Color',[0 0 0],...
'HorizontalAlignment','center',...
'Position',[-0.0592515592515593 0.497289972899729 1.00005459937205],...
'Rotation',90,...
'VerticalAlignment','bottom',...
'HandleVisibility','off');

h6 = get(h2,'zlabel');

set(h6,...
'Parent',h2,...
'Color',[0 0 0],...
'HorizontalAlignment','right',...
'Position',[-0.102910602910603 1.15853658536585 1.00005459937205],...
'HandleVisibility','off',...
'Visible','off');

h7 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'Callback','GUImagneto(''pushbutton_ecouter_Callback'',gcbo,[],guidata(gcbo))',...
'FontSize',8,...
'ListboxTop',0,...
'Position',[0.785987261146497 0.745393634840871 0.10 0.0586264656616415],...
'String','Ecouter',...
'Tag','pushbutton_ecouter');


h8 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'BackgroundColor',[1 1 1],...
'Callback','GUImagneto(''listbox_frequence_Callback'',gcbo,[],guidata(gcbo))',...
'Position',[0.722292993630573 0.499162479061977 0.212738853503185 0.137353433835846],...
'String',{  '8000'; '9000'; '10000'; '11000'; '12000'; '13000'; '14000'; '15000' },...
'Style','listbox',...
'Value',1,...
'CreateFcn','GUImagneto(''listbox_couleur_CreateFcn'',gcbo,[],guidata(gcbo))',...
'Tag','listbox_couleur');


h9 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'BackgroundColor',[0.9 0.9 0.9],...
'Callback','GUImagneto(''slider_volume_Callback'',gcbo,[],guidata(gcbo))',...
'ListboxTop',0,...
'Position',[0.722292993630573 0.33500837520938 0.192356687898089 0.050251256281407],...
'String','',...
'Style','slider',...
'Value',0.5,...
'CreateFcn','GUImagneto(''slider_volume_CreateFcn'',gcbo,[],guidata(gcbo))',...
'Tag','slider_volume');


h10 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'ListboxTop',0,...
'Position',[0.722292993630573 0.252931323283082 0.192356687898089 0.0485762144053601],...
'String','Volume',...
'Style','text',...
'Tag','text_volume');


h11 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'BackgroundColor',[1 1 1],... 
'Callback','GUImagneto(''edit_fichier_Callback'',gcbo,[],guidata(gcbo))',...
'ListboxTop',0,...
'Position',[0.53 0.19 0.2 0.0301507537688442],...
'String','',...
'Style','edit',...
'CreateFcn','GUImagneto(''edit_duree_CreateFcn'',gcbo,[],guidata(gcbo))',...
'Tag','edit_duree');


h12 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'ListboxTop',0,...
'Position',[0.28 0.172529313232831 0.226751592356688 0.0435510887772194],...
'String','Sauvegarder l''enregistrement sous:',...
'Style','text',...
'Tag','text_duree');




h14 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'Callback','GUImagneto(''pushbutton_enregistrer_Callback'',gcbo,[],guidata(gcbo))',...
'ListboxTop',0,...
'Position',[0.069 0.172529313232831 0.198726114649682 0.0720268006700168],...
'String','D�marrer enregistrement',...
'Tag','pushbutton_enregistrer');

h15 = uicontrol(...
'Parent',h1,...
'Units','characters',...
'ForegroundColor',[1 0 0],...
'ListboxTop',0,...
'Position',[78 7 50.2 1],...
'String','',...
'Style','text',...
'Tag','text_erreur');



hsingleton = h1;








h16 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'Callback','GUImagneto(''pushbutton_effacer_Callback'',gcbo,[],guidata(gcbo))',...
'FontSize',8,...
'ListboxTop',0,...
'Position',[0.89 0.745393634840871 0.10 0.0586264656616415],...
'String','efface',...
'Tag','pushbutton_effacer');

h17 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'ListboxTop',0,...
'Position',[0.722292993630573 0.64 0.192356687898089 0.040],...
'String','Fr�quence d''�chantillonage (Hz)',...
'Style','text',...
'Tag','text_volume');



h18 = uicontrol(...
'Parent',h1,...
'Units','normalized',...
'Callback','GUImagneto(''pushbutton_DSP_Callback'',gcbo,[],guidata(gcbo))',...
'FontSize',8,...
'ListboxTop',0,...
'Position',[0.68 0.745393634840871 0.10 0.0586264656616415],...
'String','DSP',...
'Tag','pushbutton_DSP');









% --- Handles default GUIDE GUI creation and callback dispatch
function varargout = gui_mainfcn(gui_State, varargin)


%   GUI_MAINFCN provides these command line APIs for dealing with GUIs
%
%      GUIexemple, by itself, creates a new GUIexemple or raises the existing
%      singleton*.
%
%      H = GUIexemple returns the handle to a new GUIexemple or the handle to
%      the existing singleton*.
%
%      GUIexemple('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUIexemple.M with the given input arguments.
%
%      GUIexemple('Property','Value',...) creates a new GUIexemple or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before untitled_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to untitled_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".

%   Copyright 1984-2002 The MathWorks, Inc.
%   $Revision: 1.5 $ $Date: 2003/07/17 18:28:28 $

gui_StateFields =  {'gui_Name'
                    'gui_Singleton'
                    'gui_OpeningFcn'
                    'gui_OutputFcn'
                    'gui_LayoutFcn'
                    'gui_Callback'};
gui_Mfile = '';
for i=1:length(gui_StateFields)
    if ~isfield(gui_State, gui_StateFields{i})
        error('Could not find field %s in the gui_State struct in GUI M-file %s', gui_StateFields{i}, gui_Mfile);        
    elseif isequal(gui_StateFields{i}, 'gui_Name')
        gui_Mfile = [getfield(gui_State, gui_StateFields{i}), '.m'];
    end
end

numargin = length(varargin);

if numargin == 0
    % GUIexemple
    % create the GUI
    gui_Create = 1;
elseif numargin > 3 & ischar(varargin{1}) & ishandle(varargin{2})
    % GUIexemple('CALLBACK',hObject,eventData,handles,...)
    gui_Create = 0;
else
    % GUIexemple(...)
    % create the GUI and hand varargin to the openingfcn
    gui_Create = 1;
end

if gui_Create == 0
    varargin{1} = gui_State.gui_Callback;
    if nargout
        [varargout{1:nargout}] = feval(varargin{:});
    else
        feval(varargin{:});
    end
else
    if gui_State.gui_Singleton
        gui_SingletonOpt = 'reuse';
    else
        gui_SingletonOpt = 'new';
    end
    
    % Open fig file with stored settings.  Note: This executes all component
    % specific CreateFunctions with an empty HANDLES structure.
    
    % Do feval on layout code in m-file if it exists
    if ~isempty(gui_State.gui_LayoutFcn)
        gui_hFigure = feval(gui_State.gui_LayoutFcn, gui_SingletonOpt);
    else
        gui_hFigure = local_openfig(gui_State.gui_Name, gui_SingletonOpt);            
        % If the figure has InGUIInitialization it was not completely created
        % on the last pass.  Delete this handle and try again.
        if isappdata(gui_hFigure, 'InGUIInitialization')
            delete(gui_hFigure);
            gui_hFigure = local_openfig(gui_State.gui_Name, gui_SingletonOpt);            
        end
    end
    
    % Set flag to indicate starting GUI initialization
    setappdata(gui_hFigure,'InGUIInitialization',1);

    % Fetch GUIDE Application options
    gui_Options = getappdata(gui_hFigure,'GUIDEOptions');
    
    if ~isappdata(gui_hFigure,'GUIOnScreen')
        % Adjust background color
        if gui_Options.syscolorfig 
            set(gui_hFigure,'Color', get(0,'DefaultUicontrolBackgroundColor'));
        end

        % Generate HANDLES structure and store with GUIDATA
        guidata(gui_hFigure, guihandles(gui_hFigure));
    end
    
    % If user specified 'Visible','off' in p/v pairs, don't make the figure
    % visible.
    gui_MakeVisible = 1;
    for ind=1:2:length(varargin)
        if length(varargin) == ind
            break;
        end
        len1 = min(length('visible'),length(varargin{ind}));
        len2 = min(length('off'),length(varargin{ind+1}));
        if ischar(varargin{ind}) & ischar(varargin{ind+1}) & ...
                strncmpi(varargin{ind},'visible',len1) & len2 > 1
            if strncmpi(varargin{ind+1},'off',len2)
                gui_MakeVisible = 0;
            elseif strncmpi(varargin{ind+1},'on',len2)
                gui_MakeVisible = 1;
            end
        end
    end
    
    % Check for figure param value pairs
    for index=1:2:length(varargin)
        if length(varargin) == index
            break;
        end
        try, set(gui_hFigure, varargin{index}, varargin{index+1}), catch, break, end
    end

    % If handle visibility is set to 'callback', turn it on until finished
    % with OpeningFcn
    gui_HandleVisibility = get(gui_hFigure,'HandleVisibility');
    if strcmp(gui_HandleVisibility, 'callback')
        set(gui_hFigure,'HandleVisibility', 'on');
    end
    
    feval(gui_State.gui_OpeningFcn, gui_hFigure, [], guidata(gui_hFigure), varargin{:});
    
    if ishandle(gui_hFigure)
        % Update handle visibility
        set(gui_hFigure,'HandleVisibility', gui_HandleVisibility);
        
        % Make figure visible
        if gui_MakeVisible
            set(gui_hFigure, 'Visible', 'on')
            if gui_Options.singleton 
                setappdata(gui_hFigure,'GUIOnScreen', 1);
            end
        end

        % Done with GUI initialization
        rmappdata(gui_hFigure,'InGUIInitialization');
    end
    
    % If handle visibility is set to 'callback', turn it on until finished with
    % OutputFcn
    if ishandle(gui_hFigure)
        gui_HandleVisibility = get(gui_hFigure,'HandleVisibility');
        if strcmp(gui_HandleVisibility, 'callback')
            set(gui_hFigure,'HandleVisibility', 'on');
        end
        gui_Handles = guidata(gui_hFigure);
    else
        gui_Handles = [];
    end
    
    if nargout
        [varargout{1:nargout}] = feval(gui_State.gui_OutputFcn, gui_hFigure, [], gui_Handles);
    else
        feval(gui_State.gui_OutputFcn, gui_hFigure, [], gui_Handles);
    end
    
    if ishandle(gui_hFigure)
        set(gui_hFigure,'HandleVisibility', gui_HandleVisibility);
    end
end    

function gui_hFigure = local_openfig(name, singleton)
try
    gui_hFigure = openfig(name, singleton, 'auto');
catch
    % OPENFIG did not accept 3rd input argument until R13,
    % toggle default figure visible to prevent the figure
    % from showing up too soon.
    gui_OldDefaultVisible = get(0,'defaultFigureVisible');
    set(0,'defaultFigureVisible','off');
    gui_hFigure = openfig(name, singleton);
    set(0,'defaultFigureVisible',gui_OldDefaultVisible);
end

