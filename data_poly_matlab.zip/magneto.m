function magneto
clear all
Fs = 8000;
y  = wavrecord(5*Fs, Fs, 'int16');
beep;
wavplay(y,Fs);
fprintf('\n max = %d et min = % d \n',max(y),min(y));
fin=0;
fprintf('Vous souhaitez : \n 1 - amplifier \n 2 - att�nuer \n')
choix=input('');
switch choix 
    case 1 
        fprintf('\n entrez une valeur\n ');
        volume=input('')
        wavplay(y*volume,Fs);
        if (y*volume>0.5)
            disp('Attention son trop fort');
        end 
    case 2
        fprintf('\n entrez une ++valeur\n ');
        volume=input('')
        wavplay(y/volume,Fs);
    otherwise
            disp('mauvais choix.')

end 

wavwrite(y,'enregistrement');
disp('enregistrement sauvegard�');

