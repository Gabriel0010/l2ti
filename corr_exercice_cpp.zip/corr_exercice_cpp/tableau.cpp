#include "tableau.hpp"

ListeI::ListeI(void):premier(0){}
ListeI::~ListeI(void)
{
  while(!premier)
  {
    CellI *ptr=premier->suiv;
    delete premier;
    premier=ptr;
  }
}
void ListeI::ajouter(void)
{
  CellI * c=new CellI;
  c->suiv=premier;
  premier=c;
}

Tableau::Tableau(int taille)
{
  for(int i=0;i<taille;i++)
    ajouter();
}
int & Tableau::operator[](int i)
{
  CellI * ptr=premier;
  for(int j=0;j<i;j++)
    ptr=ptr->suiv;
  return ptr->i;
}