using namespace std;
#include <iostream>
#include <iomanip>

class Fiche
{
private:
  char nom[10];
  int age;
public:
  Fiche(const char * const nom,const int age);
  Fiche(const Fiche &);
  bool sAppelleAinsi(const char * const nom)const;
  int & lireAge();
  friend ostream & operator<< (ostream & Flux,const Fiche f);
};

class Age
{
private:
  Fiche * tab[10];
  int curseur; //pointe sur la fiche non-utilis�e
  bool nomDejaUtilise(const char * const nom,int & index)const;
public:
  Age();
  Age(const Age & t);
  ~Age();
  int & operator[](const char * const);
  friend ostream & operator<<(ostream &,Age tab);
};


class Fiche1
{
public:
  char nom[10];
  int age;
public:
  bool sAppelleAinsi(const char * const nom)const;
  friend ostream & operator<< (ostream & Flux,const Fiche1 f);
};

class Age1
{
private:
  Fiche1  tab[10];
  int curseur; //pointe sur la fiche non-utilis�e
  bool nomDejaUtilise(const char * const nom,int & index)const;
public:
  Age1();
  Age1(const Age1 & t);
  int & operator[](const char *const);
  friend ostream & operator<<(ostream &,const Age1 tab);
};

class Fiche2
{
private:
  char nom[10];
  int age;
public:
  bool sAppelleAinsi(const char * const nom)const;
  void copie(const Fiche2 & f);
  void setNom(const char * const nom);
  int & lireAge(void);
  friend ostream & operator<< (ostream & Flux,const Fiche2 f);
};

class Age2
{
private:
  Fiche2  tab[10];
  int curseur; //pointe sur la fiche non-utilis�e
  bool nomDejaUtilise(const char * const nom,int & index)const;
public:
  Age2();
  Age2(const Age2 & t);
  int & operator[](const char *const);
  friend ostream & operator<<(ostream &,const Age2 tab);
};