using namespace std;
#include "age.hpp"

int main(void)
{
  //test de la classe Fiche
  Fiche personne("Pierre",20);
  personne.lireAge()=18;
  if (!personne.sAppelleAinsi("Pierre")) return -1;
  if (personne.sAppelleAinsi("Jean")) return -1;
  cout << personne;
  //test de la classe Age
  Age tab;
  tab["Pierre"]=15;
  tab["Jean"]=26;
  cout << tab;
  //test de la classe Age1
  Age1 tab1;
  tab1["Pierre"]=15;
  tab1["Jean"]=26;
  cout << tab1;
  //test de la classe Age2
  Age2 tab2;
  tab2["Pierre"]=15;
  tab2["Jean"]=26;
  cout << tab2;

	return 0;
}