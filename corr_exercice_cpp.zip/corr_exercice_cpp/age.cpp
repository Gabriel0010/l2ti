#include "age.hpp"


//Solution 1 : 
Fiche::Fiche(const char * const nom,const int age):age(age)
{
  strcpy(this->nom,nom);
}
Fiche::Fiche(const Fiche & f):age(f.age)
{
  strcpy(nom,f.nom);
}
bool Fiche::sAppelleAinsi(const char * const nom)const
{
  return 0==strcmp(this->nom,nom);
}
ostream & operator<< (ostream & Flux,const Fiche f)
{
  Flux <<  setiosflags(ios::left) << setw(10) << f.nom << ' ' << f.age << endl;
  return Flux;
}
int & Fiche::lireAge()
{
  return age;
}
Age::Age():curseur(0){}
Age::~Age(void)
{
  for(int i=0; i<curseur; i++) delete tab[i];
}
Age::Age(const Age & t):curseur(t.curseur)
{
  for(int i=0;i<curseur;i++)
    tab[i]=new Fiche(*t.tab[i]);
}
bool Age::nomDejaUtilise(const char * const nom,int & index)const
{
  bool test=false;
  index=-1;
  for(int i=0;i<curseur;i++)
    if (tab[i]->sAppelleAinsi(nom))
    {
      test=true; index=i;
    }
  return test;
}
int & Age::operator[](const char * const nom)
{
  int index=0;
  if (nomDejaUtilise(nom,index))
    return tab[index]->lireAge();
  else
  {
    int age1=0;
    tab[curseur]=new Fiche(nom,age1);
    return tab[curseur++]->lireAge();
  }
}
ostream & operator<<(ostream & Flux,const Age tab)
{
  for(int i=0;i<tab.curseur;i++)
    Flux << *(tab.tab[i]);
  return Flux;
}

//Solution 2
bool Fiche1::sAppelleAinsi(const char * const nom) const
{
  return 0==strcmp(this->nom,nom);
}
ostream & operator<< (ostream & Flux,const Fiche1 f)
{
  Flux <<  setiosflags(ios::left) << setw(10) << f.nom << ' ' << f.age << endl;
  return Flux;
}
Age1::Age1():curseur(0){}
Age1::Age1(const Age1 & t):curseur(t.curseur)
{
  for(int i=0;i<curseur;i++)
  {
    strcpy(tab[i].nom,t.tab[i].nom);
    tab[i].age=t.tab[i].age;
  }
}
bool Age1::nomDejaUtilise(const char * const nom,int & index)const
{
  bool test=false;
  index=-1;
  for(int i=0;i<curseur;i++)
    if (tab[i].sAppelleAinsi(nom))
    {
      test=true; index=i;
    }
  return test;
}
int & Age1::operator[](const char * const nom)
{
  int index=0;
  if (nomDejaUtilise(nom,index))
    return tab[index].age;
  else
  {
    int age1=0;
    strcpy(tab[curseur].nom,nom);
    return tab[curseur++].age;
  }
}
ostream & operator<<(ostream & Flux,const Age1 tab)
{
  for(int i=0;i<tab.curseur;i++)
    Flux << tab.tab[i];
  return Flux;
}

//SOLUTION 3
void Fiche2::copie(const Fiche2 & f)
{
  strcpy(this->nom,f.nom);
  this->age=f.age;
}
void Fiche2::setNom(const char * const nom)
{
  strcpy(this->nom,nom);
}
bool Fiche2::sAppelleAinsi(const char * const nom)const 
{
  return 0==strcmp(this->nom,nom);
}
int & Fiche2::lireAge(void)
{
  return age;
}
ostream & operator<< (ostream & Flux,const Fiche2 f)
{
  Flux <<  setiosflags(ios::left) << setw(10) << f.nom << ' ' << f.age << endl;
  return Flux;
}
Age2::Age2():curseur(0){}
Age2::Age2(const Age2 & t):curseur(t.curseur)
{
  for(int i=0;i<curseur;i++)
    tab[i].copie(t.tab[i]);
}
bool Age2::nomDejaUtilise(const char * const nom,int & index)const
{
  bool test=false;
  index=-1;
  for(int i=0;i<curseur;i++)
    if (tab[i].sAppelleAinsi(nom))
    {
      test=true; index=i;
    }
  return test;
}
int & Age2::operator[](const char * const nom)
{
  int index=0;
  if (nomDejaUtilise(nom,index))
    return tab[index].lireAge();
  else
  {
    int age1=0;
    tab[curseur].setNom(nom);
    return tab[curseur++].lireAge();
  }
}
ostream & operator<<(ostream & Flux,const Age2 tab)
{
  for(int i=0;i<tab.curseur;i++)
    Flux << tab.tab[i];
  return Flux;
}



