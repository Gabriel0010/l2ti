using namespace std;
#include <iostream>
#include "tableau.hpp"

int main(void)
{
  //test de la classe ListeI
  ListeI liste;
  for(int i=0; i<10; i++)
    liste.ajouter();
  CellI * ptr=liste.premier;
  int j=0;
  while(ptr!=0) 
  {
    ptr->i=j++; ptr=ptr->suiv;
  }
  ptr=liste.premier;
  while(ptr!=0)
  {
    cout << ptr->i << ' ';
    ptr=ptr->suiv;
  }
  cout << endl;
  //test de la classe Tableau
  Tableau tab(3);
  tab[0]=0;
  tab[1]=1;
  tab[2]=2;
  for(int i=0; i<3;i++) cout << tab[i] << ' ';
  cout << endl;
  return 0;
}