

class CellI
{
public:
  int i;
  CellI * suiv;
};

class ListeI
{
public:
  CellI * premier;
public:
  ListeI();
  ~ListeI();
  void ajouter(void);
};

class Tableau:ListeI
{
public:
  Tableau(int taille);
  int & operator[](int i);
};